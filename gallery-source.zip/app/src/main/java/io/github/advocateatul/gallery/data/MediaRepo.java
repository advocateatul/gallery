package io.github.advocateatul.gallery.data;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MediaRepo {
    public static class Album {
        public String name;
        public int count;
        public int photoCount;
        public int videoCount;
        public MediaItem cover;
        public long latest;
    }

    private static final String[] IMG_PROJ = {
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATA, MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.LATITUDE, MediaStore.Images.Media.LONGITUDE,
            MediaStore.Images.Media.RELATIVE_PATH };
    private static final String[] VID_PROJ = {
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA, MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE, MediaStore.Video.Media.DATE_TAKEN,
            MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.LATITUDE, MediaStore.Video.Media.LONGITUDE,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.RELATIVE_PATH };

    public static List<MediaItem> queryAll(Context c, int sort) {
        List<MediaItem> out = new ArrayList<MediaItem>();
        out.addAll(queryUri(c, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, IMG_PROJ, false, null));
        out.addAll(queryUri(c, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, VID_PROJ, true, null));
        sortList(out, sort);
        return out;
    }

    public static List<MediaItem> queryBucket(Context c, String bucket, int sort) {
        List<MediaItem> out = new ArrayList<MediaItem>();
        String sel = MediaStore.Images.Media.BUCKET_DISPLAY_NAME + "=?";
        String[] args = new String[]{bucket};
        out.addAll(queryUri(c, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, IMG_PROJ, false, sel, args));
        out.addAll(queryUri(c, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, VID_PROJ, true, sel, args));
        sortList(out, sort);
        return out;
    }

    public static MediaItem getByKey(Context c, String key) {
        if (key == null || key.length() < 2) return null;
        boolean video = key.charAt(0) == 'v';
        long id;
        try { id = Long.parseLong(key.substring(1)); } catch (NumberFormatException e) { return null; }
        Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        List<MediaItem> l = queryUri(c, ContentUris.withAppendedId(base, id),
                video ? VID_PROJ : IMG_PROJ, video, null);
        return l.isEmpty() ? null : l.get(0);
    }

    /** Look up an item that may be in the trash (API 30+: trashed items are
     *  hidden from normal queries unless MATCH_TRASHED is requested). */
    public static MediaItem getByKeyTrashed(Context c, String key) {
        if (key == null || key.length() < 2) return null;
        boolean video = key.charAt(0) == 'v';
        long id;
        try { id = Long.parseLong(key.substring(1)); } catch (NumberFormatException e) { return null; }
        Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Uri uri = ContentUris.withAppendedId(base, id);
        if (Build.VERSION.SDK_INT >= 30) {
            ContentResolver cr = c.getContentResolver();
            android.os.Bundle qb = new android.os.Bundle();
            qb.putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_INCLUDE);
            String[] proj = video ? VID_PROJ : IMG_PROJ;
            Cursor cur = null;
            try {
                cur = cr.query(uri, proj, qb, null);
                if (cur != null && cur.moveToFirst()) {
                    List<MediaItem> one = new ArrayList<MediaItem>();
                    // reuse the row parser by re-querying through the shared path:
                    // simplest: build the item from this cursor directly
                    MediaItem m = new MediaItem();
                    m.id = id; m.isVideo = video; m.uri = uri;
                    m.name = cur.getString(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME));
                    int iData = cur.getColumnIndex(MediaStore.MediaColumns.DATA);
                    m.path = iData >= 0 ? cur.getString(iData) : null;
                    m.bucket = cur.getString(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME));
                    if (m.bucket == null) m.bucket = "";
                    m.mime = cur.getString(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE));
                    m.dateTaken = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN));
                    long added = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED));
                    m.dateAdded = added * 1000L;
                    if (m.dateTaken <= 0) m.dateTaken = m.dateAdded;
                    m.size = cur.getLong(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE));
                    m.width = cur.getInt(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH));
                    m.height = cur.getInt(cur.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT));
                    int iDur = video ? cur.getColumnIndex(MediaStore.Video.Media.DURATION) : -1;
                    if (iDur >= 0) m.duration = cur.getLong(iDur);
                    one.add(m);
                    return m;
                }
            } catch (Exception e) {
                return null;
            } finally {
                if (cur != null) cur.close();
            }
            return null;
        }
        return getByKey(c, key);
    }

    private static List<MediaItem> queryUri(Context c, Uri uri, String[] proj, boolean video, String sel, String... args) {
        List<MediaItem> out = new ArrayList<MediaItem>();
        ContentResolver cr = c.getContentResolver();
        Cursor cur = null;
        try {
            cur = cr.query(uri, proj, sel, args, null);
            if (cur == null) return out;
            int iId = cur.getColumnIndexOrThrow("_id");
            int iName = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
            int iData = cur.getColumnIndex(MediaStore.MediaColumns.DATA);
            int iBucket = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME);
            int iMime = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE);
            int iTaken = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN);
            int iAdded = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED);
            int iSize = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE);
            int iW = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH);
            int iH = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT);
            int iLat = cur.getColumnIndex("latitude");
            int iLng = cur.getColumnIndex("longitude");
            int iDur = video ? cur.getColumnIndex(MediaStore.Video.Media.DURATION) : -1;
            int iRel = cur.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
            while (cur.moveToNext()) {
                MediaItem m = new MediaItem();
                m.id = cur.getLong(iId);
                m.isVideo = video;
                m.uri = ContentUris.withAppendedId(uri, m.id);
                m.name = cur.getString(iName);
                m.path = iData >= 0 ? cur.getString(iData) : null;
                if ((m.path == null || m.path.isEmpty()) && iRel >= 0) {
                    String rel = cur.getString(iRel);
                    m.path = (rel != null ? rel : "") + (m.name != null ? m.name : "");
                }
                m.bucket = cur.getString(iBucket);
                if (m.bucket == null) m.bucket = "";
                m.mime = cur.getString(iMime);
                m.dateTaken = cur.getLong(iTaken);
                long added = cur.getLong(iAdded);
                m.dateAdded = added * 1000L;
                if (m.dateTaken <= 0) m.dateTaken = m.dateAdded;
                m.size = cur.getLong(iSize);
                m.width = cur.getInt(iW);
                m.height = cur.getInt(iH);
                if (iLat >= 0 && !cur.isNull(iLat)) m.lat = cur.getDouble(iLat);
                if (iLng >= 0 && !cur.isNull(iLng)) m.lng = cur.getDouble(iLng);
                if (iDur >= 0) m.duration = cur.getLong(iDur);
                out.add(m);
            }
        } catch (Exception e) {
            // query failed; return what we have
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }

    private static List<MediaItem> queryUri(Context c, Uri uri, String[] proj, boolean video, String sel) {
        return queryUri(c, uri, proj, video, sel, (String[]) null);
    }

    public static void sortList(List<MediaItem> list, int sort) {
        final int s = sort;
        Collections.sort(list, new Comparator<MediaItem>() {
            @Override public int compare(MediaItem a, MediaItem b) {
                switch (s) {
                    case 1: return Long.compare(a.dateTaken, b.dateTaken);
                    case 2: return safe(a.name).compareToIgnoreCase(safe(b.name));
                    case 3: return Long.compare(b.size, a.size);
                    default: return Long.compare(b.dateTaken, a.dateTaken);
                }
            }
        });
    }
    private static String safe(String s) { return s == null ? "" : s; }

    public static List<Album> queryAlbums(Context c) {
        Map<String, Album> map = new LinkedHashMap<String, Album>();
        List<MediaItem> all = queryAll(c, 0);
        for (MediaItem m : all) {
            Album a = map.get(m.bucket);
            if (a == null) {
                a = new Album();
                a.name = m.bucket.isEmpty() ? "Unknown" : m.bucket;
                a.cover = m;
                map.put(m.bucket, a);
            }
            a.count++;
            if (m.isVideo) a.videoCount++; else a.photoCount++;
            if (m.dateTaken > a.latest) a.latest = m.dateTaken;
        }
        List<Album> out = new ArrayList<Album>(map.values());
        Collections.sort(out, new Comparator<Album>() {
            @Override public int compare(Album a, Album b) { return Long.compare(b.latest, a.latest); }
        });
        return out;
    }

    // ---- smart search: name, album, type, location, date text ----
    public static List<MediaItem> search(Context c, String q, String typeFilter) {
        List<MediaItem> all = queryAll(c, 0);
        if (q == null) q = "";
        q = q.trim();
        if (q.isEmpty() && (typeFilter == null || typeFilter.isEmpty())) return all;
        String lower = q.toLowerCase(Locale.getDefault());
        Long[] dateRange = parseDateQuery(lower);
        List<MediaItem> out = new ArrayList<MediaItem>();
        for (MediaItem m : all) {
            if (typeFilter != null) {
                if (typeFilter.equals("photo") && m.isVideo) continue;
                if (typeFilter.equals("video") && !m.isVideo) continue;
                if (typeFilter.equals("location") && !m.hasLocation()) continue;
            }
            if (q.isEmpty()) { out.add(m); continue; }
            boolean hit = false;
            if (m.name != null && m.name.toLowerCase(Locale.getDefault()).contains(lower)) hit = true;
            if (m.bucket != null && m.bucket.toLowerCase(Locale.getDefault()).contains(lower)) hit = true;
            if (dateRange != null && m.dateTaken >= dateRange[0] && m.dateTaken < dateRange[1]) hit = true;
            if (!hit) {
                // match "January 2026" style month/year in date
                String ds = new SimpleDateFormat("MMMM yyyy MMMM d yyyy", Locale.getDefault()).format(new Date(m.dateTaken)).toLowerCase(Locale.getDefault());
                if (ds.contains(lower)) hit = true;
            }
            if (hit) out.add(m);
        }
        return out;
    }

    // parses "january 2026", "2026", "16 november", "november" -> [start,end) ms, or null
    private static Long[] parseDateQuery(String q) {
        String[] months = {"january","february","march","april","may","june","july","august","september","october","november","december"};
        int month = -1, year = -1, day = -1;
        for (int i = 0; i < months.length; i++) {
            if (q.contains(months[i])) { month = i; break; }
        }
        String digits = q.replaceAll("[^0-9 ]", " ").trim();
        String[] parts = digits.split("\\s+");
        for (String p : parts) {
            if (p.isEmpty()) continue;
            try {
                int v = Integer.parseInt(p);
                if (v >= 1900 && v <= 2100) year = v;
                else if (v >= 1 && v <= 31 && day < 0) day = v;
            } catch (NumberFormatException ignored) {}
        }
        if (month < 0 && year < 0 && day < 0) return null;
        java.util.Calendar cal = java.util.Calendar.getInstance();
        if (year < 0) year = cal.get(java.util.Calendar.YEAR);
        if (month < 0) month = 0;
        cal.set(year, month, day > 0 ? day : 1, 0, 0, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        long start = cal.getTimeInMillis();
        if (day > 0) cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
        else if (month >= 0 && q.contains(months[month])) cal.add(java.util.Calendar.MONTH, 1);
        else cal.add(java.util.Calendar.YEAR, 1);
        return new Long[]{start, cal.getTimeInMillis()};
    }

    public static boolean deleteItem(Context c, MediaItem m) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                // direct delete needs user consent via createDeleteRequest; caller handles that.
                // Here: use trash instead (createTrashRequest) - handled by TrashHelper.
                return false;
            }
            return c.getContentResolver().delete(m.uri, null, null) > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static Map<String, List<MediaItem>> groupByDay(List<MediaItem> all) {
        Map<String, List<MediaItem>> map = new LinkedHashMap<String, List<MediaItem>>();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        for (MediaItem m : all) {
            String day = f.format(new Date(m.dateTaken));
            List<MediaItem> l = map.get(day);
            if (l == null) { l = new ArrayList<MediaItem>(); map.put(day, l); }
            l.add(m);
        }
        return map;
    }
}
