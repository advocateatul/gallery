package io.github.advocateatul.gallery.ui;

import androidx.appcompat.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.util.MediaActions;
import io.github.advocateatul.gallery.util.ThumbLoader;
import io.github.advocateatul.gallery.util.UiUtils;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ViewerActivity extends AppCompatActivity {
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private ViewPager2 pager;
    private TextView titleView;
    private ImageButton btnFav;
    private View topBar, bottomBar, videoBar;
    private SeekBar seek;
    private TextView timeView;
    private ImageButton btnPlay;
    private VideoView currentVideo;
    private Handler handler = new Handler();
    private boolean chromeVisible = true;
    private boolean slideshow = false;
    private Runnable slideshowTask;
    private Runnable seekTask;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_viewer);
        items = getIntent().getParcelableArrayListExtra("items");
        if (items == null) items = new ArrayList<MediaItem>();
        int pos = getIntent().getIntExtra("position", 0);
        pager = findViewById(R.id.pager);
        titleView = findViewById(R.id.title);
        btnFav = findViewById(R.id.btn_fav);
        topBar = findViewById(R.id.top_bar);
        bottomBar = findViewById(R.id.bottom_bar);
        videoBar = findViewById(R.id.video_bar);
        seek = findViewById(R.id.seek);
        timeView = findViewById(R.id.time);
        btnPlay = findViewById(R.id.btn_play);
        pager.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return items.size(); }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View v = LayoutInflater.from(p.getContext()).inflate(R.layout.page_viewer, p, false);
                return new RecyclerView.ViewHolder(v) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int position) {
                final MediaItem m = items.get(position);
                final ZoomImageView img = h.itemView.findViewById(R.id.image);
                final VideoView vv = h.itemView.findViewById(R.id.video);
                final ImageView bigPlay = h.itemView.findViewById(R.id.video_play_big);
                final ProgressBar prog = h.itemView.findViewById(R.id.progress);
                img.setOnSingleTapListener(new ZoomImageView.OnSingleTapListener() {
                    @Override public void onSingleTap() { toggleChrome(); }
                });
                vv.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { toggleChrome(); }
                });
                if (m.isVideo) {
                    img.setVisibility(View.GONE);
                    vv.setVisibility(View.VISIBLE);
                    bigPlay.setVisibility(View.VISIBLE);
                    prog.setVisibility(View.VISIBLE);
                    vv.setVideoURI(m.uri);
                    vv.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
                        @Override public void onPrepared(android.media.MediaPlayer mp) {
                            prog.setVisibility(View.GONE);
                            seek.setMax(mp.getDuration());
                            updateTime(0, mp.getDuration());
                        }
                    });
                    bigPlay.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            bigPlay.setVisibility(View.GONE);
                            vv.start();
                            btnPlay.setImageResource(R.drawable.ic_pause);
                            startSeekUpdates(vv);
                        }
                    });
                } else {
                    vv.setVisibility(View.GONE);
                    bigPlay.setVisibility(View.GONE);
                    img.setVisibility(View.VISIBLE);
                    prog.setVisibility(View.VISIBLE);
                    new Thread(new Runnable() {
                        @Override public void run() {
                            final Bitmap b = ThumbLoader.loadFull(ViewerActivity.this, m.uri, 2048);
                            runOnUiThread(new Runnable() {
                                @Override public void run() {
                                    prog.setVisibility(View.GONE);
                                    if (b != null) img.setImageBitmap(b);
                                    else UiUtils.toast(ViewerActivity.this, R.string.error_load);
                                }
                            });
                        }
                    }).start();
                }
            }
            @Override public void onViewRecycled(RecyclerView.ViewHolder h) {
                VideoView vv = h.itemView.findViewById(R.id.video);
                if (vv != null && vv.isPlaying()) vv.stopPlayback();
                ZoomImageView img = h.itemView.findViewById(R.id.image);
                if (img != null) { img.setImageDrawable(null); img.resetZoom(); }
                super.onViewRecycled(h);
            }
        });
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int position) {
                stopVideo();
                updateTitle(position);
                updateVideoBar(position);
            }
        });
        pager.setCurrentItem(pos, false);
        updateTitle(pos);
        updateVideoBar(pos);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        btnFav.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleFavorite(); }
        });
        findViewById(R.id.btn_share).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ArrayList<MediaItem> one = new ArrayList<MediaItem>();
                one.add(items.get(pager.getCurrentItem()));
                MediaActions.share(ViewerActivity.this, one);
            }
        });
        findViewById(R.id.btn_delete).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmDelete(); }
        });
        findViewById(R.id.btn_more).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMoreMenu(); }
        });
        findViewById(R.id.btn_edit).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                MediaItem m = items.get(pager.getCurrentItem());
                if (m.isVideo) {
                    Intent i = new Intent(ViewerActivity.this, VideoTrimActivity.class);
                    i.putExtra("item", m);
                    startActivity(i);
                } else {
                    Intent i = new Intent(ViewerActivity.this, EditorActivity.class);
                    i.putExtra("item", m);
                    startActivity(i);
                }
            }
        });
        findViewById(R.id.btn_details).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDetails(); }
        });
        findViewById(R.id.btn_slideshow).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleSlideshow(); }
        });
        findViewById(R.id.btn_wallpaper).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setWallpaper(); }
        });
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { togglePlayPause(); }
        });
        findViewById(R.id.btn_trim).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                MediaItem m = items.get(pager.getCurrentItem());
                Intent i = new Intent(ViewerActivity.this, VideoTrimActivity.class);
                i.putExtra("item", m);
                startActivity(i);
            }
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser && currentVideo != null) currentVideo.seekTo(p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
    }

    private MediaItem current() {
        return items.get(pager.getCurrentItem());
    }

    private void updateTitle(int pos) {
        MediaItem m = items.get(pos);
        titleView.setText(m.name != null ? m.name : "");
        btnFav.setImageResource(m.favorite ? R.drawable.ic_fav : R.drawable.ic_fav);
        btnFav.setColorFilter(m.favorite
                ? getResources().getColor(R.color.oneui_red)
                : getResources().getColor(R.color.oneui_text));
    }

    private void updateVideoBar(int pos) {
        boolean video = items.get(pos).isVideo;
        videoBar.setVisibility(video && chromeVisible ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(video ? View.GONE : (chromeVisible ? View.VISIBLE : View.GONE));
        if (video) {
            if (pager.getChildCount() > 0 && pager.getChildAt(0) instanceof RecyclerView) {
                RecyclerView rv = (RecyclerView) pager.getChildAt(0);
                RecyclerView.ViewHolder h = rv.findViewHolderForAdapterPosition(pos);
                if (h != null) {
                    currentVideo = h.itemView.findViewById(R.id.video);
                }
            }
        }
    }

    private void toggleChrome() {
        chromeVisible = !chromeVisible;
        topBar.setVisibility(chromeVisible ? View.VISIBLE : View.GONE);
        MediaItem m = current();
        if (m.isVideo) {
            videoBar.setVisibility(chromeVisible ? View.VISIBLE : View.GONE);
            bottomBar.setVisibility(View.GONE);
        } else {
            bottomBar.setVisibility(chromeVisible ? View.VISIBLE : View.GONE);
            videoBar.setVisibility(View.GONE);
        }
    }

    private void toggleFavorite() {
        MediaItem m = current();
        GalleryDb db = GalleryDb.get(this);
        if (m.favorite) { db.removeFavorite(m); m.favorite = false; UiUtils.toast(this, R.string.fav_removed); }
        else { db.addFavorite(m); m.favorite = true; UiUtils.toast(this, R.string.fav_added); }
        updateTitle(pager.getCurrentItem());
    }

    private void confirmDelete() {
        final MediaItem m = current();
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.action_delete)
                .setMessage(R.string.trash_delete_msg)
                .setPositiveButton(R.string.action_delete, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        ArrayList<MediaItem> one = new ArrayList<MediaItem>();
                        one.add(m);
                        MediaActions.moveToTrash(ViewerActivity.this, one, new MediaActions.Done() {
                            @Override public void run(boolean ok) {
                                if (ok) {
                                    UiUtils.toast(ViewerActivity.this, R.string.trash_moved);
                                    items.remove(m);
                                    pager.getAdapter().notifyDataSetChanged();
                                    if (items.isEmpty()) finish();
                                }
                            }
                        });
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void showMoreMenu() {
        final MediaItem m = current();
        final String[] opts = {
                getString(R.string.action_move_secure),
                getString(R.string.action_details),
                getString(R.string.action_slideshow)
        };
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setItems(opts, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            new Thread(new Runnable() {
                                @Override public void run() {
                                    final boolean ok = MediaActions.moveToSecure(ViewerActivity.this, m);
                                    runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            if (ok) {
                                                UiUtils.toast(ViewerActivity.this, R.string.secure_moved);
                                                items.remove(m);
                                                pager.getAdapter().notifyDataSetChanged();
                                                if (items.isEmpty()) finish();
                                            }
                                        }
                                    });
                                }
                            }).start();
                        } else if (which == 1) showDetails();
                        else toggleSlideshow();
                    }
                }).show();
    }

    private void showDetails() {
        MediaItem m = current();
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog);
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_details, null);
        LinearLayout rows = v.findViewById(R.id.rows);
        addRow(rows, R.string.detail_name, m.name);
        addRow(rows, R.string.detail_date, UiUtils.fullDate(m.dateTaken));
        addRow(rows, R.string.detail_size, UiUtils.formatSize(m.size));
        addRow(rows, R.string.detail_resolution, m.width + " × " + m.height);
        addRow(rows, R.string.detail_album, m.bucket);
        addRow(rows, R.string.detail_path, m.path);
        addRow(rows, R.string.detail_type, m.mime);
        if (m.isVideo) addRow(rows, R.string.detail_duration, UiUtils.formatDuration(m.duration));
        if (m.hasLocation()) {
            addRow(rows, R.string.detail_location,
                    String.format(java.util.Locale.US, "%.5f, %.5f", m.lat, m.lng));
        }
        b.setView(v).setTitle(R.string.action_details)
                .setPositiveButton(R.string.action_ok, null).show();
    }

    private void addRow(LinearLayout root, int labelRes, String value) {
        if (value == null) value = "";
        View row = LayoutInflater.from(this).inflate(R.layout.item_row, root, false);
        ((TextView) row.findViewById(R.id.label)).setText(labelRes);
        ((TextView) row.findViewById(R.id.label)).setTextColor(getResources().getColor(R.color.oneui_text2));
        ((ImageView) row.findViewById(R.id.icon)).setVisibility(View.GONE);
        TextView val = row.findViewById(R.id.value);
        val.setText(value);
        val.setTextColor(getResources().getColor(R.color.oneui_text));
        val.setMaxLines(3);
        root.addView(row);
    }

    private void toggleSlideshow() {
        slideshow = !slideshow;
        if (slideshow) {
            UiUtils.toast(this, R.string.slideshow_on);
            slideshowTask = new Runnable() {
                @Override public void run() {
                    if (!slideshow) return;
                    int next = (pager.getCurrentItem() + 1) % items.size();
                    pager.setCurrentItem(next, true);
                    handler.postDelayed(this, GalleryApp.slideshowMs(ViewerActivity.this));
                }
            };
            handler.postDelayed(slideshowTask, GalleryApp.slideshowMs(this));
        } else {
            handler.removeCallbacks(slideshowTask);
        }
    }

    private void setWallpaper() {
        final MediaItem m = current();
        if (m.isVideo) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    InputStream in = getContentResolver().openInputStream(m.uri);
                    final Bitmap b = BitmapFactory.decodeStream(in);
                    in.close();
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            try {
                                WallpaperManager.getInstance(ViewerActivity.this).setBitmap(b);
                                UiUtils.toast(ViewerActivity.this, R.string.wallpaper_set);
                            } catch (Exception e) {
                                UiUtils.toast(ViewerActivity.this, R.string.edit_save_failed);
                            }
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { UiUtils.toast(ViewerActivity.this, R.string.edit_save_failed); }
                    });
                }
            }
        }).start();
    }

    private void togglePlayPause() {
        if (currentVideo == null) return;
        if (currentVideo.isPlaying()) {
            currentVideo.pause();
            btnPlay.setImageResource(R.drawable.ic_play);
        } else {
            currentVideo.start();
            btnPlay.setImageResource(R.drawable.ic_pause);
            startSeekUpdates(currentVideo);
        }
    }

    private void startSeekUpdates(final VideoView vv) {
        currentVideo = vv;
        if (seekTask != null) handler.removeCallbacks(seekTask);
        seekTask = new Runnable() {
            @Override public void run() {
                if (vv.isPlaying()) {
                    seek.setProgress(vv.getCurrentPosition());
                    updateTime(vv.getCurrentPosition(), vv.getDuration());
                    handler.postDelayed(this, 500);
                }
            }
        };
        handler.post(seekTask);
    }

    private void updateTime(int cur, int dur) {
        timeView.setText(UiUtils.formatDuration(cur) + " / " + UiUtils.formatDuration(dur));
    }

    private void stopVideo() {
        if (currentVideo != null && currentVideo.isPlaying()) currentVideo.pause();
        if (seekTask != null) handler.removeCallbacks(seekTask);
        btnPlay.setImageResource(R.drawable.ic_play);
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopVideo();
        slideshow = false;
        if (slideshowTask != null) handler.removeCallbacks(slideshowTask);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MediaActions.REQ_TRASH) {
            if (resultCode == RESULT_OK) MediaActions.noteTrash(this);
            else MediaActions.cancelTrash();
        }
    }
}
