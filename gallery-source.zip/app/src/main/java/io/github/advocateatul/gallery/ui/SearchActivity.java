package io.github.advocateatul.gallery.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    private EditText query;
    private RecyclerView results;
    private View empty;
    private MediaGridAdapter adapter;
    private Handler handler = new Handler();
    private String typeFilter = null;
    private List<MediaItem> current = new ArrayList<MediaItem>();
    private Runnable searchTask;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_search);
        query = findViewById(R.id.query);
        results = findViewById(R.id.results);
        empty = findViewById(R.id.empty);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        GridLayoutManager lm = new GridLayoutManager(this, 3);
        lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER
                        ? 3 : 1;
            }
        });
        results.setLayoutManager(lm);
        adapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {
                Intent i = new Intent(SearchActivity.this, ViewerActivity.class);
                i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(current));
                i.putExtra("position", position);
                startActivity(i);
            }
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {}
        });
        results.setAdapter(adapter);
        // chips
        LinearLayout chips = findViewById(R.id.chips);
        addChip(chips, R.string.search_photos, "photo");
        addChip(chips, R.string.search_videos, "video");
        addChip(chips, R.string.search_by_location, "location");
        query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { scheduleSearch(); }
        });
        query.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) { runSearch(); return true; }
                return false;
            }
        });
        query.requestFocus();
    }

    private void addChip(LinearLayout chips, int labelRes, final String filter) {
        final TextView chip = (TextView) LayoutInflater.from(this).inflate(R.layout.item_chip, chips, false);
        chip.setText(labelRes);
        chip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (filter.equals(typeFilter)) {
                    typeFilter = null;
                    chip.setBackgroundResource(R.drawable.bg_chip);
                } else {
                    typeFilter = filter;
                    for (int i = 0; i < chips.getChildCount(); i++) {
                        chips.getChildAt(i).setBackgroundResource(R.drawable.bg_chip);
                    }
                    chip.setBackgroundResource(R.drawable.bg_chip_selected);
                }
                runSearch();
            }
        });
        chips.addView(chip);
    }

    private void scheduleSearch() {
        if (searchTask != null) handler.removeCallbacks(searchTask);
        searchTask = new Runnable() {
            @Override public void run() { runSearch(); }
        };
        handler.postDelayed(searchTask, 300);
    }

    private void runSearch() {
        final String q = query.getText().toString();
        final String tf = typeFilter;
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> found = MediaRepo.search(SearchActivity.this, q, tf);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        current = found;
                        empty.setVisibility(found.isEmpty() ? View.VISIBLE : View.GONE);
                        adapter.setItems(found, false);
                    }
                });
            }
        }).start();
    }
}
