package io.github.advocateatul.gallery.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class EditCanvasView extends View {
    public static final int MODE_NONE = 0;
    public static final int MODE_CROP = 1;
    public static final int MODE_DRAW = 2;
    public static final int MODE_ERASER = 3;
    public static final int MODE_TEXT = 4;
    public static final int MODE_STICKER = 5;

    public static class Stroke {
        Path path = new Path();
        int color;
        float width;
        boolean eraser;
    }
    public static class OverlayText {
        String text;
        float x, y; // bitmap coords
        float size;
        int color;
        boolean emoji;
    }

    private Bitmap bitmap;
    private Matrix imgMatrix = new Matrix();
    private Matrix invMatrix = new Matrix();
    private RectF imgRect = new RectF();
    private int mode = MODE_NONE;
    private List<Stroke> strokes = new ArrayList<Stroke>();
    private List<OverlayText> texts = new ArrayList<OverlayText>();
    private Stroke currentStroke;
    private Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private Paint cropPaint = new Paint();
    private Paint handlePaint = new Paint();
    private Paint maskPaint = new Paint();
    private RectF cropRect = new RectF(); // view coords
    private float aspect = 0; // 0 = free
    private int activeHandle = -1; // 0..3 corners
    private PointF lastTouch = new PointF();
    private int drawColor = Color.WHITE;
    private float drawWidth = 14f;
    private String pendingText;
    private int pendingTextColor = Color.WHITE;
    private float pendingTextSize = 64f;
    private String pendingEmoji;
    private OnTapListener tapListener;

    public interface OnTapListener { void onTap(float bitmapX, float bitmapY); }

    public EditCanvasView(Context c) { super(c); init(); }
    public EditCanvasView(Context c, AttributeSet a) { super(c, a); init(); }
    public EditCanvasView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        cropPaint.setColor(Color.WHITE);
        cropPaint.setStyle(Paint.Style.STROKE);
        cropPaint.setStrokeWidth(3f);
        handlePaint.setColor(Color.WHITE);
        handlePaint.setStyle(Paint.Style.FILL);
        maskPaint.setColor(Color.argb(140, 255, 0, 0));
        maskPaint.setStyle(Paint.Style.STROKE);
        maskPaint.setStrokeWidth(28f);
        maskPaint.setStrokeCap(Paint.Cap.ROUND);
        maskPaint.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setOnTapListener(OnTapListener l) { tapListener = l; }
    public void setMode(int m) { mode = m; if (m == MODE_CROP) resetCropRect(); invalidate(); }
    public int getMode() { return mode; }
    public void setDrawColor(int c) { drawColor = c; }
    public void setAspect(float a) { aspect = a; resetCropRect(); invalidate(); }
    public void setPendingText(String t, int color, float size) { pendingText = t; pendingTextColor = color; pendingTextSize = size; }
    public void setPendingEmoji(String e) { pendingEmoji = e; }
    public List<Stroke> getStrokes() { return strokes; }
    public List<OverlayText> getTexts() { return texts; }
    public void clearOverlays() { strokes.clear(); texts.clear(); invalidate(); }
    public void undoStroke() {
        if (!strokes.isEmpty()) strokes.remove(strokes.size() - 1);
        else if (!texts.isEmpty()) texts.remove(texts.size() - 1);
        invalidate();
    }

    public void setBitmap(Bitmap b) {
        bitmap = b;
        strokes.clear();
        texts.clear();
        computeMatrix();
        resetCropRect();
        invalidate();
    }
    public Bitmap getBitmap() { return bitmap; }

    private void computeMatrix() {
        if (bitmap == null || getWidth() == 0) return;
        float scale = Math.min((float) getWidth() / bitmap.getWidth(), (float) getHeight() / bitmap.getHeight());
        imgMatrix.reset();
        imgMatrix.postScale(scale, scale);
        imgMatrix.postTranslate((getWidth() - bitmap.getWidth() * scale) / 2f,
                (getHeight() - bitmap.getHeight() * scale) / 2f);
        imgMatrix.invert(invMatrix);
        imgRect.set(0, 0, bitmap.getWidth(), bitmap.getHeight());
        imgMatrix.mapRect(imgRect);
    }

    private void resetCropRect() {
        if (bitmap == null) return;
        cropRect.set(imgRect);
        cropRect.inset(imgRect.width() * 0.08f, imgRect.height() * 0.08f);
        if (aspect > 0) applyAspect();
    }

    private void applyAspect() {
        float w = cropRect.width(), h = cropRect.height();
        float cx = cropRect.centerX(), cy = cropRect.centerY();
        if (w / h > aspect) {
            float nw = h * aspect;
            cropRect.set(cx - nw / 2, cropRect.top, cx + nw / 2, cropRect.bottom);
        } else {
            float nh = w / aspect;
            cropRect.set(cropRect.left, cy - nh / 2, cropRect.right, cy + nh / 2);
        }
        // clamp inside image
        if (cropRect.left < imgRect.left) cropRect.offset(imgRect.left - cropRect.left, 0);
        if (cropRect.top < imgRect.top) cropRect.offset(0, imgRect.top - cropRect.top);
        if (cropRect.right > imgRect.right) cropRect.offset(imgRect.right - cropRect.right, 0);
        if (cropRect.bottom > imgRect.bottom) cropRect.offset(0, imgRect.bottom - cropRect.bottom);
    }

    public RectF getCropRectBitmap() {
        if (bitmap == null) return null;
        float[] pts = {cropRect.left, cropRect.top, cropRect.right, cropRect.bottom};
        invMatrix.mapPoints(pts);
        RectF r = new RectF(Math.max(0, pts[0]), Math.max(0, pts[1]),
                Math.min(bitmap.getWidth(), pts[2]), Math.min(bitmap.getHeight(), pts[3]));
        return r;
    }

    public Bitmap buildEraseMask() {
        if (bitmap == null) return null;
        Bitmap mask = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(mask);
        c.drawColor(Color.BLACK);
        Paint p = new Paint();
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        float scale = imgRect.width() / bitmap.getWidth();
        for (Stroke s : strokes) {
            if (!s.eraser) continue;
            p.setStrokeWidth(s.width / scale * 2.2f);
            Path bp = new Path();
            s.path.transform(imgMatrix, bp);
            // transform path from view coords to bitmap coords: use inverse
            Path bmpPath = new Path();
            bp.transform(invMatrix, bmpPath);
            c.drawPath(bmpPath, p);
        }
        return mask;
    }

    public void removeEraserStrokes() {
        List<Stroke> keep = new ArrayList<Stroke>();
        for (Stroke s : strokes) if (!s.eraser) keep.add(s);
        strokes = keep;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        computeMatrix();
        if (mode == MODE_CROP) resetCropRect();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap == null) return;
        canvas.drawBitmap(bitmap, imgMatrix, bmpPaint);
        float scale = imgRect.width() / bitmap.getWidth();
        // overlays
        for (Stroke s : strokes) {
            Paint p = new Paint();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setAntiAlias(true);
            if (s.eraser) {
                p.setColor(Color.argb(140, 255, 0, 0));
                p.setStrokeWidth(s.width * 2.2f);
            } else {
                p.setColor(s.color);
                p.setStrokeWidth(s.width);
            }
            canvas.drawPath(s.path, p);
        }
        for (OverlayText t : texts) {
            Paint p = new Paint();
            p.setColor(t.color);
            p.setTextSize(t.size * scale);
            p.setAntiAlias(true);
            p.setTextAlign(Paint.Align.CENTER);
            float[] pt = {t.x, t.y};
            imgMatrix.mapPoints(pt);
            canvas.drawText(t.text, pt[0], pt[1], p);
        }
        if (mode == MODE_CROP) {
            // dim outside crop
            Paint dim = new Paint();
            dim.setColor(Color.argb(140, 0, 0, 0));
            canvas.drawRect(0, 0, getWidth(), cropRect.top, dim);
            canvas.drawRect(0, cropRect.bottom, getWidth(), getHeight(), dim);
            canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, dim);
            canvas.drawRect(cropRect.right, cropRect.top, getWidth(), cropRect.bottom, dim);
            canvas.drawRect(cropRect, cropPaint);
            // thirds grid
            Paint grid = new Paint();
            grid.setColor(Color.argb(120, 255, 255, 255));
            grid.setStrokeWidth(1f);
            float cw = cropRect.width() / 3f, ch = cropRect.height() / 3f;
            canvas.drawLine(cropRect.left + cw, cropRect.top, cropRect.left + cw, cropRect.bottom, grid);
            canvas.drawLine(cropRect.left + 2 * cw, cropRect.top, cropRect.left + 2 * cw, cropRect.bottom, grid);
            canvas.drawLine(cropRect.left, cropRect.top + ch, cropRect.right, cropRect.top + ch, grid);
            canvas.drawLine(cropRect.left, cropRect.top + 2 * ch, cropRect.right, cropRect.top + 2 * ch, grid);
            // handles
            float r = 14f;
            float[][] corners = {{cropRect.left, cropRect.top}, {cropRect.right, cropRect.top},
                    {cropRect.left, cropRect.bottom}, {cropRect.right, cropRect.bottom}};
            for (float[] c : corners) canvas.drawCircle(c[0], c[1], r, handlePaint);
        }
    }

    private int handleAt(float x, float y) {
        float[][] corners = {{cropRect.left, cropRect.top}, {cropRect.right, cropRect.top},
                {cropRect.left, cropRect.bottom}, {cropRect.right, cropRect.bottom}};
        for (int i = 0; i < 4; i++) {
            if (Math.abs(x - corners[i][0]) < 44 && Math.abs(y - corners[i][1]) < 44) return i;
        }
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        if (mode == MODE_CROP) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    activeHandle = handleAt(x, y);
                    lastTouch.set(x, y);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (activeHandle >= 0) {
                        float dx = x - lastTouch.x, dy = y - lastTouch.y;
                        switch (activeHandle) {
                            case 0: cropRect.left += dx; cropRect.top += dy; break;
                            case 1: cropRect.right += dx; cropRect.top += dy; break;
                            case 2: cropRect.left += dx; cropRect.bottom += dy; break;
                            case 3: cropRect.right += dx; cropRect.bottom += dy; break;
                        }
                        if (cropRect.width() < 80) cropRect.right = cropRect.left + 80;
                        if (cropRect.height() < 80) cropRect.bottom = cropRect.top + 80;
                        cropRect.left = Math.max(imgRect.left, cropRect.left);
                        cropRect.top = Math.max(imgRect.top, cropRect.top);
                        cropRect.right = Math.min(imgRect.right, cropRect.right);
                        cropRect.bottom = Math.min(imgRect.bottom, cropRect.bottom);
                        if (aspect > 0) applyAspect();
                        lastTouch.set(x, y);
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    activeHandle = -1;
                    return true;
            }
            return true;
        }
        if (mode == MODE_DRAW || mode == MODE_ERASER) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    currentStroke = new Stroke();
                    currentStroke.color = drawColor;
                    currentStroke.width = drawWidth;
                    currentStroke.eraser = (mode == MODE_ERASER);
                    currentStroke.path.moveTo(x, y);
                    strokes.add(currentStroke);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (currentStroke != null) {
                        currentStroke.path.lineTo(x, y);
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    currentStroke = null;
                    return true;
            }
            return true;
        }
        if (mode == MODE_TEXT || mode == MODE_STICKER) {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                float[] pt = {x, y};
                invMatrix.mapPoints(pt);
                if (mode == MODE_TEXT && pendingText != null) {
                    OverlayText t = new OverlayText();
                    t.text = pendingText;
                    t.x = pt[0]; t.y = pt[1];
                    t.size = pendingTextSize;
                    t.color = pendingTextColor;
                    t.emoji = false;
                    texts.add(t);
                    pendingText = null;
                    invalidate();
                } else if (mode == MODE_STICKER && pendingEmoji != null) {
                    OverlayText t = new OverlayText();
                    t.text = pendingEmoji;
                    t.x = pt[0]; t.y = pt[1];
                    t.size = 160f;
                    t.color = Color.WHITE;
                    t.emoji = true;
                    texts.add(t);
                    invalidate();
                }
                if (tapListener != null) tapListener.onTap(pt[0], pt[1]);
            }
            return true;
        }
        return super.onTouchEvent(e);
    }

    // compose base + overlays into a full-resolution bitmap
    public Bitmap exportBitmap() {
        if (bitmap == null) return null;
        Bitmap out = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(out);
        float scale = (float) out.getWidth() / bitmap.getWidth();
        for (Stroke s : strokes) {
            if (s.eraser) continue;
            Paint p = new Paint();
            p.setColor(s.color);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setAntiAlias(true);
            p.setStrokeWidth(s.width / (imgRect.width() / bitmap.getWidth()));
            // stroke path is in view coords: map to bitmap coords
            Path bp = new Path();
            s.path.transform(invMatrix, bp);
            c.drawPath(bp, p);
        }
        for (OverlayText t : texts) {
            Paint p = new Paint();
            p.setColor(t.color);
            p.setTextSize(t.size);
            p.setAntiAlias(true);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(t.text, t.x, t.y, p);
        }
        return out;
    }
}
