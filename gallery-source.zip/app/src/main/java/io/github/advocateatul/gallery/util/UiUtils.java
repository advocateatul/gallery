package io.github.advocateatul.gallery.util;

import android.content.Context;
import android.text.format.DateUtils;
import android.util.DisplayMetrics;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class UiUtils {
    public static void toast(Context c, int resId) {
        Toast.makeText(c, resId, Toast.LENGTH_SHORT).show();
    }
    public static void toast(Context c, String msg) {
        Toast.makeText(c, msg, Toast.LENGTH_SHORT).show();
    }
    public static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb);
        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }
    public static String formatDuration(long ms) {
        long s = ms / 1000;
        long m = s / 60;
        s = s % 60;
        if (m >= 60) {
            long h = m / 60;
            m = m % 60;
            return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        }
        return String.format(Locale.US, "%d:%02d", m, s);
    }
    public static String dayHeader(long ms, Context c) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(ms);
        Calendar today = Calendar.getInstance();
        if (sameDay(cal, today)) return c.getString(io.github.advocateatul.gallery.R.string.story_today);
        today.add(Calendar.DAY_OF_YEAR, -1);
        if (sameDay(cal, today)) return c.getString(io.github.advocateatul.gallery.R.string.story_yesterday);
        SimpleDateFormat f = new SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault());
        return f.format(new Date(ms));
    }
    public static String monthHeader(long ms) {
        return new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(new Date(ms));
    }
    public static String fullDate(long ms) {
        return new SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.getDefault()).format(new Date(ms));
    }
    public static String shortDate(long ms) {
        return new SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(new Date(ms));
    }
    public static boolean sameDay(Calendar a, Calendar b) {
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR)
                && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }
    public static boolean sameMonthDay(Calendar a, Calendar b) {
        return a.get(Calendar.MONTH) == b.get(Calendar.MONTH)
                && a.get(Calendar.DAY_OF_MONTH) == b.get(Calendar.DAY_OF_MONTH);
    }
    public static int screenWidth(Context c) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        return dm.widthPixels;
    }
    public static int dp(Context c, int dp) {
        return Math.round(dp * c.getResources().getDisplayMetrics().density);
    }
    public static String relativeTime(long ms) {
        return DateUtils.getRelativeTimeSpanString(ms, System.currentTimeMillis(),
                DateUtils.DAY_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE).toString();
    }
}
