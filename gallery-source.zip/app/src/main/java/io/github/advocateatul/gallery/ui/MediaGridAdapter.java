package io.github.advocateatul.gallery.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.util.ThumbLoader;
import io.github.advocateatul.gallery.util.UiUtils;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MediaGridAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final int TYPE_HEADER = 0;
    public static final int TYPE_PHOTO = 1;

    public interface Listener {
        void onClick(MediaItem item, int position);
        void onLongClick(MediaItem item, int position);
        void onSelectionChanged(int count);
    }

    private Context ctx;
    private List<Object> rows = new ArrayList<Object>(); // String header or MediaItem
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private Set<String> selected = new HashSet<String>();
    private boolean selectionMode = false;
    private Listener listener;
    private int thumbSize = 320;
    private int spanCount = 3;

    public MediaGridAdapter(Context ctx, Listener l) {
        this.ctx = ctx;
        this.listener = l;
    }

    public void setSpanCount(int span) { spanCount = span; }
    public int getSpanCount() { return spanCount; }

    public void setItems(List<MediaItem> list, boolean groupByDay) {
        items = list == null ? new ArrayList<MediaItem>() : list;
        rows.clear();
        selected.clear();
        selectionMode = false;
        String lastHeader = null;
        for (MediaItem m : items) {
            if (groupByDay) {
                String h = UiUtils.dayHeader(m.dateTaken, ctx);
                if (!h.equals(lastHeader)) {
                    rows.add(h);
                    lastHeader = h;
                }
            }
            rows.add(m);
        }
        thumbSize = Math.max(160, UiUtils.screenWidth(ctx) / Math.max(1, spanCount));
        notifyDataSetChanged();
    }

    public List<MediaItem> getItems() { return items; }
    public Set<String> getSelectedKeys() { return selected; }
    public boolean isSelectionMode() { return selectionMode; }

    public List<MediaItem> getSelectedItems() {
        List<MediaItem> out = new ArrayList<MediaItem>();
        for (MediaItem m : items) if (selected.contains(m.key())) out.add(m);
        return out;
    }

    public void clearSelection() {
        selected.clear();
        selectionMode = false;
        notifyDataSetChanged();
        if (listener != null) listener.onSelectionChanged(0);
    }

    public void selectAll() {
        for (MediaItem m : items) selected.add(m.key());
        selectionMode = true;
        notifyDataSetChanged();
        if (listener != null) listener.onSelectionChanged(selected.size());
    }

    public int positionOf(MediaItem item) {
        return rows.indexOf(item);
    }

    @Override public int getItemViewType(int pos) {
        return rows.get(pos) instanceof String ? TYPE_HEADER : TYPE_PHOTO;
    }

    @Override public int getItemCount() { return rows.size(); }

    static class HeaderVH extends RecyclerView.ViewHolder {
        TextView t;
        HeaderVH(View v) { super(v); t = (TextView) v; }
    }
    static class PhotoVH extends RecyclerView.ViewHolder {
        ImageView thumb, play, fav, check;
        TextView duration;
        View dim;
        PhotoVH(View v) {
            super(v);
            thumb = v.findViewById(R.id.thumb);
            play = v.findViewById(R.id.play);
            fav = v.findViewById(R.id.fav);
            check = v.findViewById(R.id.check);
            duration = v.findViewById(R.id.duration);
            dim = v.findViewById(R.id.selected_dim);
        }
    }

    @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            View v = inf.inflate(R.layout.item_header, parent, false);
            return new HeaderVH(v);
        }
        View v = inf.inflate(R.layout.item_photo, parent, false);
        // square cell: height = width (set via layout params in onBind)
        return new PhotoVH(v);
    }

    @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
        if (h instanceof HeaderVH) {
            ((HeaderVH) h).t.setText((String) rows.get(pos));
            return;
        }
        final MediaItem m = (MediaItem) rows.get(pos);
        final PhotoVH vh = (PhotoVH) h;
        ViewGroup.LayoutParams lp = vh.itemView.getLayoutParams();
        int cell = UiUtils.screenWidth(ctx) / Math.max(1, spanCount);
        lp.height = cell;
        vh.itemView.setLayoutParams(lp);
        if (m.thumbFile != null) {
            ThumbLoader.get(ctx).loadFile(vh.thumb, new java.io.File(m.thumbFile), thumbSize);
        } else {
            ThumbLoader.get(ctx).load(vh.thumb, m, thumbSize);
        }
        boolean isSel = selected.contains(m.key());
        vh.check.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
        vh.check.setImageResource(isSel ? R.drawable.ic_check_circle : R.drawable.ic_check_circle);
        vh.check.setAlpha(isSel ? 1f : 0.45f);
        vh.dim.setVisibility(isSel ? View.VISIBLE : View.GONE);
        vh.fav.setVisibility(m.favorite && !selectionMode ? View.VISIBLE : View.GONE);
        if (m.isVideo) {
            vh.play.setVisibility(View.VISIBLE);
            vh.duration.setVisibility(View.VISIBLE);
            vh.duration.setText(UiUtils.formatDuration(m.duration));
        } else {
            vh.play.setVisibility(View.GONE);
            vh.duration.setVisibility(View.GONE);
        }
        vh.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (selectionMode) {
                    toggle(m);
                } else if (listener != null) {
                    listener.onClick(m, items.indexOf(m));
                }
            }
        });
        vh.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (!selectionMode) {
                    selectionMode = true;
                    selected.add(m.key());
                    notifyDataSetChanged();
                    if (listener != null) listener.onSelectionChanged(selected.size());
                } else if (listener != null) {
                    listener.onLongClick(m, items.indexOf(m));
                }
                return true;
            }
        });
    }

    private void toggle(MediaItem m) {
        if (selected.contains(m.key())) selected.remove(m.key());
        else selected.add(m.key());
        if (selected.isEmpty()) selectionMode = false;
        notifyDataSetChanged();
        if (listener != null) listener.onSelectionChanged(selected.size());
    }

    @Override public void onViewRecycled(RecyclerView.ViewHolder h) {
        super.onViewRecycled(h);
        if (h instanceof PhotoVH) {
            ((PhotoVH) h).thumb.setImageBitmap(null);
        }
    }
}
