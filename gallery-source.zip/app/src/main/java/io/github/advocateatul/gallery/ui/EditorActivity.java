package io.github.advocateatul.gallery.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.util.ImageUtils;
import io.github.advocateatul.gallery.util.ThumbLoader;
import io.github.advocateatul.gallery.util.UiUtils;

public class EditorActivity extends AppCompatActivity {
    private EditCanvasView canvas;
    private LinearLayout panel, optionsRow;
    private TextView panelLabel, panelHint;
    private SeekBar slider;
    private MediaItem item;
    private Bitmap baseBitmap;      // geometry-applied
    private Bitmap displayBitmap;   // base + filter + adjust
    private String filterName = "original";
    // adjust: 0 brightness, 1 contrast, 2 saturation, 3 warmth, 4 highlights, 5 shadows, 6 sharpness
    private int[] adj = {0, 100, 100, 100, 0, 0, 0};
    private int currentAdjust = 0;
    private int currentTool = -1;
    private Handler handler = new Handler();
    private long lastRecompute = 0;
    private int recomputeGen = 0;

    private static class Tool {
        int icon, labelRes, id;
        Tool(int icon, int labelRes, int id) { this.icon = icon; this.labelRes = labelRes; this.id = id; }
    }
    private static final int T_CROP = 1, T_ROTATE = 2, T_FLIP = 3, T_FILTERS = 4, T_ADJUST = 5,
            T_DRAW = 6, T_TEXT = 7, T_STICKERS = 8, T_COLLAGE = 9, T_ENHANCE = 10, T_ERASER = 11;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_editor);
        item = getIntent().getParcelableExtra("item");
        canvas = findViewById(R.id.canvas);
        panel = findViewById(R.id.panel);
        optionsRow = findViewById(R.id.options_row);
        panelLabel = findViewById(R.id.panel_label);
        panelHint = findViewById(R.id.panel_hint);
        slider = findViewById(R.id.slider);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        findViewById(R.id.btn_save).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        canvas.setOnTapListener(new EditCanvasView.OnTapListener() {
            @Override public void onTap(float bx, float by) {
                if (currentTool == T_TEXT) askText();
            }
        });
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser || currentTool != T_ADJUST) return;
                setAdjustValue(p);
                throttledRecompute();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) { recomputeDisplay(); }
        });
        buildTools();
        loadBitmap();
    }

    private void loadBitmap() {
        panelHint.setVisibility(View.VISIBLE);
        panelHint.setText(R.string.loading);
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap b = ThumbLoader.loadFull(EditorActivity.this, item.uri, 1600);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        panelHint.setVisibility(View.GONE);
                        if (b == null) {
                            UiUtils.toast(EditorActivity.this, R.string.error_load);
                            finish();
                            return;
                        }
                        baseBitmap = b;
                        recomputeDisplay();
                    }
                });
            }
        }).start();
    }

    private void buildTools() {
        final Tool[] tools = {
                new Tool(R.drawable.ic_crop, R.string.edit_crop, T_CROP),
                new Tool(R.drawable.ic_rotate, R.string.edit_rotate, T_ROTATE),
                new Tool(R.drawable.ic_flip, R.string.edit_flip, T_FLIP),
                new Tool(R.drawable.ic_filter, R.string.edit_filters, T_FILTERS),
                new Tool(R.drawable.ic_adjust, R.string.edit_adjust, T_ADJUST),
                new Tool(R.drawable.ic_draw, R.string.edit_draw, T_DRAW),
                new Tool(R.drawable.ic_text, R.string.edit_text, T_TEXT),
                new Tool(R.drawable.ic_sticker, R.string.edit_stickers, T_STICKERS),
                new Tool(R.drawable.ic_collage, R.string.edit_collage, T_COLLAGE),
                new Tool(R.drawable.ic_magic, R.string.edit_enhance, T_ENHANCE),
                new Tool(R.drawable.ic_eraser, R.string.edit_eraser, T_ERASER),
        };
        RecyclerView rv = findViewById(R.id.tools);
        rv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rv.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return tools.length; }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_tool, p, false);
                return new RecyclerView.ViewHolder(v) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                final Tool tool = tools[pos];
                ((ImageView) h.itemView.findViewById(R.id.icon)).setImageResource(tool.icon);
                TextView label = h.itemView.findViewById(R.id.label);
                label.setText(tool.labelRes);
                boolean active = tool.id == currentTool;
                label.setTextColor(getResources().getColor(active ? R.color.oneui_accent : R.color.oneui_text));
                ((ImageView) h.itemView.findViewById(R.id.icon)).setColorFilter(
                        getResources().getColor(active ? R.color.oneui_accent : R.color.oneui_text));
                h.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { onTool(tool.id); }
                });
            }
        });
    }

    private void refreshTools() {
        RecyclerView rv = findViewById(R.id.tools);
        if (rv.getAdapter() != null) rv.getAdapter().notifyDataSetChanged();
    }

    private void onTool(int id) {
        currentTool = id;
        refreshTools();
        hidePanel();
        canvas.setMode(EditCanvasView.MODE_NONE);
        switch (id) {
            case T_CROP:
                canvas.setMode(EditCanvasView.MODE_CROP);
                showCropPanel();
                break;
            case T_ROTATE:
                showRotatePanel();
                break;
            case T_FLIP:
                showFlipPanel();
                break;
            case T_FILTERS:
                showFilterPanel();
                break;
            case T_ADJUST:
                currentAdjust = 0;
                showAdjustPanel();
                break;
            case T_DRAW:
                canvas.setMode(EditCanvasView.MODE_DRAW);
                showDrawPanel();
                break;
            case T_TEXT:
                canvas.setMode(EditCanvasView.MODE_TEXT);
                askText();
                break;
            case T_STICKERS:
                canvas.setMode(EditCanvasView.MODE_STICKER);
                showStickerPanel();
                break;
            case T_COLLAGE:
                startActivity(new Intent(this, CollageActivity.class));
                break;
            case T_ENHANCE:
                applyEnhance();
                break;
            case T_ERASER:
                canvas.setMode(EditCanvasView.MODE_ERASER);
                showEraserPanel();
                break;
        }
    }

    private void hidePanel() {
        panel.setVisibility(View.GONE);
        panelHint.setVisibility(View.GONE);
        optionsRow.removeAllViews();
    }

    private void showPanel(String label) {
        panel.setVisibility(View.VISIBLE);
        panelLabel.setText(label);
        slider.setVisibility(View.GONE);
    }

    private TextView chip(String text) {
        TextView c = (TextView) LayoutInflater.from(this).inflate(R.layout.item_chip, optionsRow, false);
        c.setText(text);
        return c;
    }

    private void showCropPanel() {
        showPanel(getString(R.string.edit_crop));
        final String[] ratios = {"Free", "1:1", "4:3", "16:9"};
        final float[] vals = {0f, 1f, 4f / 3f, 16f / 9f};
        for (int i = 0; i < ratios.length; i++) {
            final float ratio = vals[i];
            TextView c = chip(ratios[i]);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { canvas.setAspect(ratio); }
            });
            optionsRow.addView(c);
        }
        TextView apply = chip(getString(R.string.action_done));
        apply.setBackgroundResource(R.drawable.bg_chip_selected);
        apply.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyCrop(); }
        });
        optionsRow.addView(apply);
    }

    private void applyCrop() {
        if (baseBitmap == null) return;
        RectF r = canvas.getCropRectBitmap();
        if (r == null || r.width() < 10 || r.height() < 10) return;
        Bitmap cropped = Bitmap.createBitmap(baseBitmap,
                (int) r.left, (int) r.top, (int) r.width(), (int) r.height());
        baseBitmap = cropped;
        canvas.clearOverlays();
        canvas.setMode(EditCanvasView.MODE_NONE);
        hidePanel();
        recomputeDisplay();
    }

    private void showRotatePanel() {
        showPanel(getString(R.string.edit_rotate));
        TextView left = chip("⟲ 90°");
        left.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                baseBitmap = ImageUtils.rotate(baseBitmap, -90);
                recomputeDisplay();
            }
        });
        TextView right = chip("⟳ 90°");
        right.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                baseBitmap = ImageUtils.rotate(baseBitmap, 90);
                recomputeDisplay();
            }
        });
        optionsRow.addView(left);
        optionsRow.addView(right);
    }

    private void showFlipPanel() {
        showPanel(getString(R.string.edit_flip));
        TextView h = chip("⇄");
        h.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                baseBitmap = ImageUtils.flipH(baseBitmap);
                recomputeDisplay();
            }
        });
        TextView v = chip("⇅");
        v.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                baseBitmap = ImageUtils.flipV(baseBitmap);
                recomputeDisplay();
            }
        });
        optionsRow.addView(h);
        optionsRow.addView(v);
    }

    private void showFilterPanel() {
        showPanel(getString(R.string.edit_filters));
        final String[] names = {"original", "vivid", "warm", "cool", "mono", "sepia", "fade", "noir"};
        final int[] labels = {R.string.filter_original, R.string.filter_vivid, R.string.filter_warm,
                R.string.filter_cool, R.string.filter_mono, R.string.filter_sepia,
                R.string.filter_fade, R.string.filter_noir};
        for (int i = 0; i < names.length; i++) {
            final String n = names[i];
            TextView c = chip(getString(labels[i]));
            if (n.equals(filterName)) c.setBackgroundResource(R.drawable.bg_chip_selected);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    filterName = n;
                    recomputeDisplay();
                    showFilterPanel();
                }
            });
            optionsRow.addView(c);
        }
    }

    private void showAdjustPanel() {
        showPanel(getString(R.string.edit_adjust));
        slider.setVisibility(View.VISIBLE);
        final String[] names = {getString(R.string.adj_brightness), getString(R.string.adj_contrast),
                getString(R.string.adj_saturation), getString(R.string.adj_warmth),
                getString(R.string.adj_highlights), getString(R.string.adj_shadows),
                getString(R.string.adj_sharpness)};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView c = chip(names[i]);
            if (idx == currentAdjust) c.setBackgroundResource(R.drawable.bg_chip_selected);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    currentAdjust = idx;
                    showAdjustPanel();
                }
            });
            optionsRow.addView(c);
        }
        syncSlider();
    }

    private void syncSlider() {
        int v = adj[currentAdjust];
        if (currentAdjust == 0 || currentAdjust == 4 || currentAdjust == 5) slider.setProgress(v + 100);
        else if (currentAdjust == 6) slider.setProgress(v * 2);
        else slider.setProgress(v);
        panelLabel.setText(getString(R.string.edit_adjust) + " · " + adjustName(currentAdjust) + ": " + v);
    }

    private String adjustName(int i) {
        int[] res = {R.string.adj_brightness, R.string.adj_contrast, R.string.adj_saturation,
                R.string.adj_warmth, R.string.adj_highlights, R.string.adj_shadows, R.string.adj_sharpness};
        return getString(res[i]);
    }

    private void setAdjustValue(int progress) {
        int v;
        if (currentAdjust == 0 || currentAdjust == 4 || currentAdjust == 5) v = progress - 100;
        else if (currentAdjust == 6) v = progress / 2;
        else v = progress;
        adj[currentAdjust] = v;
        panelLabel.setText(getString(R.string.edit_adjust) + " · " + adjustName(currentAdjust) + ": " + v);
    }

    private void showDrawPanel() {
        showPanel(getString(R.string.edit_draw));
        final int[] colors = {Color.WHITE, Color.BLACK, Color.RED, Color.YELLOW, Color.BLUE, Color.GREEN};
        for (final int c : colors) {
            TextView chip = chip("●");
            chip.setTextColor(c);
            chip.setTextSize(20);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { canvas.setDrawColor(c); }
            });
            optionsRow.addView(chip);
        }
        TextView undo = chip("↩");
        undo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { canvas.undoStroke(); }
        });
        optionsRow.addView(undo);
    }

    private void askText() {
        final EditText input = new EditText(this);
        input.setHint(R.string.text_hint);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.GRAY);
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.edit_text)
                .setView(input)
                .setPositiveButton(R.string.action_done, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        String t = input.getText().toString().trim();
                        if (!t.isEmpty()) {
                            canvas.setPendingText(t, Color.WHITE, 72f);
                            panelHint.setVisibility(View.VISIBLE);
                            panelHint.setText(R.string.text_hint);
                        }
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void showStickerPanel() {
        showPanel(getString(R.string.edit_stickers));
        final String[] emojis = {"\uD83D\uDE00", "\uD83D\uDE0D", "\uD83C\uDF89", "\u2764\uFE0F",
                "\u2B50", "\uD83D\uDD25", "\uD83C\uDF38", "\uD83D\uDC36", "\uD83C\uDF1F", "\uD83D\uDC4D"};
        for (final String e : emojis) {
            TextView c = chip(e);
            c.setTextSize(22);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    canvas.setPendingEmoji(e);
                    panelHint.setVisibility(View.VISIBLE);
                    panelHint.setText(R.string.edit_stickers);
                }
            });
            optionsRow.addView(c);
        }
    }

    private void showEraserPanel() {
        showPanel(getString(R.string.edit_eraser));
        panelHint.setVisibility(View.VISIBLE);
        panelHint.setText(R.string.eraser_hint);
        TextView apply = chip(getString(R.string.eraser_apply));
        apply.setBackgroundResource(R.drawable.bg_chip_selected);
        apply.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyEraser(); }
        });
        optionsRow.addView(apply);
        TextView undo = chip("↩");
        undo.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { canvas.undoStroke(); }
        });
        optionsRow.addView(undo);
    }

    private void applyEraser() {
        if (baseBitmap == null) return;
        panelHint.setText(R.string.loading);
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap mask = canvas.buildEraseMask();
                if (mask == null) return;
                // find bbox of mask
                int w = mask.getWidth(), h = mask.getHeight();
                int[] px = new int[w * h];
                mask.getPixels(px, 0, w, 0, 0, w, h);
                int minX = w, minY = h, maxX = -1, maxY = -1;
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        if (((px[y * w + x] >> 16) & 0xFF) > 128) {
                            if (x < minX) minX = x;
                            if (x > maxX) maxX = x;
                            if (y < minY) minY = y;
                            if (y > maxY) maxY = y;
                        }
                    }
                }
                if (maxX < 0) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { panelHint.setText(R.string.eraser_hint); }
                    });
                    return;
                }
                int pad = 12;
                minX = Math.max(0, minX - pad); minY = Math.max(0, minY - pad);
                maxX = Math.min(w - 1, maxX + pad); maxY = Math.min(h - 1, maxY + pad);
                int rw = maxX - minX + 1, rh = maxY - minY + 1;
                Bitmap region = Bitmap.createBitmap(baseBitmap, minX, minY, rw, rh);
                Bitmap regionMask = Bitmap.createBitmap(mask, minX, minY, rw, rh);
                Bitmap small = ImageUtils.scaleTo(region, 512);
                Bitmap smallMask = ImageUtils.scaleTo(regionMask, 512);
                Bitmap fixed = ImageUtils.inpaint(small, smallMask);
                Bitmap fixedFull = Bitmap.createScaledBitmap(fixed, rw, rh, true);
                android.graphics.Canvas c = new android.graphics.Canvas(baseBitmap);
                c.drawBitmap(fixedFull, minX, minY, null);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        canvas.removeEraserStrokes();
                        panelHint.setText(R.string.eraser_hint);
                        recomputeDisplay();
                    }
                });
            }
        }).start();
    }

    private void applyEnhance() {
        if (baseBitmap == null) return;
        panelHint.setVisibility(View.VISIBLE);
        panelHint.setText(R.string.loading);
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap enhanced = ImageUtils.autoEnhance(baseBitmap);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        baseBitmap = enhanced;
                        panelHint.setVisibility(View.GONE);
                        recomputeDisplay();
                    }
                });
            }
        }).start();
    }

    private void throttledRecompute() {
        long now = System.currentTimeMillis();
        if (now - lastRecompute < 150) return;
        lastRecompute = now;
        recomputeDisplay();
    }

    private void recomputeDisplay() {
        if (baseBitmap == null) return;
        final int gen = ++recomputeGen;
        final Bitmap base = baseBitmap;
        final String filter = filterName;
        final int[] a = adj.clone();
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap filtered = ImageUtils.applyFilter(base, filter);
                Bitmap out = ImageUtils.adjust(filtered, a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
                if (filtered != out && filtered != base) filtered.recycle();
                final Bitmap fin = out;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (gen != recomputeGen) {
                            fin.recycle();
                            return;
                        }
                        if (displayBitmap != null && displayBitmap != fin) displayBitmap.recycle();
                        displayBitmap = fin;
                        canvas.setBitmap(fin);
                    }
                });
            }
        }).start();
    }

    private void save() {
        if (displayBitmap == null) return;
        panelHint.setVisibility(View.VISIBLE);
        panelHint.setText(R.string.loading);
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap exported = canvas.exportBitmap();
                if (exported == null) return;
                String base = item != null && item.name != null
                        ? item.name.replaceAll("\\.[^.]+$", "") : "edited";
                final Uri uri = ImageUtils.saveToGallery(EditorActivity.this, exported, base + "_edit");
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        panelHint.setVisibility(View.GONE);
                        if (uri != null) {
                            UiUtils.toast(EditorActivity.this, R.string.edit_saved);
                            finish();
                        } else {
                            UiUtils.toast(EditorActivity.this, R.string.edit_save_failed);
                        }
                    }
                });
            }
        }).start();
    }
}
