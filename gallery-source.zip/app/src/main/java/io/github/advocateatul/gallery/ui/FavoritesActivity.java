package io.github.advocateatul.gallery.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import java.util.ArrayList;
import java.util.List;

public class FavoritesActivity extends AppCompatActivity {
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private MediaGridAdapter adapter;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_list);
        ((android.widget.TextView) findViewById(R.id.title)).setText(R.string.menu_favorites);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        RecyclerView list = findViewById(R.id.list);
        GridLayoutManager lm = new GridLayoutManager(this, 3);
        lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER ? 3 : 1;
            }
        });
        list.setLayoutManager(lm);
        adapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {
                Intent i = new Intent(FavoritesActivity.this, ViewerActivity.class);
                i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(items));
                i.putExtra("position", position);
                startActivity(i);
            }
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {}
        });
        list.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> out = new ArrayList<MediaItem>();
                for (String key : GalleryDb.get(FavoritesActivity.this).favoriteKeys()) {
                    MediaItem m = MediaRepo.getByKey(FavoritesActivity.this, key);
                    if (m != null) { m.favorite = true; out.add(m); }
                }
                MediaRepo.sortList(out, 0);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        items = out;
                        findViewById(R.id.empty).setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                        ((android.widget.ImageView) findViewById(R.id.empty_icon)).setImageResource(R.drawable.ic_fav);
                        ((android.widget.TextView) findViewById(R.id.empty_text)).setText(R.string.empty_favorites);
                        ((android.widget.TextView) findViewById(R.id.empty_sub)).setText(R.string.empty_favorites_sub);
                        adapter.setItems(items, true);
                    }
                });
            }
        }).start();
    }
}
