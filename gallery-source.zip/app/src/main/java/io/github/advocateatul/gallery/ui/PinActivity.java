package io.github.advocateatul.gallery.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.util.UiUtils;
import java.security.MessageDigest;
import java.util.concurrent.Executor;

public class PinActivity extends AppCompatActivity {
    private StringBuilder pin = new StringBuilder();
    private String firstPin = null;
    private boolean setupMode;
    private boolean changeMode;
    private View[] dots = new View[4];
    private TextView titleView, hintView;
    private CancellationSignal cancelSignal;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_pin);
        SharedPreferences prefs = GalleryApp.prefs(this);
        setupMode = !prefs.getBoolean(GalleryApp.PREF_PIN_SET, false);
        changeMode = getIntent().getBooleanExtra("change", false);
        titleView = findViewById(R.id.title);
        hintView = findViewById(R.id.hint);
        dots[0] = findViewById(R.id.dot1);
        dots[1] = findViewById(R.id.dot2);
        dots[2] = findViewById(R.id.dot3);
        dots[3] = findViewById(R.id.dot4);
        if (setupMode) {
            titleView.setText(R.string.pin_title_setup);
            hintView.setText("");
        } else if (changeMode) {
            titleView.setText(R.string.pin_title_enter);
        } else {
            titleView.setText(R.string.pin_title_enter);
            hintView.setText(R.string.secure_unlock);
        }
        int[] keys = {R.id.k0, R.id.k1, R.id.k2, R.id.k3, R.id.k4, R.id.k5, R.id.k6, R.id.k7, R.id.k8, R.id.k9};
        final String[] digits = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
        for (int i = 0; i < keys.length; i++) {
            final String d = digits[i];
            findViewById(keys[i]).setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { addDigit(d); }
            });
        }
        findViewById(R.id.k_del).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (pin.length() > 0) {
                    pin.deleteCharAt(pin.length() - 1);
                    updateDots();
                }
            }
        });
        Button fp = findViewById(R.id.k_fp);
        if (!setupMode && Build.VERSION.SDK_INT >= 28 && canBiometric()) {
            fp.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { startBiometric(); }
            });
        } else {
            fp.setVisibility(View.INVISIBLE);
        }
        if (!setupMode && Build.VERSION.SDK_INT >= 28 && canBiometric()) {
            startBiometric();
        }
    }

    private boolean canBiometric() {
        try {
            android.hardware.biometrics.BiometricManager bm =
                    (android.hardware.biometrics.BiometricManager) getSystemService(BIOMETRIC_SERVICE);
            return bm != null && bm.canAuthenticate() == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS;
        } catch (Exception e) {
            return false;
        }
    }

    private void startBiometric() {
        try {
            Executor exec = new Executor() {
                @Override public void execute(Runnable r) { runOnUiThread(r); }
            };
            BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                    .setTitle(getString(R.string.menu_secure))
                    .setSubtitle(getString(R.string.pin_use_fingerprint))
                    .setNegativeButton(getString(R.string.action_cancel), exec, new DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int which) {}
                    })
                    .build();
            cancelSignal = new CancellationSignal();
            prompt.authenticate(cancelSignal, exec, new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    openSecure();
                }
                @Override public void onAuthenticationFailed() {
                    UiUtils.toast(PinActivity.this, R.string.pin_wrong);
                }
            });
        } catch (Exception e) {
            // biometric unavailable; PIN still works
        }
    }

    private void addDigit(String d) {
        if (pin.length() >= 4) return;
        pin.append(d);
        updateDots();
        if (pin.length() == 4) {
            final String entered = pin.toString();
            pin.setLength(0);
            updateDots();
            handlePin(entered);
        }
    }

    private void updateDots() {
        for (int i = 0; i < 4; i++) {
            dots[i].setBackgroundResource(i < pin.length()
                    ? R.drawable.bg_pin_dot_active : R.drawable.bg_pin_dot);
        }
    }

    private void handlePin(String entered) {
        SharedPreferences prefs = GalleryApp.prefs(this);
        if (setupMode) {
            if (firstPin == null) {
                firstPin = entered;
                titleView.setText(R.string.pin_confirm);
            } else {
                if (firstPin.equals(entered)) {
                    prefs.edit().putString(GalleryApp.PREF_PIN, hash(entered))
                            .putBoolean(GalleryApp.PREF_PIN_SET, true).apply();
                    openSecure();
                } else {
                    firstPin = null;
                    titleView.setText(R.string.pin_title_setup);
                    UiUtils.toast(this, R.string.pin_mismatch);
                }
            }
            return;
        }
        String stored = prefs.getString(GalleryApp.PREF_PIN, "");
        if (hash(entered).equals(stored)) {
            if (changeMode) {
                // reuse setup flow for new PIN
                firstPin = null;
                setupMode = true;
                changeMode = false;
                titleView.setText(R.string.pin_title_setup);
                hintView.setText("");
            } else {
                openSecure();
            }
        } else {
            UiUtils.toast(this, R.string.pin_wrong);
        }
    }

    private void openSecure() {
        startActivity(new Intent(this, SecureFolderActivity.class));
        finish();
    }

    public static String hash(String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("gallery-secure:" + pin).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return pin;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cancelSignal != null) cancelSignal.cancel();
    }
}
