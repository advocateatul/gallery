package io.github.advocateatul.gallery.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.util.MediaActions;
import io.github.advocateatul.gallery.util.UiUtils;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PicturesFragment.Host {
    private PicturesFragment pictures;
    private AlbumsFragment albums;
    private StoriesFragment stories;
    private Fragment current;
    private TextView title;
    private ImageButton btnSearch, btnSort, btnMore;
    private int selectionCount = 0;
    private boolean selectionMode = false;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);
        title = findViewById(R.id.title);
        btnSearch = findViewById(R.id.btn_search);
        btnSort = findViewById(R.id.btn_sort);
        btnMore = findViewById(R.id.btn_more);
        pictures = new PicturesFragment();
        albums = new AlbumsFragment();
        stories = new StoriesFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.container, pictures, "pictures")
                .add(R.id.container, albums, "albums").hide(albums)
                .add(R.id.container, stories, "stories").hide(stories)
                .commit();
        current = pictures;
        findViewById(R.id.nav_pictures).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTab(pictures, 0); }
        });
        findViewById(R.id.nav_albums).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTab(albums, 1); }
        });
        findViewById(R.id.nav_stories).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showTab(stories, 2); }
        });
        findViewById(R.id.nav_menu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenuDialog(); }
        });
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (selectionMode) {
                    MediaActions.share(MainActivity.this, pictures.getSelectedItems());
                } else {
                    startActivity(new Intent(MainActivity.this, SearchActivity.class));
                }
            }
        });
        btnSort.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (selectionMode) {
                    toggleFavoriteSelected();
                } else {
                    showSortDialog();
                }
            }
        });
        btnMore.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (selectionMode) showSelectionMenu();
                else showMenuDialog();
            }
        });
        updateNav(0);
    }

    private void showTab(Fragment f, int tab) {
        if (current == f) return;
        if (selectionMode) exitSelectionMode();
        getSupportFragmentManager().beginTransaction().hide(current).show(f).commit();
        current = f;
        updateNav(tab);
        title.setText(tab == 0 ? R.string.app_name : tab == 1 ? R.string.tab_albums : R.string.tab_stories);
    }

    private void updateNav(int tab) {
        int accent = getResources().getColor(R.color.oneui_accent);
        int gray = getResources().getColor(R.color.oneui_text3);
        int[] icons = {R.id.nav_pictures_icon, R.id.nav_albums_icon, R.id.nav_stories_icon, R.id.nav_menu_icon};
        int[] labels = {R.id.nav_pictures_label, R.id.nav_albums_label, R.id.nav_stories_label, R.id.nav_menu_label};
        for (int i = 0; i < 4; i++) {
            boolean active = (i == tab);
            ((ImageView) findViewById(icons[i])).setColorFilter(active ? accent : gray);
            ((TextView) findViewById(labels[i])).setTextColor(active ? accent : gray);
        }
    }

    public void openViewer(List<MediaItem> items, int position) {
        Intent i = new Intent(this, ViewerActivity.class);
        i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(items));
        i.putExtra("position", position);
        startActivity(i);
    }

    // ---- selection mode ----
    @Override
    public void onSelectionChanged(int count) {
        selectionCount = count;
        if (count > 0 && !selectionMode) {
            selectionMode = true;
            title.setText(count + " selected");
            btnSearch.setImageResource(R.drawable.ic_share);
            btnSort.setImageResource(R.drawable.ic_fav);
            btnMore.setImageResource(R.drawable.ic_more);
        } else if (count > 0) {
            title.setText(count + " selected");
        } else {
            exitSelectionMode();
        }
    }

    @Override
    public void onLoaded() {}

    private void exitSelectionMode() {
        if (!selectionMode) return;
        selectionMode = false;
        selectionCount = 0;
        title.setText(current == albums ? R.string.tab_albums : current == stories ? R.string.tab_stories : R.string.app_name);
        btnSearch.setImageResource(R.drawable.ic_search);
        btnSort.setImageResource(R.drawable.ic_sort);
        btnMore.setImageResource(R.drawable.ic_more);
    }

    public void clearSelection() {
        if (pictures != null) pictures.clearSelection();
        exitSelectionMode();
    }

    @Override
    public void onBackPressed() {
        if (selectionMode) {
            clearSelection();
            return;
        }
        super.onBackPressed();
    }

    private void toggleFavoriteSelected() {
        List<MediaItem> sel = pictures.getSelectedItems();
        GalleryDb db = GalleryDb.get(this);
        for (MediaItem m : sel) {
            if (m.favorite) { db.removeFavorite(m); m.favorite = false; }
            else { db.addFavorite(m); m.favorite = true; }
        }
        UiUtils.toast(this, R.string.fav_added);
        clearSelection();
        pictures.refresh();
    }

    private void showSelectionMenu() {
        final String[] items = {
                getString(R.string.action_delete),
                getString(R.string.action_move_secure),
                getString(R.string.album_add),
                getString(R.string.action_select_all)
        };
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        List<MediaItem> sel = pictures.getSelectedItems();
                        if (which == 0) {
                            MediaActions.moveToTrash(MainActivity.this, sel, new MediaActions.Done() {
                                @Override public void run(boolean ok) {
                                    if (ok) UiUtils.toast(MainActivity.this, R.string.trash_moved);
                                    clearSelection();
                                    pictures.refresh();
                                }
                            });
                        } else if (which == 1) {
                            new Thread(new Runnable() {
                                @Override public void run() {
                                    final List<MediaItem> s = pictures.getSelectedItems();
                                    for (MediaItem m : s) MediaActions.moveToSecure(MainActivity.this, m);
                                    runOnUiThread(new Runnable() {
                                        @Override public void run() {
                                            UiUtils.toast(MainActivity.this, R.string.secure_moved);
                                            clearSelection();
                                            pictures.refresh();
                                        }
                                    });
                                }
                            }).start();
                        } else if (which == 2) {
                            showAddToAlbumDialog();
                        } else {
                            pictures.selectAll();
                        }
                    }
                }).show();
    }

    private void showAddToAlbumDialog() {
        final List<GalleryDb.CustomAlbum> albums = GalleryDb.get(this).listCustomAlbums();
        final String[] names = new String[albums.size() + 1];
        for (int i = 0; i < albums.size(); i++) names[i] = albums.get(i).name;
        names[albums.size()] = getString(R.string.album_new);
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.album_add)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        final List<MediaItem> sel = pictures.getSelectedItems();
                        final List<String> keys = new ArrayList<String>();
                        for (MediaItem m : sel) keys.add(m.key());
                        if (which == albums.size()) {
                            final android.widget.EditText input = new android.widget.EditText(MainActivity.this);
                            new AlertDialog.Builder(MainActivity.this, R.style.Theme_Gallery_Dialog)
                                    .setTitle(R.string.action_create_album)
                                    .setView(input)
                                    .setPositiveButton(R.string.action_done, new DialogInterface.OnClickListener() {
                                        @Override public void onClick(DialogInterface d2, int w2) {
                                            String name = input.getText().toString().trim();
                                            if (name.isEmpty()) return;
                                            long id = GalleryDb.get(MainActivity.this).createAlbum(name);
                                            GalleryDb.get(MainActivity.this).addToAlbum(id, keys);
                                            UiUtils.toast(MainActivity.this, R.string.album_added);
                                            clearSelection();
                                        }
                                    })
                                    .setNegativeButton(R.string.action_cancel, null)
                                    .show();
                        } else {
                            GalleryDb.get(MainActivity.this).addToAlbum(albums.get(which).id, keys);
                            UiUtils.toast(MainActivity.this, R.string.album_added);
                            clearSelection();
                        }
                    }
                }).show();
    }

    private void showSortDialog() {
        final String[] opts = {
                getString(R.string.sort_newest), getString(R.string.sort_oldest),
                getString(R.string.sort_name), getString(R.string.sort_size)
        };
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.sort_title)
                .setSingleChoiceItems(opts, GalleryApp.sortMode(this), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        GalleryApp.setSortMode(MainActivity.this, which);
                        d.dismiss();
                        if (current == pictures) pictures.refresh();
                        else if (current == albums) albums.refresh();
                    }
                }).show();
    }

    private void showMenuDialog() {
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(8, 8, 8, 8);
        addMenuRow(root, R.drawable.ic_fav, R.string.menu_favorites, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, FavoritesActivity.class)); }
        });
        addMenuRow(root, R.drawable.ic_trash, R.string.menu_trash, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, TrashActivity.class)); }
        });
        addMenuRow(root, R.drawable.ic_lock, R.string.menu_secure, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, PinActivity.class)); }
        });
        addMenuRow(root, R.drawable.ic_magic, R.string.menu_cleanup, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, CleanupActivity.class)); }
        });
        addMenuRow(root, R.drawable.ic_stories, R.string.menu_memories, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MemoriesActivity.class);
                i.putExtra("title", getString(R.string.story_memories));
                startActivity(i);
            }
        });
        addMenuRow(root, R.drawable.ic_adjust, R.string.menu_settings, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, SettingsActivity.class)); }
        });
        addMenuRow(root, R.drawable.ic_language, R.string.menu_language, new View.OnClickListener() {
            @Override public void onClick(View v) { showLanguageDialog(); }
        });
        b.setView(root);
        final AlertDialog dlg = b.create();
        root.setTag(dlg);
        dlg.show();
    }

    private void addMenuRow(LinearLayout root, int icon, int label, final View.OnClickListener l) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_row, root, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(icon);
        ((TextView) row.findViewById(R.id.label)).setText(label);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Object tag = root.getTag();
                if (tag instanceof AlertDialog) ((AlertDialog) tag).dismiss();
                l.onClick(v);
            }
        });
        root.addView(row);
    }

    private void showLanguageDialog() {
        final String[] langs = {getString(R.string.settings_english), getString(R.string.settings_hindi)};
        String cur = GalleryApp.prefs(this).getString(GalleryApp.PREF_LANG, "");
        int checked = "hi".equals(cur) ? 1 : 0;
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.menu_language)
                .setSingleChoiceItems(langs, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        GalleryApp.prefs(MainActivity.this).edit()
                                .putString(GalleryApp.PREF_LANG, which == 1 ? "hi" : "en").apply();
                        d.dismiss();
                        recreate();
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MediaActions.REQ_TRASH) {
            if (resultCode == RESULT_OK) MediaActions.noteTrash(this);
            else MediaActions.cancelTrash();
            if (pictures != null) pictures.refresh();
        } else if (requestCode == MediaActions.REQ_DELETE) {
            if (resultCode == RESULT_OK) MediaActions.noteDelete(this);
            else MediaActions.cancelDelete();
        } else if (requestCode == MediaActions.REQ_RESTORE_TRASH) {
            if (resultCode == RESULT_OK) MediaActions.noteRestore(this);
            else MediaActions.cancelRestore();
        }
    }
}
