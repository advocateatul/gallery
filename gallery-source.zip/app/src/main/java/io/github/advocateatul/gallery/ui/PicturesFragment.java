package io.github.advocateatul.gallery.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class PicturesFragment extends Fragment {
    public interface Host {
        void onSelectionChanged(int count);
        void onLoaded();
    }

    public static final int REQ_MEDIA = 2001;
    private RecyclerView grid;
    private View empty, perm, loading;
    private MediaGridAdapter adapter;
    private GridLayoutManager layoutManager;
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private ScaleGestureDetector pinch;
    private float pinchAccum = 1f;
    private int pendingSpan = -1;

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle saved) {
        View v = inf.inflate(R.layout.fragment_pictures, parent, false);
        grid = v.findViewById(R.id.grid);
        empty = v.findViewById(R.id.empty);
        perm = v.findViewById(R.id.perm);
        loading = v.findViewById(R.id.loading);
        v.findViewById(R.id.btn_grant).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { requestPerms(); }
        });
        int span = GalleryApp.gridSpan(getContext());
        layoutManager = new GridLayoutManager(getContext(), span);
        layoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER
                        ? layoutManager.getSpanCount() : 1;
            }
        });
        grid.setLayoutManager(layoutManager);
        grid.setHasFixedSize(true);
        adapter = new MediaGridAdapter(getContext(), new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).openViewer(items, position);
                }
            }
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {
                if (getActivity() instanceof Host) ((Host) getActivity()).onSelectionChanged(count);
            }
        });
        adapter.setSpanCount(span);
        grid.setAdapter(adapter);
        grid.setItemViewCacheSize(20);
        // pinch to change grid size (2..5 columns)
        pinch = new ScaleGestureDetector(getContext(), new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                pinchAccum *= d.getScaleFactor();
                if (pinchAccum > 1.25f) {
                    changeSpan(-1);
                    pinchAccum = 1f;
                } else if (pinchAccum < 0.8f) {
                    changeSpan(1);
                    pinchAccum = 1f;
                }
                return true;
            }
        });
        grid.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                pinch.onTouchEvent(e);
                return false;
            }
        });
        return v;
    }

    private void changeSpan(int delta) {
        int span = layoutManager.getSpanCount() + delta;
        if (span < 2) span = 2;
        if (span > 5) span = 5;
        if (span == layoutManager.getSpanCount()) return;
        layoutManager.setSpanCount(span);
        adapter.setSpanCount(span);
        GalleryApp.setGridSpan(getContext(), span);
        adapter.setItems(items, true);
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    public void refresh() {
        if (getContext() == null) return;
        if (!hasPerms()) {
            perm.setVisibility(View.VISIBLE);
            loading.setVisibility(View.GONE);
            grid.setVisibility(View.GONE);
            empty.setVisibility(View.GONE);
            return;
        }
        perm.setVisibility(View.GONE);
        if (items.isEmpty()) loading.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> loaded = MediaRepo.queryAll(getContext(), GalleryApp.sortMode(getContext()));
                // apply favorites
                final Set<String> favs = GalleryDb.get(getContext()).favoriteKeys();
                for (MediaItem m : loaded) m.favorite = favs.contains(m.key());
                if (getActivity() == null) return;
                getActivity().runOnUiThread(new Runnable() {
                    @Override public void run() {
                        items = loaded;
                        loading.setVisibility(View.GONE);
                        grid.setVisibility(View.VISIBLE);
                        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                        adapter.setItems(items, true);
                        if (getActivity() instanceof Host) ((Host) getActivity()).onLoaded();
                    }
                });
            }
        }).start();
    }

    public boolean hasPerms() {
        if (Build.VERSION.SDK_INT >= 33) {
            return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                    || ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        }
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    public void requestPerms() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.ACCESS_MEDIA_LOCATION}, REQ_MEDIA);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code == REQ_MEDIA) refresh();
    }

    public List<MediaItem> getItems() { return items; }
    public List<MediaItem> getSelectedItems() { return adapter.getSelectedItems(); }
    public void clearSelection() { adapter.clearSelection(); }
    public void selectAll() { adapter.selectAll(); }
    public boolean isSelectionMode() { return adapter.isSelectionMode(); }
}
