package io.github.advocateatul.gallery.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class AlbumActivity extends AppCompatActivity {
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private MediaGridAdapter adapter;
    private GridLayoutManager layoutManager;
    private String bucket;
    private String storyTitle;
    private long albumId = -1;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_album);
        bucket = getIntent().getStringExtra("bucket");
        storyTitle = getIntent().getStringExtra("story_title");
        albumId = getIntent().getLongExtra("album_id", -1);
        TextView title = findViewById(R.id.title);
        title.setText(storyTitle != null ? storyTitle : (bucket != null ? bucket : getString(R.string.app_name)));
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        findViewById(R.id.btn_sort).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                // cycle sort quickly: newest <-> oldest
                int s = GalleryApp.sortMode(AlbumActivity.this);
                GalleryApp.setSortMode(AlbumActivity.this, s == 0 ? 1 : 0);
                refresh();
            }
        });
        RecyclerView grid = findViewById(R.id.grid);
        int span = GalleryApp.gridSpan(this);
        layoutManager = new GridLayoutManager(this, span);
        layoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER
                        ? layoutManager.getSpanCount() : 1;
            }
        });
        grid.setLayoutManager(layoutManager);
        adapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {
                Intent i = new Intent(AlbumActivity.this, ViewerActivity.class);
                i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(items));
                i.putExtra("position", position);
                startActivity(i);
            }
            @Override public void onLongClick(final MediaItem item, int position) {
                if (albumId > 0) {
                    new androidx.appcompat.app.AlertDialog.Builder(AlbumActivity.this, R.style.Theme_Gallery_Dialog)
                            .setTitle(item.name)
                            .setMessage(R.string.album_remove)
                            .setPositiveButton(R.string.action_delete, new android.content.DialogInterface.OnClickListener() {
                                @Override public void onClick(android.content.DialogInterface d, int which) {
                                    GalleryDb.get(AlbumActivity.this).removeFromAlbum(albumId, item.key());
                                    io.github.advocateatul.gallery.util.UiUtils.toast(AlbumActivity.this, R.string.album_removed);
                                    refresh();
                                }
                            })
                            .setNegativeButton(R.string.action_cancel, null)
                            .show();
                }
            }
            @Override public void onSelectionChanged(int count) {
                ((TextView) findViewById(R.id.title)).setText(count > 0
                        ? count + " selected"
                        : (storyTitle != null ? storyTitle : bucket));
            }
        });
        adapter.setSpanCount(span);
        grid.setAdapter(adapter);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        final ArrayList<MediaItem> passed = getIntent().getParcelableArrayListExtra("items");
        new Thread(new Runnable() {
            @Override public void run() {
                List<MediaItem> loaded;
                if (passed != null) {
                    loaded = passed;
                    MediaRepo.sortList(loaded, GalleryApp.sortMode(AlbumActivity.this));
                } else if (bucket != null) {
                    loaded = MediaRepo.queryBucket(AlbumActivity.this, bucket, GalleryApp.sortMode(AlbumActivity.this));
                } else {
                    loaded = new ArrayList<MediaItem>();
                }
                final Set<String> favs = GalleryDb.get(AlbumActivity.this).favoriteKeys();
                for (MediaItem m : loaded) m.favorite = favs.contains(m.key());
                final List<MediaItem> fin = loaded;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        items = fin;
                        findViewById(R.id.empty).setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                        adapter.setItems(items, storyTitle == null);
                    }
                });
            }
        }).start();
    }
}
