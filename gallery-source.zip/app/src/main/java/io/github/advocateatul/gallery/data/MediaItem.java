package io.github.advocateatul.gallery.data;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

public class MediaItem implements Parcelable {
    public long id;
    public Uri uri;
    public String name;
    public String path;
    public String bucket;
    public String mime;
    public long dateTaken;   // ms
    public long dateAdded;   // s -> ms stored
    public long size;
    public int width;
    public int height;
    public long duration;    // ms, video only
    public double lat = Double.NaN;
    public double lng = Double.NaN;
    public boolean isVideo;
    public boolean favorite;
    public String thumbFile; // local file to use for thumbnails (e.g. legacy trash)

    public MediaItem() {}

    public String key() {
        return (isVideo ? "v" : "i") + id;
    }

    public boolean hasLocation() {
        return !Double.isNaN(lat) && !Double.isNaN(lng) && (lat != 0 || lng != 0);
    }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MediaItem)) return false;
        MediaItem m = (MediaItem) o;
        return id == m.id && isVideo == m.isVideo;
    }
    @Override public int hashCode() {
        return (int) (id * 31 + (isVideo ? 1 : 0));
    }

    // Parcelable
    protected MediaItem(Parcel in) {
        id = in.readLong();
        uri = in.readParcelable(Uri.class.getClassLoader());
        name = in.readString();
        path = in.readString();
        bucket = in.readString();
        mime = in.readString();
        dateTaken = in.readLong();
        dateAdded = in.readLong();
        size = in.readLong();
        width = in.readInt();
        height = in.readInt();
        duration = in.readLong();
        lat = in.readDouble();
        lng = in.readDouble();
        isVideo = in.readByte() != 0;
        favorite = in.readByte() != 0;
    }
    @Override public void writeToParcel(Parcel d, int flags) {
        d.writeLong(id); d.writeParcelable(uri, flags); d.writeString(name);
        d.writeString(path); d.writeString(bucket); d.writeString(mime);
        d.writeLong(dateTaken); d.writeLong(dateAdded); d.writeLong(size);
        d.writeInt(width); d.writeInt(height); d.writeLong(duration);
        d.writeDouble(lat); d.writeDouble(lng);
        d.writeByte((byte) (isVideo ? 1 : 0)); d.writeByte((byte) (favorite ? 1 : 0));
    }
    @Override public int describeContents() { return 0; }
    public static final Creator<MediaItem> CREATOR = new Creator<MediaItem>() {
        @Override public MediaItem createFromParcel(Parcel in) { return new MediaItem(in); }
        @Override public MediaItem[] newArray(int size) { return new MediaItem[size]; }
    };
}
