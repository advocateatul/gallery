package io.github.advocateatul.gallery.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import io.github.advocateatul.gallery.data.SmartEngine;
import io.github.advocateatul.gallery.util.MediaActions;
import io.github.advocateatul.gallery.util.UiUtils;
import java.util.ArrayList;
import java.util.List;

public class CleanupActivity extends AppCompatActivity {
    private RecyclerView list;
    private View empty, loading;
    private TextView actionView;
    private SmartEngine.CleanupResult result;
    private List<MediaItem> detailItems = null;
    private String detailTitle = null;
    private MediaGridAdapter gridAdapter;

    private static class Section {
        int icon, titleRes;
        List<MediaItem> items;
        String sub;
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_list);
        ((TextView) findViewById(R.id.title)).setText(R.string.cleanup_title);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (detailItems != null) { showOverview(); }
                else finish();
            }
        });
        actionView = findViewById(R.id.action);
        list = findViewById(R.id.list);
        empty = findViewById(R.id.empty);
        loading = findViewById(R.id.loading);
        loading.setVisibility(View.VISIBLE);
        ((TextView) findViewById(R.id.empty_text)).setText(R.string.empty_cleanup);
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> all = MediaRepo.queryAll(CleanupActivity.this, GalleryApp.sortMode(CleanupActivity.this));
                final SmartEngine.CleanupResult r = SmartEngine.scanCleanup(CleanupActivity.this, all);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        loading.setVisibility(View.GONE);
                        result = r;
                        showOverview();
                    }
                });
            }
        }).start();
    }

    private List<Section> buildSections() {
        List<Section> out = new ArrayList<Section>();
        if (result == null) return out;
        Section s;
        if (!result.duplicates.isEmpty()) {
            s = new Section();
            s.icon = R.drawable.ic_pictures; s.titleRes = R.string.cleanup_duplicates;
            s.items = flattenGroups(result.duplicates);
            s.sub = result.duplicates.size() + " groups · " + s.items.size() + " photos";
            out.add(s);
        }
        if (!result.similar.isEmpty()) {
            s = new Section();
            s.icon = R.drawable.ic_pictures; s.titleRes = R.string.cleanup_similar;
            s.items = flattenGroups(result.similar);
            s.sub = result.similar.size() + " groups · " + s.items.size() + " photos";
            out.add(s);
        }
        if (!result.blurry.isEmpty()) {
            s = new Section();
            s.icon = R.drawable.ic_warning; s.titleRes = R.string.cleanup_blurry;
            s.items = result.blurry;
            s.sub = result.blurry.size() + " photos";
            out.add(s);
        }
        if (!result.dark.isEmpty()) {
            s = new Section();
            s.icon = R.drawable.ic_adjust; s.titleRes = R.string.cleanup_dark;
            s.items = result.dark;
            s.sub = result.dark.size() + " photos";
            out.add(s);
        }
        if (!result.screenshots.isEmpty()) {
            s = new Section();
            s.icon = R.drawable.ic_camera; s.titleRes = R.string.cleanup_screenshots;
            s.items = result.screenshots;
            s.sub = result.screenshots.size() + " photos";
            out.add(s);
        }
        return out;
    }

    private List<MediaItem> flattenGroups(List<List<MediaItem>> groups) {
        List<MediaItem> out = new ArrayList<MediaItem>();
        for (List<MediaItem> g : groups) out.addAll(g);
        return out;
    }

    private void showOverview() {
        detailItems = null;
        detailTitle = null;
        actionView.setVisibility(View.GONE);
        final List<Section> sections = buildSections();
        empty.setVisibility(sections.isEmpty() ? View.VISIBLE : View.GONE);
        ((ImageView) findViewById(R.id.empty_icon)).setImageResource(R.drawable.ic_magic);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return sections.size(); }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_cleanup, p, false);
                return new RecyclerView.ViewHolder(v) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                final Section s = sections.get(pos);
                ((ImageView) h.itemView.findViewById(R.id.icon)).setImageResource(s.icon);
                ((TextView) h.itemView.findViewById(R.id.title)).setText(s.titleRes);
                ((TextView) h.itemView.findViewById(R.id.sub)).setText(s.sub);
                h.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { showDetail(s); }
                });
            }
        });
    }

    private void showDetail(final Section s) {
        detailItems = s.items;
        detailTitle = getString(s.titleRes);
        ((TextView) findViewById(R.id.title)).setText(detailTitle);
        actionView.setVisibility(View.VISIBLE);
        actionView.setText(R.string.action_select_all);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (gridAdapter != null) gridAdapter.selectAll();
            }
        });
        GridLayoutManager lm = new GridLayoutManager(this, 3);
        lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return gridAdapter != null && gridAdapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER ? 3 : 1;
            }
        });
        list.setLayoutManager(lm);
        gridAdapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {}
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {
                if (count > 0) {
                    actionView.setText(getString(R.string.action_delete) + " (" + count + ")");
                    actionView.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { deleteSelected(); }
                    });
                } else {
                    actionView.setText(R.string.action_select_all);
                    actionView.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            if (gridAdapter != null) gridAdapter.selectAll();
                        }
                    });
                }
            }
        });
        list.setAdapter(gridAdapter);
        gridAdapter.setItems(detailItems, false);
    }

    private void deleteSelected() {
        if (gridAdapter == null) return;
        final List<MediaItem> sel = gridAdapter.getSelectedItems();
        MediaActions.moveToTrash(this, sel, new MediaActions.Done() {
            @Override public void run(boolean ok) {
                if (ok) UiUtils.toast(CleanupActivity.this, getString(R.string.cleanup_deleted, sel.size()));
                // remove from result lists and refresh overview
                if (result != null) {
                    result.blurry.removeAll(sel);
                    result.dark.removeAll(sel);
                    result.screenshots.removeAll(sel);
                    for (List<MediaItem> g : result.duplicates) g.removeAll(sel);
                    for (List<MediaItem> g : result.similar) g.removeAll(sel);
                }
                showOverview();
                ((TextView) findViewById(R.id.title)).setText(R.string.cleanup_title);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MediaActions.REQ_TRASH) {
            if (resultCode == RESULT_OK) MediaActions.noteTrash(this);
            else MediaActions.cancelTrash();
        }
    }

    @Override
    public void onBackPressed() {
        if (detailItems != null) {
            showOverview();
            ((TextView) findViewById(R.id.title)).setText(R.string.cleanup_title);
        } else {
            super.onBackPressed();
        }
    }
}
