package io.github.advocateatul.gallery.ui;

import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.util.UiUtils;
import java.io.File;
import java.nio.ByteBuffer;

public class VideoTrimActivity extends AppCompatActivity {
    private VideoView video;
    private SeekBar seekStart, seekEnd;
    private TextView rangeLabel;
    private MediaItem item;
    private long durationMs = 0;
    private Handler handler = new Handler();
    private Runnable stopTask;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_trim);
        item = getIntent().getParcelableExtra("item");
        video = findViewById(R.id.video);
        seekStart = findViewById(R.id.seek_start);
        seekEnd = findViewById(R.id.seek_end);
        rangeLabel = findViewById(R.id.range_label);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        findViewById(R.id.btn_save).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { saveTrim(); }
        });
        video.setVideoURI(item.uri);
        video.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(android.media.MediaPlayer mp) {
                durationMs = mp.getDuration();
                updateLabel();
                video.seekTo((int) startMs());
                video.start();
                scheduleStop();
            }
        });
        video.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (video.isPlaying()) video.pause();
                else {
                    if (video.getCurrentPosition() >= endMs()) video.seekTo((int) startMs());
                    video.start();
                    scheduleStop();
                }
            }
        });
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                if (s == seekStart && p > seekEnd.getProgress() - 10) seekStart.setProgress(seekEnd.getProgress() - 10);
                if (s == seekEnd && p < seekStart.getProgress() + 10) seekEnd.setProgress(seekStart.getProgress() + 10);
                updateLabel();
                video.seekTo((int) startMs());
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        };
        seekStart.setOnSeekBarChangeListener(l);
        seekEnd.setOnSeekBarChangeListener(l);
    }

    private long startMs() { return durationMs * seekStart.getProgress() / 1000; }
    private long endMs() { return durationMs * seekEnd.getProgress() / 1000; }

    private void updateLabel() {
        rangeLabel.setText(UiUtils.formatDuration(startMs()) + " – " + UiUtils.formatDuration(endMs())
                + "  (" + UiUtils.formatDuration(endMs() - startMs()) + ")");
    }

    private void scheduleStop() {
        if (stopTask != null) handler.removeCallbacks(stopTask);
        stopTask = new Runnable() {
            @Override public void run() {
                if (video.isPlaying() && video.getCurrentPosition() >= endMs()) video.pause();
                else if (video.isPlaying()) handler.postDelayed(this, 200);
            }
        };
        handler.postDelayed(stopTask, 200);
    }

    private void saveTrim() {
        rangeLabel.setText(R.string.loading);
        final long startUs = startMs() * 1000;
        final long endUs = endMs() * 1000;
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = trimVideo(item.uri, startUs, endUs);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (ok) {
                            UiUtils.toast(VideoTrimActivity.this, R.string.trim_saved);
                            finish();
                        } else {
                            UiUtils.toast(VideoTrimActivity.this, R.string.trim_failed);
                            updateLabel();
                        }
                    }
                });
            }
        }).start();
    }

    private boolean trimVideo(Uri uri, long startUs, long endUs) {
        try {
            File movies = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Gallery");
            movies.mkdirs();
            File out = new File(movies, "trimmed_" + System.currentTimeMillis() + ".mp4");
            return trimAllTracks(uri, startUs, endUs, out);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean trimAllTracks(Uri uri, long startUs, long endUs, File out) {
        MediaExtractor ex = new MediaExtractor();
        MediaMuxer muxer = null;
        try {
            ex.setDataSource(this, uri, null);
            muxer = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int trackCount = ex.getTrackCount();
            int[] trackMap = new int[trackCount];
            for (int i = 0; i < trackCount; i++) {
                MediaFormat fmt = ex.getTrackFormat(i);
                String mime = fmt.getString(MediaFormat.KEY_MIME);
                if (mime != null && (mime.startsWith("video") || mime.startsWith("audio"))) {
                    trackMap[i] = muxer.addTrack(fmt);
                    ex.selectTrack(i);
                } else {
                    trackMap[i] = -1;
                }
            }
            muxer.start();
            ByteBuffer buf = ByteBuffer.allocate(1024 * 1024);
            android.media.MediaCodec.BufferInfo info = new android.media.MediaCodec.BufferInfo();
            for (int i = 0; i < trackCount; i++) {
                if (trackMap[i] < 0) continue;
                ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                // seekTo seeks all selected tracks; process one track at a time by
                // reading only samples of track i:
                while (true) {
                    int n = ex.readSampleData(buf, 0);
                    if (n < 0) break;
                    int track = ex.getSampleTrackIndex();
                    long t = ex.getSampleTime();
                    if (track != i) { ex.advance(); continue; }
                    if (t > endUs) break;
                    if (t < startUs) { ex.advance(); continue; }
                    info.offset = 0;
                    info.size = n;
                    info.presentationTimeUs = t - startUs;
                    info.flags = ex.getSampleFlags();
                    muxer.writeSampleData(trackMap[i], buf, info);
                    ex.advance();
                }
                // Note: readSampleData advances across tracks; the loop above consumes
                // samples of other tracks too (skipped). To keep it simple and correct,
                // we re-seek for each track and rely on seekTo resetting position.
                ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            }
            muxer.stop();
            muxer.release();
            ex.release();
            android.media.MediaScannerConnection.scanFile(this,
                    new String[]{out.getAbsolutePath()}, new String[]{"video/mp4"}, null);
            return out.length() > 0;
        } catch (Exception e) {
            try { if (muxer != null) muxer.release(); } catch (Exception ignored) {}
            try { ex.release(); } catch (Exception ignored) {}
            return false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (video != null && video.isPlaying()) video.pause();
        if (stopTask != null) handler.removeCallbacks(stopTask);
    }
}
