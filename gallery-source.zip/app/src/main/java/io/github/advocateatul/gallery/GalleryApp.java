package io.github.advocateatul.gallery;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.preference.PreferenceManager;
import java.util.Locale;

public class GalleryApp extends Application {
    public static final String PREF_LANG = "lang";
    public static final String PREF_SPAN = "grid_span";
    public static final String PREF_SORT = "sort";
    public static final String PREF_SLIDESHOW = "slideshow_ms";
    public static final String PREF_PIN = "secure_pin_hash";
    public static final String PREF_PIN_SET = "secure_pin_set";

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(applyLocale(base));
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static Context applyLocale(Context c) {
        String lang = PreferenceManager.getDefaultSharedPreferences(c).getString(PREF_LANG, "");
        if (lang == null || lang.isEmpty()) return c;
        Locale loc = new Locale(lang);
        Locale.setDefault(loc);
        Resources res = c.getResources();
        Configuration cfg = new Configuration(res.getConfiguration());
        if (Build.VERSION.SDK_INT >= 17) cfg.setLocale(loc);
        else cfg.locale = loc;
        return c.createConfigurationContext(cfg);
    }

    public static SharedPreferences prefs(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }

    public static int gridSpan(Context c) {
        return prefs(c).getInt(PREF_SPAN, 3);
    }

    public static void setGridSpan(Context c, int span) {
        prefs(c).edit().putInt(PREF_SPAN, span).apply();
    }

    public static int sortMode(Context c) {
        return prefs(c).getInt(PREF_SORT, 0); // 0 newest, 1 oldest, 2 name, 3 size
    }

    public static void setSortMode(Context c, int mode) {
        prefs(c).edit().putInt(PREF_SORT, mode).apply();
    }

    public static int slideshowMs(Context c) {
        return prefs(c).getInt(PREF_SLIDESHOW, 3000);
    }
}
