package io.github.advocateatul.gallery.util;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class ImageUtils {

    public static Bitmap copy(Bitmap src) {
        return src.copy(Bitmap.Config.ARGB_8888, true);
    }

    // ---- filters (ColorMatrix presets) ----
    public static Bitmap applyFilter(Bitmap src, String name) {
        if (name == null || name.equals("original")) return copy(src);
        ColorMatrix cm = new ColorMatrix();
        switch (name) {
            case "vivid":
                cm.setSaturation(1.5f);
                concatContrast(cm, 1.12f);
                break;
            case "warm":
                cm.setSaturation(1.1f);
                concatWarm(cm, 1.12f);
                break;
            case "cool":
                cm.setSaturation(1.05f);
                concatWarm(cm, 0.88f);
                break;
            case "mono":
                cm.setSaturation(0f);
                break;
            case "sepia":
                cm.setSaturation(0f);
                ColorMatrix sep = new ColorMatrix(new float[]{
                        0.393f, 0.769f, 0.189f, 0, 0,
                        0.349f, 0.686f, 0.168f, 0, 0,
                        0.272f, 0.534f, 0.131f, 0, 0,
                        0, 0, 0, 1, 0});
                cm.postConcat(sep);
                break;
            case "fade":
                cm.setSaturation(0.75f);
                concatContrast(cm, 0.88f);
                concatBrightness(cm, 14f);
                break;
            case "noir":
                cm.setSaturation(0f);
                concatContrast(cm, 1.35f);
                break;
            default:
                return copy(src);
        }
        return applyMatrix(src, cm);
    }

    public static Bitmap applyMatrix(Bitmap src, ColorMatrix cm) {
        Bitmap out = copy(src);
        Canvas c = new Canvas(out);
        Paint p = new Paint();
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(src, 0, 0, p);
        return out;
    }

    private static void concatBrightness(ColorMatrix cm, float b) {
        ColorMatrix m = new ColorMatrix(new float[]{
                1, 0, 0, 0, b,
                0, 1, 0, 0, b,
                0, 0, 1, 0, b,
                0, 0, 0, 1, 0});
        cm.postConcat(m);
    }

    private static void concatContrast(ColorMatrix cm, float c) {
        float t = (1 - c) * 128f;
        ColorMatrix m = new ColorMatrix(new float[]{
                c, 0, 0, 0, t,
                0, c, 0, 0, t,
                0, 0, c, 0, t,
                0, 0, 0, 1, 0});
        cm.postConcat(m);
    }

    private static void concatWarm(ColorMatrix cm, float w) {
        // w>1 warm (more red, less blue), w<1 cool
        ColorMatrix m = new ColorMatrix(new float[]{
                w, 0, 0, 0, 0,
                0, 1, 0, 0, 0,
                0, 0, 2 - w, 0, 0,
                0, 0, 0, 1, 0});
        cm.postConcat(m);
    }

    // ---- adjust: brightness -100..100, contrast 0..200 (100=normal), saturation 0..200, warmth 0..200, highlights -100..100, shadows -100..100, sharpness 0..100 ----
    public static Bitmap adjust(Bitmap src, int brightness, int contrast, int saturation, int warmth, int highlights, int shadows, int sharpness) {
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(saturation / 100f);
        concatContrast(cm, contrast / 100f);
        concatBrightness(cm, brightness * 1.27f);
        concatWarm(cm, warmth / 100f);
        Bitmap out = applyMatrix(src, cm);
        if (highlights != 0 || shadows != 0) {
            out = applyToneCurve(out, highlights, shadows);
        }
        if (sharpness > 0) {
            out = sharpen(out, sharpness / 100f);
        }
        return out;
    }

    private static Bitmap applyToneCurve(Bitmap src, int highlights, int shadows) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            float v = i / 255f;
            // shadows: lift dark values
            if (shadows != 0) {
                float s = shadows / 100f;
                if (s > 0) v = v + (1 - v) * (1 - v) * s * 0.45f;
                else v = v * (1 + s * 0.45f * (1 - v));
            }
            // highlights: compress/expand bright values
            if (highlights != 0) {
                float hl = highlights / 100f;
                if (hl > 0) v = v + (1 - v) * v * hl * 0.5f;
                else v = v - v * v * (-hl) * 0.5f;
            }
            lut[i] = Math.max(0, Math.min(255, Math.round(v * 255)));
        }
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            int a = (p >>> 24) & 0xFF;
            int r = lut[(p >> 16) & 0xFF];
            int g = lut[(p >> 8) & 0xFF];
            int b = lut[p & 0xFF];
            px[i] = (a << 24) | (r << 16) | (g << 8) | b;
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    private static Bitmap sharpen(Bitmap src, float amount) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] out = new int[w * h];
        float center = 1 + 4 * amount;
        float edge = -amount;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                int c = px[i];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                int r2 = 0, g2 = 0, b2 = 0;
                // 3x3 kernel: center, N, S, E, W
                int[] nb = {i, i - w, i + w, i - 1, i + 1};
                float[] wt = {center, edge, edge, edge, edge};
                boolean[] ok = {true, y > 0, y < h - 1, x > 0, x < w - 1};
                for (int k = 0; k < 5; k++) {
                    if (!ok[k]) continue;
                    int p2 = px[nb[k]];
                    r2 += (int) (((p2 >> 16) & 0xFF) * wt[k]);
                    g2 += (int) (((p2 >> 8) & 0xFF) * wt[k]);
                    b2 += (int) ((p2 & 0xFF) * wt[k]);
                }
                r2 = Math.max(0, Math.min(255, r2));
                g2 = Math.max(0, Math.min(255, g2));
                b2 = Math.max(0, Math.min(255, b2));
                out[i] = (c & 0xFF000000) | (r2 << 16) | (g2 << 8) | b2;
            }
        }
        Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        res.setPixels(out, 0, w, 0, 0, w, h);
        return res;
    }

    // ---- auto enhance: histogram stretch + saturation + mild sharpen ----
    public static Bitmap autoEnhance(Bitmap src) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] hist = new int[256];
        for (int p : px) {
            int lum = (int) (0.299 * ((p >> 16) & 0xFF) + 0.587 * ((p >> 8) & 0xFF) + 0.114 * (p & 0xFF));
            hist[lum]++;
        }
        int total = px.length;
        int lo = 0, hi = 255;
        int acc = 0;
        for (int i = 0; i < 256; i++) {
            acc += hist[i];
            if (acc > total * 0.01) { lo = i; break; }
        }
        acc = 0;
        for (int i = 255; i >= 0; i--) {
            acc += hist[i];
            if (acc > total * 0.01) { hi = i; break; }
        }
        if (hi <= lo) hi = lo + 1;
        int[] lut = new int[256];
        for (int i = 0; i < 256; i++) {
            int v = (i - lo) * 255 / (hi - lo);
            lut[i] = Math.max(0, Math.min(255, v));
        }
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            int r = lut[(p >> 16) & 0xFF];
            int g = lut[(p >> 8) & 0xFF];
            int b = lut[p & 0xFF];
            // slight saturation boost: move away from luminance
            int lum = (r + g + b) / 3;
            r = clamp(lum + (int) ((r - lum) * 1.15f));
            g = clamp(lum + (int) ((g - lum) * 1.15f));
            b = clamp(lum + (int) ((b - lum) * 1.15f));
            px[i] = (p & 0xFF000000) | (r << 16) | (g << 8) | b;
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return sharpen(out, 0.35f);
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    // ---- geometry ----
    public static Bitmap rotate(Bitmap src, float degrees) {
        Matrix m = new Matrix();
        m.postRotate(degrees);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
    }
    public static Bitmap flipH(Bitmap src) {
        Matrix m = new Matrix();
        m.preScale(-1, 0);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
    }
    public static Bitmap flipV(Bitmap src) {
        Matrix m = new Matrix();
        m.preScale(0, -1);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
    }
    public static Bitmap scaleTo(Bitmap src, int maxDim) {
        int w = src.getWidth(), h = src.getHeight();
        int max = Math.max(w, h);
        if (max <= maxDim) return src;
        float s = (float) maxDim / max;
        return Bitmap.createScaledBitmap(src, Math.round(w * s), Math.round(h * s), true);
    }

    // ---- simple diffusion inpainting: fills mask with neighbour averages (iterative) ----
    // mask: same size as src, white pixels = region to erase. Works on downscaled copy.
    public static Bitmap inpaint(Bitmap src, Bitmap mask) {
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getPixels(px, 0, w, 0, 0, w, h);
        int[] mk = new int[w * h];
        mask.getPixels(mk, 0, w, 0, 0, w, h);
        boolean[] hole = new boolean[w * h];
        for (int i = 0; i < mk.length; i++) {
            hole[i] = ((mk[i] >> 16) & 0xFF) > 128;
        }
        // iterative fill from the border inward
        for (int iter = 0; iter < 400; iter++) {
            boolean changed = false;
            int[] next = px.clone();
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    if (!hole[i]) continue;
                    int r = 0, g = 0, b = 0, n = 0;
                    if (x > 0 && !hole[i - 1]) { int p = px[i - 1]; r += (p >> 16) & 0xFF; g += (p >> 8) & 0xFF; b += p & 0xFF; n++; }
                    if (x < w - 1 && !hole[i + 1]) { int p = px[i + 1]; r += (p >> 16) & 0xFF; g += (p >> 8) & 0xFF; b += p & 0xFF; n++; }
                    if (y > 0 && !hole[i - w]) { int p = px[i - w]; r += (p >> 16) & 0xFF; g += (p >> 8) & 0xFF; b += p & 0xFF; n++; }
                    if (y < h - 1 && !hole[i + w]) { int p = px[i + w]; r += (p >> 16) & 0xFF; g += (p >> 8) & 0xFF; b += p & 0xFF; n++; }
                    if (n > 0) {
                        next[i] = (px[i] & 0xFF000000) | ((r / n) << 16) | ((g / n) << 8) | (b / n);
                        hole[i] = false;
                        changed = true;
                    }
                }
            }
            px = next;
            if (!changed) break;
        }
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(px, 0, w, 0, 0, w, h);
        return out;
    }

    // ---- save ----
    public static Uri saveToGallery(Context c, Bitmap bmp, String baseName) {
        String name = baseName + "_" + System.currentTimeMillis() + ".jpg";
        try {
            ContentResolver cr = c.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Gallery");
                v.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return null;
            OutputStream out = cr.openOutputStream(uri);
            if (out == null) return null;
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, out);
            out.close();
            if (Build.VERSION.SDK_INT >= 29) {
                v.clear();
                v.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(uri, v, null, null);
            }
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    public static File saveToFile(File dir, Bitmap bmp, String name) {
        try {
            dir.mkdirs();
            File f = new File(dir, name);
            FileOutputStream out = new FileOutputStream(f);
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, out);
            out.close();
            return f;
        } catch (Exception e) {
            return null;
        }
    }
}
