package io.github.advocateatul.gallery.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import io.github.advocateatul.gallery.util.MediaActions;
import io.github.advocateatul.gallery.util.UiUtils;
import java.util.ArrayList;
import java.util.List;

public class TrashActivity extends AppCompatActivity {
    private List<GalleryDb.TrashRow> rows = new ArrayList<GalleryDb.TrashRow>();
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private MediaGridAdapter adapter;
    private TextView actionView;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_list);
        ((TextView) findViewById(R.id.title)).setText(R.string.menu_trash);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        actionView = findViewById(R.id.action);
        actionView.setVisibility(View.VISIBLE);
        actionView.setText(R.string.trash_empty_title);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmEmpty(); }
        });
        RecyclerView list = findViewById(R.id.list);
        GridLayoutManager lm = new GridLayoutManager(this, 3);
        lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER ? 3 : 1;
            }
        });
        list.setLayoutManager(lm);
        adapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {
                showItemMenu(item);
            }
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {}
        });
        list.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        new Thread(new Runnable() {
            @Override public void run() {
                // prune expired / gone rows
                List<GalleryDb.TrashRow> all = GalleryDb.get(TrashActivity.this).listTrash();
                List<GalleryDb.TrashRow> gone = new ArrayList<GalleryDb.TrashRow>();
                final List<MediaItem> found = new ArrayList<MediaItem>();
                final List<GalleryDb.TrashRow> kept = new ArrayList<GalleryDb.TrashRow>();
                for (GalleryDb.TrashRow r : all) {
                    MediaItem m = MediaRepo.getByKeyTrashed(TrashActivity.this, r.id);
                    if (m == null) {
                        // legacy trash (API <30): file was moved out of MediaStore;
                        // build a display item from the stored file, or prune if gone
                        java.io.File f = new java.io.File(r.path);
                        if (!f.exists()) { gone.add(r); continue; }
                        m = new MediaItem();
                        try { m.id = Long.parseLong(r.id.substring(1)); } catch (Exception e) { m.id = 0; }
                        m.isVideo = r.isVideo;
                        m.uri = android.net.Uri.fromFile(f);
                        m.name = r.name;
                        m.mime = r.mime;
                        m.dateTaken = r.dateAdded;
                        m.dateAdded = r.dateAdded;
                        m.thumbFile = r.path;
                    }
                    m.name = r.name;
                    found.add(m);
                    kept.add(r);
                }
                for (GalleryDb.TrashRow r : gone) GalleryDb.get(TrashActivity.this).removeTrash(r.id);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        rows = kept;
                        items = found;
                        findViewById(R.id.empty).setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                        ((android.widget.ImageView) findViewById(R.id.empty_icon)).setImageResource(R.drawable.ic_trash);
                        ((android.widget.TextView) findViewById(R.id.empty_text)).setText(R.string.empty_trash);
                        adapter.setItems(items, false);
                    }
                });
            }
        }).start();
    }

    private void showItemMenu(final MediaItem item) {
        GalleryDb.TrashRow row = null;
        for (GalleryDb.TrashRow r : rows) if (r.id.equals(item.key())) row = r;
        if (row == null) return;
        final GalleryDb.TrashRow fr = row;
        long daysLeft = Math.max(0, (fr.expiry - System.currentTimeMillis()) / (24 * 60 * 60 * 1000));
        final String[] opts = {
                getString(R.string.action_restore) + "  ·  " + getString(R.string.trash_days_left, (int) daysLeft),
                getString(R.string.action_delete_forever)
        };
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(item.name)
                .setItems(opts, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            ArrayList<GalleryDb.TrashRow> one = new ArrayList<GalleryDb.TrashRow>();
                            one.add(fr);
                            MediaActions.restoreTrash(TrashActivity.this, one, new MediaActions.Done() {
                                @Override public void run(boolean ok) {
                                    if (ok) UiUtils.toast(TrashActivity.this, R.string.trash_restored);
                                    refresh();
                                }
                            });
                        } else {
                            confirmDeleteOne(fr);
                        }
                    }
                }).show();
    }

    private void confirmDeleteOne(final GalleryDb.TrashRow row) {
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.trash_delete_title)
                .setMessage(R.string.trash_delete_msg)
                .setPositiveButton(R.string.action_delete, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        ArrayList<GalleryDb.TrashRow> one = new ArrayList<GalleryDb.TrashRow>();
                        one.add(row);
                        MediaActions.deleteForever(TrashActivity.this, one, new MediaActions.Done() {
                            @Override public void run(boolean ok) {
                                if (ok) UiUtils.toast(TrashActivity.this, R.string.trash_deleted);
                                refresh();
                            }
                        });
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void confirmEmpty() {
        if (rows.isEmpty()) return;
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.trash_empty_title)
                .setMessage(R.string.trash_empty_msg)
                .setPositiveButton(R.string.action_delete, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        MediaActions.deleteForever(TrashActivity.this, new ArrayList<GalleryDb.TrashRow>(rows), new MediaActions.Done() {
                            @Override public void run(boolean ok) {
                                if (ok) UiUtils.toast(TrashActivity.this, R.string.trash_empty_done);
                                refresh();
                            }
                        });
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MediaActions.REQ_DELETE) {
            if (resultCode == RESULT_OK) MediaActions.noteDelete(this);
            else MediaActions.cancelDelete();
            refresh();
        } else if (requestCode == MediaActions.REQ_RESTORE_TRASH) {
            if (resultCode == RESULT_OK) MediaActions.noteRestore(this);
            else MediaActions.cancelRestore();
            refresh();
        }
    }
}
