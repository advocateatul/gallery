package io.github.advocateatul.gallery.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import io.github.advocateatul.gallery.data.SmartEngine;
import io.github.advocateatul.gallery.util.ThumbLoader;
import java.util.ArrayList;
import java.util.List;

public class StoriesFragment extends Fragment {
    private RecyclerView memoriesView, storiesView;
    private View empty;
    private List<SmartEngine.Story> stories = new ArrayList<SmartEngine.Story>();
    private List<MemoryCard> memories = new ArrayList<MemoryCard>();

    static class MemoryCard {
        String title, sub;
        List<MediaItem> items;
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle saved) {
        View v = inf.inflate(R.layout.fragment_stories, parent, false);
        memoriesView = v.findViewById(R.id.memories);
        storiesView = v.findViewById(R.id.stories);
        empty = v.findViewById(R.id.empty);
        memoriesView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        storiesView.setLayoutManager(new LinearLayoutManager(getContext()));
        memoriesView.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return memories.size(); }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View item = LayoutInflater.from(p.getContext()).inflate(R.layout.item_memory, p, false);
                return new RecyclerView.ViewHolder(item) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                final MemoryCard m = memories.get(pos);
                ImageView cover = h.itemView.findViewById(R.id.cover);
                ((TextView) h.itemView.findViewById(R.id.title)).setText(m.title);
                ((TextView) h.itemView.findViewById(R.id.sub)).setText(m.sub);
                if (!m.items.isEmpty()) ThumbLoader.get(h.itemView.getContext()).load(cover, m.items.get(0), 400);
                h.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        Intent i = new Intent(getContext(), MemoriesActivity.class);
                        i.putExtra("title", m.title);
                        i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(m.items));
                        startActivity(i);
                    }
                });
            }
        });
        storiesView.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return stories.size(); }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View item = LayoutInflater.from(p.getContext()).inflate(R.layout.item_story, p, false);
                return new RecyclerView.ViewHolder(item) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                final SmartEngine.Story s = stories.get(pos);
                ImageView cover = h.itemView.findViewById(R.id.cover);
                ((TextView) h.itemView.findViewById(R.id.title)).setText(s.title);
                ((TextView) h.itemView.findViewById(R.id.sub)).setText(s.sub);
                if (!s.items.isEmpty()) ThumbLoader.get(h.itemView.getContext()).load(cover, s.items.get(0), 300);
                h.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        Intent i = new Intent(getContext(), AlbumActivity.class);
                        i.putExtra("story_title", s.title);
                        i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(s.items));
                        startActivity(i);
                    }
                });
            }
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    public void refresh() {
        if (getContext() == null) return;
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> all = MediaRepo.queryAll(getContext(), GalleryApp.sortMode(getContext()));
                final List<SmartEngine.Story> st = SmartEngine.autoStories(all);
                final List<MediaItem> otd = SmartEngine.onThisDay(all);
                final List<MediaItem> best = SmartEngine.bestShots(getContext(), all, 12);
                final List<SmartEngine.SmartAlbum> smart = SmartEngine.smartAlbums(all);
                if (getActivity() == null) return;
                getActivity().runOnUiThread(new Runnable() {
                    @Override public void run() {
                        stories = st;
                        memories = new ArrayList<MemoryCard>();
                        if (!otd.isEmpty()) {
                            MemoryCard c = new MemoryCard();
                            c.title = getString(R.string.story_on_this_day);
                            c.sub = otd.size() + " photos";
                            c.items = otd;
                            memories.add(c);
                        }
                        if (!best.isEmpty()) {
                            MemoryCard c = new MemoryCard();
                            c.title = getString(R.string.story_best_shots);
                            c.sub = best.size() + " photos";
                            c.items = best;
                            memories.add(c);
                        }
                        for (SmartEngine.SmartAlbum a : smart) {
                            MemoryCard c = new MemoryCard();
                            c.title = a.title;
                            c.sub = a.items.size() + " photos";
                            c.items = a.items;
                            memories.add(c);
                        }
                        empty.setVisibility(stories.isEmpty() && memories.isEmpty() ? View.VISIBLE : View.GONE);
                        memoriesView.getAdapter().notifyDataSetChanged();
                        storiesView.getAdapter().notifyDataSetChanged();
                    }
                });
            }
        }).start();
    }
}
