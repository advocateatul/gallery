package io.github.advocateatul.gallery.ui;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import androidx.appcompat.widget.AppCompatImageView;

public class ZoomImageView extends AppCompatImageView {
    private Matrix matrix = new Matrix();
    private Matrix baseMatrix = new Matrix();
    private float[] m = new float[9];
    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;
    private float minScale = 1f;
    private float maxScale = 6f;
    private PointF last = new PointF();
    private boolean dragging = false;
    private OnSingleTapListener tapListener;

    public interface OnSingleTapListener { void onSingleTap(); }

    public ZoomImageView(Context c) { super(c); init(c); }
    public ZoomImageView(Context c, AttributeSet a) { super(c, a); init(c); }
    public ZoomImageView(Context c, AttributeSet a, int s) { super(c, a, s); init(c); }

    public void setOnSingleTapListener(OnSingleTapListener l) { tapListener = l; }

    private void init(Context c) {
        setScaleType(ScaleType.MATRIX);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                float factor = d.getScaleFactor();
                float cur = currentScale();
                float next = cur * factor;
                if (next < minScale) factor = minScale / cur;
                if (next > maxScale) factor = maxScale / cur;
                matrix.postScale(factor, factor, d.getFocusX(), d.getFocusY());
                fixBounds();
                setImageMatrix(matrix);
                return true;
            }
        });
        gestureDetector = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) {
                float cur = currentScale();
                float target = cur > minScale * 1.5f ? minScale : minScale * 2.5f;
                matrix.postScale(target / cur, target / cur, e.getX(), e.getY());
                fixBounds();
                setImageMatrix(matrix);
                return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (tapListener != null) tapListener.onSingleTap();
                return true;
            }
        });
    }

    public float currentScale() {
        matrix.getValues(m);
        return m[Matrix.MSCALE_X];
    }

    public void resetZoom() {
        setImageMatrix(baseMatrix);
        matrix.set(baseMatrix);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) fitImage();
    }

    @Override
    public void setImageDrawable(Drawable d) {
        super.setImageDrawable(d);
        fitImage();
    }

    private void fitImage() {
        Drawable d = getDrawable();
        if (d == null) return;
        int vw = getWidth(), vh = getHeight();
        if (vw == 0 || vh == 0) return;
        int dw = d.getIntrinsicWidth(), dh = d.getIntrinsicHeight();
        if (dw <= 0 || dh <= 0) return;
        float scale = Math.min((float) vw / dw, (float) vh / dh);
        minScale = scale;
        baseMatrix.reset();
        baseMatrix.postScale(scale, scale);
        baseMatrix.postTranslate((vw - dw * scale) / 2f, (vh - dh * scale) / 2f);
        matrix.set(baseMatrix);
        setImageMatrix(matrix);
    }

    private void fixBounds() {
        Drawable d = getDrawable();
        if (d == null) return;
        RectF r = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        matrix.mapRect(r);
        float dx = 0, dy = 0;
        int vw = getWidth(), vh = getHeight();
        if (r.width() <= vw) {
            dx = (vw - r.width()) / 2f - r.left;
        } else {
            if (r.left > 0) dx = -r.left;
            if (r.right < vw) dx = vw - r.right;
        }
        if (r.height() <= vh) {
            dy = (vh - r.height()) / 2f - r.top;
        } else {
            if (r.top > 0) dy = -r.top;
            if (r.bottom < vh) dy = vh - r.bottom;
        }
        matrix.postTranslate(dx, dy);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        gestureDetector.onTouchEvent(e);
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            last.set(e.getX(), e.getY());
            dragging = currentScale() > minScale * 1.01f;
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (dragging && !scaleDetector.isInProgress()) {
                float dx = e.getX() - last.x;
                float dy = e.getY() - last.y;
                matrix.postTranslate(dx, dy);
                fixBounds();
                setImageMatrix(matrix);
                last.set(e.getX(), e.getY());
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            dragging = false;
        }
        // consume the event only when zoomed (so ViewPager2 can swipe otherwise)
        if (currentScale() > minScale * 1.01f) {
            getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        }
        return super.onTouchEvent(e);
    }
}
