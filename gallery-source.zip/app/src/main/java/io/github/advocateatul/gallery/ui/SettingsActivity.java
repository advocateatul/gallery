package io.github.advocateatul.gallery.ui;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;

public class SettingsActivity extends AppCompatActivity {
    private LinearLayout rows;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_settings);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        rows = findViewById(R.id.rows);
        rebuild();
    }

    private void rebuild() {
        rows.removeAllViews();
        String lang = GalleryApp.prefs(this).getString(GalleryApp.PREF_LANG, "");
        addRow(R.drawable.ic_language, R.string.settings_language,
                "hi".equals(lang) ? getString(R.string.settings_hindi) : getString(R.string.settings_english),
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showLanguageDialog(); }
                });
        addRow(R.drawable.ic_grid, R.string.settings_grid,
                String.valueOf(GalleryApp.gridSpan(this)),
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showGridDialog(); }
                });
        int ms = GalleryApp.slideshowMs(this);
        addRow(R.drawable.ic_slideshow, R.string.settings_slideshow_speed,
                (ms / 1000) + "s",
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showSlideshowDialog(); }
                });
        java.util.Set<String> hidden = AlbumsFragment.hiddenBuckets(this);
        addRow(R.drawable.ic_albums, R.string.settings_hidden,
                hidden.isEmpty() ? getString(R.string.settings_hidden_none) : String.valueOf(hidden.size()),
                new View.OnClickListener() {
                    @Override public void onClick(View v) { showHiddenDialog(); }
                });
        addRow(R.drawable.ic_info, R.string.settings_about, "", new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(SettingsActivity.this, R.style.Theme_Gallery_Dialog)
                        .setTitle(R.string.settings_about)
                        .setMessage(R.string.about_text)
                        .setPositiveButton(R.string.action_ok, null)
                        .show();
            }
        });
        addRow(R.drawable.ic_pictures, R.string.settings_version, getString(R.string.settings_version), null);
    }

    private void addRow(int icon, int labelRes, String value, View.OnClickListener l) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_row, rows, false);
        ((ImageView) row.findViewById(R.id.icon)).setImageResource(icon);
        ((TextView) row.findViewById(R.id.label)).setText(labelRes);
        ((TextView) row.findViewById(R.id.value)).setText(value);
        if (l != null) row.setOnClickListener(l);
        rows.addView(row);
    }

    private void showHiddenDialog() {
        final java.util.Set<String> hidden = AlbumsFragment.hiddenBuckets(this);
        if (hidden.isEmpty()) {
            new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                    .setTitle(R.string.settings_hidden)
                    .setMessage(R.string.settings_hidden_none)
                    .setPositiveButton(R.string.action_ok, null)
                    .show();
            return;
        }
        final String[] names = hidden.toArray(new String[0]);
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.settings_hidden)
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        java.util.Set<String> s = AlbumsFragment.hiddenBuckets(SettingsActivity.this);
                        s.remove(names[which]);
                        AlbumsFragment.setHidden(SettingsActivity.this, s);
                        rebuild();
                    }
                }).show();
    }

    private void showLanguageDialog() {
        final String[] langs = {getString(R.string.settings_english), getString(R.string.settings_hindi)};
        String cur = GalleryApp.prefs(this).getString(GalleryApp.PREF_LANG, "");
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.menu_language)
                .setSingleChoiceItems(langs, "hi".equals(cur) ? 1 : 0, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        GalleryApp.prefs(SettingsActivity.this).edit()
                                .putString(GalleryApp.PREF_LANG, which == 1 ? "hi" : "en").apply();
                        d.dismiss();
                        recreate();
                    }
                }).show();
    }

    private void showGridDialog() {
        final String[] opts = {"2", "3", "4", "5"};
        int cur = GalleryApp.gridSpan(this) - 2;
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.settings_grid)
                .setSingleChoiceItems(opts, cur, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        GalleryApp.setGridSpan(SettingsActivity.this, which + 2);
                        d.dismiss();
                        rebuild();
                    }
                }).show();
    }

    private void showSlideshowDialog() {
        final String[] opts = {"2s", "3s", "5s"};
        final int[] vals = {2000, 3000, 5000};
        int cur = GalleryApp.slideshowMs(this);
        int checked = cur <= 2000 ? 0 : cur <= 3000 ? 1 : 2;
        new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.settings_slideshow_speed)
                .setSingleChoiceItems(opts, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        GalleryApp.prefs(SettingsActivity.this).edit()
                                .putInt(GalleryApp.PREF_SLIDESHOW, vals[which]).apply();
                        d.dismiss();
                        rebuild();
                    }
                }).show();
    }
}
