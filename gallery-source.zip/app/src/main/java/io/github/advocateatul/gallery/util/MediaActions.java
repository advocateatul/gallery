package io.github.advocateatul.gallery.util;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Trash / restore / secure-folder / share helpers.
 *  API 30+: system trash + delete requests (user consent via IntentSender).
 *  API 26-29: direct file operations with WRITE_EXTERNAL_STORAGE. */
public class MediaActions {
    public static final int REQ_TRASH = 1001;
    public static final int REQ_DELETE = 1002;
    public static final int REQ_RESTORE_TRASH = 1003;
    public static final long TRASH_DAYS_MS = 30L * 24 * 60 * 60 * 1000;

    public interface Done { void run(boolean ok); }

    // ---- trash ----
    public static void moveToTrash(final Activity act, final List<MediaItem> items, final Done done) {
        if (items == null || items.isEmpty()) { done.run(false); return; }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ArrayList<Uri> uris = new ArrayList<Uri>();
                for (MediaItem m : items) uris.add(m.uri);
                PendingIntent pi = MediaStore.createTrashRequest(act.getContentResolver(), uris, true);
                act.startIntentSenderForResult(pi.getIntentSender(), REQ_TRASH, null, 0, 0, 0, null);
                // DB rows are added by the caller in onActivityResult (see noteTrash)
                pendingTrash = new ArrayList<MediaItem>(items);
                pendingDone = done;
            } catch (Exception e) {
                done.run(false);
            }
        } else {
            boolean ok = true;
            for (MediaItem m : items) {
                if (!legacyMoveToTrash(act, m)) ok = false;
            }
            done.run(ok);
        }
    }

    public static List<MediaItem> pendingTrash;
    public static Done pendingDone;

    /** Call from onActivityResult(REQ_TRASH, RESULT_OK). */
    public static void noteTrash(Context c) {
        if (pendingTrash == null) return;
        long expiry = System.currentTimeMillis() + TRASH_DAYS_MS;
        GalleryDb db = GalleryDb.get(c);
        for (MediaItem m : pendingTrash) db.addTrash(m, expiry);
        if (pendingDone != null) pendingDone.run(true);
        pendingTrash = null;
        pendingDone = null;
    }
    public static void cancelTrash() {
        if (pendingDone != null) pendingDone.run(false);
        pendingTrash = null;
        pendingDone = null;
    }

    private static boolean legacyMoveToTrash(Context c, MediaItem m) {
        try {
            File trashDir = new File(c.getExternalFilesDir(null), "trash");
            trashDir.mkdirs();
            File src = m.path != null ? new File(m.path) : null;
            if (src != null && src.exists()) {
                File dst = new File(trashDir, m.key() + "_" + src.getName());
                if (src.renameTo(dst) || copyFile(src, dst)) {
                    if (src.exists()) src.delete();
                    GalleryDb.get(c).addTrash(m, System.currentTimeMillis() + TRASH_DAYS_MS);
                    // update path in DB row to the trash location
                    GalleryDb.get(c).getWritableDatabase().execSQL(
                            "UPDATE trash SET path=? WHERE id=?",
                            new Object[]{dst.getAbsolutePath(), m.key()});
                    c.getContentResolver().delete(m.uri, null, null);
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean copyFile(File src, File dst) {
        try {
            FileInputStream in = new FileInputStream(src);
            FileOutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // restore a trashed item (system trash on 30+, legacy file move below)
    public static void restoreTrash(final Activity act, final List<GalleryDb.TrashRow> rows, final Done done) {
        if (rows == null || rows.isEmpty()) { done.run(false); return; }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ArrayList<Uri> uris = new ArrayList<Uri>();
                for (GalleryDb.TrashRow r : rows) {
                    boolean video = r.isVideo;
                    Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    long id = Long.parseLong(r.id.substring(1));
                    uris.add(android.content.ContentUris.withAppendedId(base, id));
                }
                PendingIntent pi = MediaStore.createTrashRequest(act.getContentResolver(), uris, false);
                pendingRestore = new ArrayList<GalleryDb.TrashRow>(rows);
                pendingRestoreDone = done;
                act.startIntentSenderForResult(pi.getIntentSender(), REQ_RESTORE_TRASH, null, 0, 0, 0, null);
            } catch (Exception e) {
                done.run(false);
            }
        } else {
            boolean ok = true;
            for (GalleryDb.TrashRow r : rows) {
                if (!legacyRestore(act, r)) ok = false;
            }
            done.run(ok);
        }
    }

    public static List<GalleryDb.TrashRow> pendingRestore;
    public static Done pendingRestoreDone;

    public static void noteRestore(Context c) {
        if (pendingRestore == null) return;
        GalleryDb db = GalleryDb.get(c);
        for (GalleryDb.TrashRow r : pendingRestore) db.removeTrash(r.id);
        if (pendingRestoreDone != null) pendingRestoreDone.run(true);
        pendingRestore = null;
        pendingRestoreDone = null;
    }
    public static void cancelRestore() {
        if (pendingRestoreDone != null) pendingRestoreDone.run(false);
        pendingRestore = null;
        pendingRestoreDone = null;
    }

    private static boolean legacyRestore(Context c, GalleryDb.TrashRow r) {
        try {
            File trashFile = new File(r.path);
            if (!trashFile.exists()) return false;
            File dest = new File(android.os.Environment.getExternalStoragePublicDirectory(
                    android.os.Environment.DIRECTORY_PICTURES), r.name);
            if (!copyFile(trashFile, dest)) return false;
            trashFile.delete();
            android.media.MediaScannerConnection.scanFile(c, new String[]{dest.getAbsolutePath()}, null, null);
            GalleryDb.get(c).removeTrash(r.id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // permanent delete (already trashed on 30+ -> delete request; legacy -> file delete)
    public static void deleteForever(final Activity act, final List<GalleryDb.TrashRow> rows, final Done done) {
        if (rows == null || rows.isEmpty()) { done.run(false); return; }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ArrayList<Uri> uris = new ArrayList<Uri>();
                for (GalleryDb.TrashRow r : rows) {
                    Uri base = r.isVideo ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    long id = Long.parseLong(r.id.substring(1));
                    uris.add(android.content.ContentUris.withAppendedId(base, id));
                }
                PendingIntent pi = MediaStore.createDeleteRequest(act.getContentResolver(), uris);
                pendingDelete = new ArrayList<GalleryDb.TrashRow>(rows);
                pendingDeleteDone = done;
                act.startIntentSenderForResult(pi.getIntentSender(), REQ_DELETE, null, 0, 0, 0, null);
            } catch (Exception e) {
                done.run(false);
            }
        } else {
            boolean ok = true;
            for (GalleryDb.TrashRow r : rows) {
                File f = new File(r.path);
                if (f.exists() && !f.delete()) ok = false;
                GalleryDb.get(c(act)).removeTrash(r.id);
            }
            done.run(ok);
        }
    }
    private static Context c(Activity a) { return a; }

    public static List<GalleryDb.TrashRow> pendingDelete;
    public static Done pendingDeleteDone;

    public static void noteDelete(Context c) {
        if (pendingDelete == null) return;
        GalleryDb db = GalleryDb.get(c);
        for (GalleryDb.TrashRow r : pendingDelete) {
            db.removeTrash(r.id);
            File f = new File(r.path);
            if (f.exists()) f.delete();
        }
        if (pendingDeleteDone != null) pendingDeleteDone.run(true);
        pendingDelete = null;
        pendingDeleteDone = null;
    }
    public static void cancelDelete() {
        if (pendingDeleteDone != null) pendingDeleteDone.run(false);
        pendingDelete = null;
        pendingDeleteDone = null;
    }

    // ---- secure folder: move media bytes into app-private storage ----
    public static boolean moveToSecure(Context c, MediaItem m) {
        try {
            File dir = new File(c.getFilesDir(), "secure");
            dir.mkdirs();
            String id = UUID.randomUUID().toString();
            String ext = ".jpg";
            if (m.name != null && m.name.contains(".")) ext = m.name.substring(m.name.lastIndexOf('.'));
            if (m.isVideo) ext = ".mp4";
            File dst = new File(dir, id + ext);
            InputStream in = c.getContentResolver().openInputStream(m.uri);
            if (in == null) return false;
            FileOutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            GalleryDb.get(c).addSecure(id, dst.getName(), m.mime, dst.length(), m.name);
            // delete original
            if (Build.VERSION.SDK_INT >= 30) {
                // direct delete of own media is allowed without consent on 30+ only for
                // files the app created; for others use delete request. Fall back to
                // ContentResolver.delete and let the caller handle failure.
                int deleted = c.getContentResolver().delete(m.uri, null, null);
                if (deleted <= 0) {
                    // keep the secure copy; original remains (user can delete manually)
                    return true;
                }
            } else {
                c.getContentResolver().delete(m.uri, null, null);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean restoreFromSecure(Context c, GalleryDb.SecureRow row) {
        try {
            File src = new File(new File(c.getFilesDir(), "secure"), row.name);
            if (!src.exists()) return false;
            boolean video = row.mime != null && row.mime.startsWith("video");
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, row.origName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, row.mime);
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        android.os.Environment.DIRECTORY_PICTURES + "/Gallery");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            Uri uri = c.getContentResolver().insert(base, v);
            if (uri == null) return false;
            OutputStream out = c.getContentResolver().openOutputStream(uri);
            FileInputStream in = new FileInputStream(src);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v2 = new ContentValues();
                v2.put(MediaStore.MediaColumns.IS_PENDING, 0);
                c.getContentResolver().update(uri, v2, null, null);
            }
            src.delete();
            GalleryDb.get(c).removeSecure(row.id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static File secureFile(Context c, String name) {
        return new File(new File(c.getFilesDir(), "secure"), name);
    }

    // ---- share ----
    public static void share(Context c, List<MediaItem> items) {
        if (items == null || items.isEmpty()) return;
        Intent intent = new Intent(items.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
        intent.setType(items.size() == 1 ? items.get(0).mime : "*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (items.size() == 1) {
            intent.putExtra(Intent.EXTRA_STREAM, items.get(0).uri);
        } else {
            ArrayList<Uri> uris = new ArrayList<Uri>();
            for (MediaItem m : items) uris.add(m.uri);
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        c.startActivity(Intent.createChooser(intent, null));
    }
}
