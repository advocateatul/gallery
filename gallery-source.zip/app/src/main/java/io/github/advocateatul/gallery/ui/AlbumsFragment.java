package io.github.advocateatul.gallery.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import io.github.advocateatul.gallery.util.ThumbLoader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AlbumsFragment extends Fragment {
    private RecyclerView list;
    private View empty;
    private List<MediaRepo.Album> albums = new ArrayList<MediaRepo.Album>();
    private List<GalleryDb.CustomAlbum> customAlbums = new ArrayList<GalleryDb.CustomAlbum>();

    private static final String PREF_HIDDEN = "hidden_buckets";

    public static Set<String> hiddenBuckets(android.content.Context c) {
        return new HashSet<String>(GalleryApp.prefs(c).getStringSet(PREF_HIDDEN, new HashSet<String>()));
    }
    public static void setHidden(android.content.Context c, Set<String> s) {
        GalleryApp.prefs(c).edit().putStringSet(PREF_HIDDEN, s).apply();
    }

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup parent, Bundle saved) {
        View v = inf.inflate(R.layout.fragment_albums, parent, false);
        list = v.findViewById(R.id.list);
        empty = v.findViewById(R.id.empty);
        list.setLayoutManager(new GridLayoutManager(getContext(), 2));
        list.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return 1 + customAlbums.size() + albums.size(); }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View item = LayoutInflater.from(p.getContext()).inflate(R.layout.item_album, p, false);
                return new RecyclerView.ViewHolder(item) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                ImageView cover = h.itemView.findViewById(R.id.cover);
                TextView name = h.itemView.findViewById(R.id.name);
                TextView count = h.itemView.findViewById(R.id.count);
                if (pos == 0) {
                    // Create album card
                    cover.setImageResource(R.drawable.ic_add);
                    cover.setScaleType(ImageView.ScaleType.CENTER);
                    cover.setBackgroundResource(R.drawable.bg_album_cover);
                    name.setText(R.string.action_create_album);
                    count.setText("");
                    h.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { askCreateAlbum(); }
                    });
                    h.itemView.setOnLongClickListener(null);
                    return;
                }
                int idx = pos - 1;
                if (idx < customAlbums.size()) {
                    final GalleryDb.CustomAlbum a = customAlbums.get(idx);
                    name.setText(a.name);
                    count.setText(a.count + " items");
                    cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    if (a.coverKey != null) {
                        MediaItem m = MediaRepo.getByKey(h.itemView.getContext(), a.coverKey);
                        if (m != null) ThumbLoader.get(h.itemView.getContext()).load(cover, m, 480);
                        else cover.setImageResource(R.drawable.ic_albums);
                    } else {
                        cover.setImageResource(R.drawable.ic_albums);
                    }
                    h.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { openCustomAlbum(a); }
                    });
                    h.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override public boolean onLongClick(View v) {
                            confirmDeleteAlbum(a);
                            return true;
                        }
                    });
                    return;
                }
                final MediaRepo.Album a = albums.get(idx - customAlbums.size());
                name.setText(a.name);
                count.setText(a.count + " items" + (a.videoCount > 0 ? " · " + a.videoCount + " videos" : ""));
                cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                if (a.cover != null) ThumbLoader.get(h.itemView.getContext()).load(cover, a.cover, 480);
                h.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        Intent i = new Intent(getContext(), AlbumActivity.class);
                        i.putExtra("bucket", a.name);
                        startActivity(i);
                    }
                });
                h.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override public boolean onLongClick(View v) {
                        hideAlbum(a.name);
                        return true;
                    }
                });
            }
        });
        return v;
    }

    private void askCreateAlbum() {
        final EditText input = new EditText(getContext());
        input.setHint(R.string.action_create_album);
        input.setTextColor(getResources().getColor(R.color.oneui_text));
        new AlertDialog.Builder(getContext(), R.style.Theme_Gallery_Dialog)
                .setTitle(R.string.action_create_album)
                .setView(input)
                .setPositiveButton(R.string.action_done, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        String name = input.getText().toString().trim();
                        if (!name.isEmpty()) {
                            GalleryDb.get(getContext()).createAlbum(name);
                            refresh();
                        }
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void openCustomAlbum(final GalleryDb.CustomAlbum a) {
        new Thread(new Runnable() {
            @Override public void run() {
                final ArrayList<MediaItem> items = new ArrayList<MediaItem>();
                for (String key : GalleryDb.get(getContext()).albumItemKeys(a.id)) {
                    MediaItem m = MediaRepo.getByKey(getContext(), key);
                    if (m != null) items.add(m);
                }
                if (getActivity() == null) return;
                getActivity().runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Intent i = new Intent(getContext(), AlbumActivity.class);
                        i.putExtra("album_id", a.id);
                        i.putExtra("story_title", a.name);
                        i.putParcelableArrayListExtra("items", items);
                        startActivity(i);
                    }
                });
            }
        }).start();
    }

    private void confirmDeleteAlbum(final GalleryDb.CustomAlbum a) {
        new AlertDialog.Builder(getContext(), R.style.Theme_Gallery_Dialog)
                .setTitle(a.name)
                .setMessage(R.string.album_delete_msg)
                .setPositiveButton(R.string.action_delete, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        GalleryDb.get(getContext()).deleteAlbum(a.id);
                        refresh();
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    private void hideAlbum(String bucket) {
        Set<String> hidden = hiddenBuckets(getContext());
        hidden.add(bucket);
        setHidden(getContext(), hidden);
        refresh();
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    public void refresh() {
        if (getContext() == null) return;
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaRepo.Album> loaded = MediaRepo.queryAlbums(getContext());
                final Set<String> hidden = hiddenBuckets(getContext());
                final List<MediaRepo.Album> visible = new ArrayList<MediaRepo.Album>();
                for (MediaRepo.Album a : loaded) {
                    if (!hidden.contains(a.name)) visible.add(a);
                }
                final List<GalleryDb.CustomAlbum> customs = GalleryDb.get(getContext()).listCustomAlbums();
                if (getActivity() == null) return;
                getActivity().runOnUiThread(new Runnable() {
                    @Override public void run() {
                        albums = visible;
                        customAlbums = customs;
                        empty.setVisibility(albums.isEmpty() && customAlbums.isEmpty() ? View.VISIBLE : View.GONE);
                        list.getAdapter().notifyDataSetChanged();
                    }
                });
            }
        }).start();
    }
}
