package io.github.advocateatul.gallery.util;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.util.LruCache;
import android.util.Size;
import android.widget.ImageView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThumbLoader {
    private static ThumbLoader inst;
    private final LruCache<String, Bitmap> mem;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private File diskDir;

    public static synchronized ThumbLoader get(Context c) {
        if (inst == null) inst = new ThumbLoader(c.getApplicationContext());
        return inst;
    }

    private ThumbLoader(Context c) {
        int max = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheKb = max / 8;
        mem = new LruCache<String, Bitmap>(cacheKb) {
            @Override protected int sizeOf(String k, Bitmap b) {
                return b.getByteCount() / 1024;
            }
        };
        diskDir = new File(c.getCacheDir(), "thumbs");
        diskDir.mkdirs();
    }

    public void load(final ImageView view, final io.github.advocateatul.gallery.data.MediaItem item, final int sizePx) {
        final String key = item.key() + "_" + sizePx;
        view.setTag(key);
        Bitmap b = mem.get(key);
        if (b != null) { view.setImageBitmap(b); return; }
        File f = diskFile(key);
        if (f.exists()) {
            Bitmap db = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (db != null) { mem.put(key, db); view.setImageBitmap(db); return; }
        }
        view.setImageBitmap(null);
        final WeakReference<ImageView> ref = new WeakReference<ImageView>(view);
        final Context ctx = view.getContext().getApplicationContext();
        pool.execute(new Runnable() {
            @Override public void run() {
                Bitmap bmp = loadThumbSync(ctx, item.uri, item.isVideo, sizePx);
                if (bmp == null) return;
                mem.put(key, bmp);
                saveDisk(key, bmp);
                final ImageView v = ref.get();
                if (v == null) return;
                if (!key.equals(v.getTag())) return;
                v.post(new Runnable() {
                    @Override public void run() {
                        if (key.equals(v.getTag())) v.setImageBitmap(bmp);
                    }
                });
            }
        });
    }

    public void loadFile(final ImageView view, final File file, final int sizePx) {
        final String key = "f" + file.getAbsolutePath().hashCode() + "_" + sizePx;
        view.setTag(key);
        Bitmap b = mem.get(key);
        if (b != null) { view.setImageBitmap(b); return; }
        view.setImageBitmap(null);
        final WeakReference<ImageView> ref = new WeakReference<ImageView>(view);
        pool.execute(new Runnable() {
            @Override public void run() {
                Bitmap bmp = decodeScaled(file, sizePx);
                if (bmp == null) return;
                mem.put(key, bmp);
                final ImageView v = ref.get();
                if (v == null || !key.equals(v.getTag())) return;
                v.post(new Runnable() {
                    @Override public void run() {
                        if (key.equals(v.getTag())) v.setImageBitmap(bmp);
                    }
                });
            }
        });
    }

    public static Bitmap loadThumbSync(Context c, Uri uri, boolean video, int sizePx) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                return c.getContentResolver().loadThumbnail(uri, new Size(sizePx, sizePx), null);
            }
        } catch (Exception ignored) {}
        // fallback: decode scaled from stream
        try {
            InputStream in = c.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            int maxDim = Math.max(o.outWidth, o.outHeight);
            while (maxDim / sample > sizePx * 2) sample *= 2;
            in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    public static Bitmap decodeScaled(File file, int sizePx) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), o);
            int sample = 1;
            int maxDim = Math.max(o.outWidth, o.outHeight);
            while (maxDim / sample > sizePx * 2) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeFile(file.getAbsolutePath(), o2);
        } catch (Exception e) {
            return null;
        }
    }

    public static Bitmap loadFull(Context c, Uri uri, int maxDim) {
        try {
            InputStream in = c.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, o);
            in.close();
            int sample = 1;
            int max = Math.max(o.outWidth, o.outHeight);
            while (max / sample > maxDim) sample *= 2;
            in = c.getContentResolver().openInputStream(uri);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            o2.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private File diskFile(String key) {
        return new File(diskDir, String.valueOf(key.hashCode()) + ".jpg");
    }
    private void saveDisk(String key, Bitmap b) {
        try {
            FileOutputStream out = new FileOutputStream(diskFile(key));
            b.compress(Bitmap.CompressFormat.JPEG, 80, out);
            out.close();
        } catch (Exception ignored) {}
    }
    public void clearMemory() { mem.evictAll(); }
}
