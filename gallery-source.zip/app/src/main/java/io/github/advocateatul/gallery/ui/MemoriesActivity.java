package io.github.advocateatul.gallery.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import io.github.advocateatul.gallery.data.SmartEngine;
import java.util.ArrayList;
import java.util.List;

public class MemoriesActivity extends AppCompatActivity {
    private List<MediaItem> items = new ArrayList<MediaItem>();
    private MediaGridAdapter adapter;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_list);
        String t = getIntent().getStringExtra("title");
        ((android.widget.TextView) findViewById(R.id.title)).setText(t != null ? t : getString(R.string.story_memories));
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        RecyclerView list = findViewById(R.id.list);
        GridLayoutManager lm = new GridLayoutManager(this, 3);
        lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER ? 3 : 1;
            }
        });
        list.setLayoutManager(lm);
        adapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {
                Intent i = new Intent(MemoriesActivity.this, ViewerActivity.class);
                i.putParcelableArrayListExtra("items", new ArrayList<MediaItem>(items));
                i.putExtra("position", position);
                startActivity(i);
            }
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {}
        });
        list.setAdapter(adapter);
        final ArrayList<MediaItem> passed = getIntent().getParcelableArrayListExtra("items");
        if (passed != null) {
            items = passed;
            adapter.setItems(items, false);
            findViewById(R.id.empty).setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
            return;
        }
        findViewById(R.id.loading).setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> all = MediaRepo.queryAll(MemoriesActivity.this, GalleryApp.sortMode(MemoriesActivity.this));
                final List<MediaItem> out = new ArrayList<MediaItem>();
                out.addAll(SmartEngine.onThisDay(all));
                for (MediaItem m : SmartEngine.bestShots(MemoriesActivity.this, all, 12)) {
                    if (!out.contains(m)) out.add(m);
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        findViewById(R.id.loading).setVisibility(View.GONE);
                        items = out;
                        findViewById(R.id.empty).setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                        ((android.widget.TextView) findViewById(R.id.empty_text)).setText(R.string.empty_stories);
                        adapter.setItems(items, false);
                    }
                });
            }
        }).start();
    }
}
