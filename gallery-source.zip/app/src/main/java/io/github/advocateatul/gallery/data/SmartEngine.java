package io.github.advocateatul.gallery.data;

import android.content.Context;
import android.graphics.Bitmap;
import io.github.advocateatul.gallery.util.ThumbLoader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** On-device heuristics only: no ML model, no cloud. All scores come from
 *  thumbnail pixels + MediaStore metadata (date, location, size). */
public class SmartEngine {

    public static class CleanupResult {
        public List<List<MediaItem>> duplicates = new ArrayList<List<MediaItem>>();
        public List<MediaItem> blurry = new ArrayList<MediaItem>();
        public List<MediaItem> dark = new ArrayList<MediaItem>();
        public List<MediaItem> screenshots = new ArrayList<MediaItem>();
        public List<List<MediaItem>> similar = new ArrayList<List<MediaItem>>();
    }

    public static class SmartAlbum {
        public String title;
        public String sub;
        public List<MediaItem> items = new ArrayList<MediaItem>();
    }

    public static class Story {
        public String title;
        public String sub;
        public List<MediaItem> items = new ArrayList<MediaItem>();
    }

    // 8x8 average hash
    public static long aHash(Bitmap bmp) {
        if (bmp == null) return 0;
        Bitmap s = Bitmap.createScaledBitmap(bmp, 8, 8, true);
        int[] px = new int[64];
        s.getPixels(px, 0, 8, 0, 0, 8, 8);
        int[] gray = new int[64];
        long sum = 0;
        for (int i = 0; i < 64; i++) {
            int p = px[i];
            gray[i] = (int) (0.299 * ((p >> 16) & 0xFF) + 0.587 * ((p >> 8) & 0xFF) + 0.114 * (p & 0xFF));
            sum += gray[i];
        }
        int avg = (int) (sum / 64);
        long hash = 0;
        for (int i = 0; i < 64; i++) {
            if (gray[i] > avg) hash |= (1L << i);
        }
        if (s != bmp) s.recycle();
        return hash;
    }

    public static int hamming(long a, long b) {
        return Long.bitCount(a ^ b);
    }

    // Laplacian variance on a small grayscale bitmap -> sharpness score
    public static double blurScore(Bitmap bmp) {
        if (bmp == null) return 0;
        Bitmap s = Bitmap.createScaledBitmap(bmp, 32, 32, true);
        int w = 32, h = 32;
        int[] px = new int[w * h];
        s.getPixels(px, 0, w, 0, 0, w, h);
        double[] lap = new double[w * h];
        double sum = 0;
        int n = 0;
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                double c = gray(px[i]);
                double v = 4 * c - gray(px[i - 1]) - gray(px[i + 1]) - gray(px[i - w]) - gray(px[i + w]);
                lap[n++] = v;
                sum += v;
            }
        }
        if (n == 0) return 0;
        double mean = sum / n;
        double var = 0;
        for (int i = 0; i < n; i++) var += (lap[i] - mean) * (lap[i] - mean);
        var /= n;
        if (s != bmp) s.recycle();
        return var;
    }

    private static double gray(int p) {
        return 0.299 * ((p >> 16) & 0xFF) + 0.587 * ((p >> 8) & 0xFF) + 0.114 * (p & 0xFF);
    }

    public static double meanLuminance(Bitmap bmp) {
        if (bmp == null) return 0;
        Bitmap s = Bitmap.createScaledBitmap(bmp, 16, 16, true);
        int[] px = new int[256];
        s.getPixels(px, 0, 16, 0, 0, 16, 16);
        double sum = 0;
        for (int p : px) sum += gray(p);
        if (s != bmp) s.recycle();
        return sum / 256.0;
    }

    // quality score for "best shots": sharp + bright + big
    public static double qualityScore(Bitmap thumb, MediaItem m) {
        double sharp = Math.min(1.0, blurScore(thumb) / 120.0);
        double lum = meanLuminance(thumb);
        double bright = lum < 15 ? 0.2 : (lum > 235 ? 0.6 : 1.0);
        double sizeScore = Math.min(1.0, m.size / 1500000.0);
        return sharp * 0.55 + bright * 0.25 + sizeScore * 0.2;
    }

    public static CleanupResult scanCleanup(Context c, List<MediaItem> all) {
        CleanupResult r = new CleanupResult();
        Map<Long, List<MediaItem>> byHash = new HashMap<Long, List<MediaItem>>();
        List<MediaItem> photos = new ArrayList<MediaItem>();
        for (MediaItem m : all) {
            if (m.isVideo) continue;
            photos.add(m);
            String b = m.bucket == null ? "" : m.bucket.toLowerCase();
            String n = m.name == null ? "" : m.name.toLowerCase();
            if (b.contains("screenshot") || n.contains("screenshot")) r.screenshots.add(m);
        }
        // hash all photos (thumbnails, 64px)
        Map<MediaItem, Long> hashes = new HashMap<MediaItem, Long>();
        for (MediaItem m : photos) {
            Bitmap t = ThumbLoader.loadThumbSync(c, m.uri, false, 64);
            if (t == null) continue;
            long h = aHash(t);
            hashes.put(m, h);
            List<MediaItem> g = byHash.get(h);
            if (g == null) { g = new ArrayList<MediaItem>(); byHash.put(h, g); }
            g.add(m);
        }
        for (List<MediaItem> g : byHash.values()) {
            if (g.size() > 1) r.duplicates.add(g);
        }
        // similar: hamming 1..8 across different exact-hash groups
        List<MediaItem> hashed = new ArrayList<MediaItem>(hashes.keySet());
        boolean[] used = new boolean[hashed.size()];
        for (int i = 0; i < hashed.size(); i++) {
            if (used[i]) continue;
            List<MediaItem> grp = new ArrayList<MediaItem>();
            grp.add(hashed.get(i));
            for (int j = i + 1; j < hashed.size(); j++) {
                if (used[j]) continue;
                if (hamming(hashes.get(hashed.get(i)), hashes.get(hashed.get(j))) <= 6) {
                    grp.add(hashed.get(j));
                    used[j] = true;
                }
            }
            if (grp.size() > 1) { r.similar.add(grp); used[i] = true; }
        }
        // blurry + dark
        for (MediaItem m : photos) {
            Bitmap t = ThumbLoader.loadThumbSync(c, m.uri, false, 64);
            if (t == null) continue;
            double bs = blurScore(t);
            double lum = meanLuminance(t);
            if (bs < 45) r.blurry.add(m);
            else if (lum < 22) r.dark.add(m);
        }
        return r;
    }

    public static List<MediaItem> bestShots(Context c, List<MediaItem> all, int max) {
        List<MediaItem> photos = new ArrayList<MediaItem>();
        for (MediaItem m : all) if (!m.isVideo) photos.add(m);
        final Map<MediaItem, Double> scores = new HashMap<MediaItem, Double>();
        for (MediaItem m : photos) {
            Bitmap t = ThumbLoader.loadThumbSync(c, m.uri, false, 96);
            if (t == null) continue;
            scores.put(m, qualityScore(t, m));
        }
        Collections.sort(photos, new Comparator<MediaItem>() {
            @Override public int compare(MediaItem a, MediaItem b) {
                double sa = scores.containsKey(a) ? scores.get(a) : 0;
                double sb = scores.containsKey(b) ? scores.get(b) : 0;
                return Double.compare(sb, sa);
            }
        });
        List<MediaItem> out = new ArrayList<MediaItem>();
        for (MediaItem m : photos) {
            if (scores.containsKey(m) && scores.get(m) > 0.45) out.add(m);
            if (out.size() >= max) break;
        }
        return out;
    }

    public static List<MediaItem> onThisDay(List<MediaItem> all) {
        Calendar today = Calendar.getInstance();
        List<MediaItem> out = new ArrayList<MediaItem>();
        for (MediaItem m : all) {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(m.dateTaken);
            if (cal.get(Calendar.MONTH) == today.get(Calendar.MONTH)
                    && cal.get(Calendar.DAY_OF_MONTH) == today.get(Calendar.DAY_OF_MONTH)
                    && cal.get(Calendar.YEAR) < today.get(Calendar.YEAR)) {
                out.add(m);
            }
        }
        return out;
    }

    // smart albums: group by day + location cluster (0.1 degree grid)
    public static List<SmartAlbum> smartAlbums(List<MediaItem> all) {
        Map<String, SmartAlbum> map = new LinkedHashMap<String, SmartAlbum>();
        for (MediaItem m : all) {
            String locKey = m.hasLocation()
                    ? ((int) (m.lat * 10)) + "," + ((int) (m.lng * 10))
                    : "noloc";
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(m.dateTaken);
            String key = cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.DAY_OF_YEAR) + "-" + locKey;
            SmartAlbum a = map.get(key);
            if (a == null) {
                a = new SmartAlbum();
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale.getDefault());
                a.title = f.format(new java.util.Date(m.dateTaken));
                a.sub = m.hasLocation() ? "Photos with location" : (m.bucket != null ? m.bucket : "");
                map.put(key, a);
            }
            a.items.add(m);
        }
        List<SmartAlbum> out = new ArrayList<SmartAlbum>();
        for (SmartAlbum a : map.values()) {
            if (a.items.size() >= 3) out.add(a);
        }
        Collections.sort(out, new Comparator<SmartAlbum>() {
            @Override public int compare(SmartAlbum a, SmartAlbum b) {
                return Long.compare(b.items.get(0).dateTaken, a.items.get(0).dateTaken);
            }
        });
        return out;
    }

    // auto stories: one per day (last 60 days) with >= 3 items; older -> weekly rollup
    public static List<Story> autoStories(List<MediaItem> all) {
        Map<String, Story> map = new LinkedHashMap<String, Story>();
        java.text.SimpleDateFormat dayFmt = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
        java.text.SimpleDateFormat titleFmt = new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", java.util.Locale.getDefault());
        for (MediaItem m : all) {
            String day = dayFmt.format(new java.util.Date(m.dateTaken));
            Story s = map.get(day);
            if (s == null) {
                s = new Story();
                s.title = titleFmt.format(new java.util.Date(m.dateTaken));
                map.put(day, s);
            }
            s.items.add(m);
        }
        List<Story> out = new ArrayList<Story>();
        for (Story s : map.values()) {
            if (s.items.size() >= 3) {
                int photos = 0, videos = 0;
                for (MediaItem m : s.items) { if (m.isVideo) videos++; else photos++; }
                s.sub = photos + " photos" + (videos > 0 ? " · " + videos + " videos" : "");
                out.add(s);
            }
        }
        return out;
    }
}
