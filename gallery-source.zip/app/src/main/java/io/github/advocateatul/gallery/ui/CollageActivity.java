package io.github.advocateatul.gallery.ui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.GalleryApp;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.MediaItem;
import io.github.advocateatul.gallery.data.MediaRepo;
import io.github.advocateatul.gallery.util.ImageUtils;
import io.github.advocateatul.gallery.util.ThumbLoader;
import io.github.advocateatul.gallery.util.UiUtils;
import java.util.ArrayList;
import java.util.List;

public class CollageActivity extends AppCompatActivity {
    private ImageView preview;
    private RecyclerView picker;
    private List<MediaItem> all = new ArrayList<MediaItem>();
    private MediaGridAdapter adapter;
    private int layout = 0; // 0: 2 vertical, 1: 2 horizontal, 2: 3 (1 big + 2), 3: 4 grid
    private Bitmap previewBitmap;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_collage);
        preview = findViewById(R.id.preview);
        picker = findViewById(R.id.picker);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        findViewById(R.id.btn_save).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        });
        LinearLayout layouts = findViewById(R.id.layouts);
        final String[] names = {"2 ▮", "2 ▬", "3", "4"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView c = (TextView) LayoutInflater.from(this).inflate(R.layout.item_chip, layouts, false);
            c.setText(names[i]);
            if (idx == 0) c.setBackgroundResource(R.drawable.bg_chip_selected);
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    layout = idx;
                    for (int j = 0; j < layouts.getChildCount(); j++) {
                        layouts.getChildAt(j).setBackgroundResource(R.drawable.bg_chip);
                    }
                    v.setBackgroundResource(R.drawable.bg_chip_selected);
                    composePreview();
                }
            });
            layouts.addView(c);
        }
        GridLayoutManager lm = new GridLayoutManager(this, 4);
        lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int position) {
                return adapter != null && adapter.getItemViewType(position) == MediaGridAdapter.TYPE_HEADER ? 4 : 1;
            }
        });
        picker.setLayoutManager(lm);
        adapter = new MediaGridAdapter(this, new MediaGridAdapter.Listener() {
            @Override public void onClick(MediaItem item, int position) {}
            @Override public void onLongClick(MediaItem item, int position) {}
            @Override public void onSelectionChanged(int count) {
                if (count > 4) {
                    UiUtils.toast(CollageActivity.this, getString(R.string.collage_pick));
                    return;
                }
                composePreview();
            }
        });
        picker.setAdapter(adapter);
        new Thread(new Runnable() {
            @Override public void run() {
                final List<MediaItem> loaded = MediaRepo.queryAll(CollageActivity.this, GalleryApp.sortMode(CollageActivity.this));
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        all = loaded;
                        adapter.setItems(all, false);
                    }
                });
            }
        }).start();
    }

    private List<MediaItem> selected() {
        List<MediaItem> sel = adapter.getSelectedItems();
        return sel.size() > 4 ? sel.subList(0, 4) : sel;
    }

    private void composePreview() {
        final List<MediaItem> sel = selected();
        if (sel.isEmpty()) {
            preview.setImageBitmap(null);
            return;
        }
        final int lay = layout;
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap bmp = compose(sel, lay, 1080);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (previewBitmap != null) previewBitmap.recycle();
                        previewBitmap = bmp;
                        preview.setImageBitmap(bmp);
                    }
                });
            }
        }).start();
    }

    // compose selected photos into one bitmap; cells filled center-crop with white gaps
    public static Bitmap compose(List<MediaItem> sel, int layout, int size, android.content.Context ctx) {
        int n = sel.size();
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(Color.WHITE);
        int gap = 8;
        List<Bitmap> thumbs = new ArrayList<Bitmap>();
        for (MediaItem m : sel) {
            Bitmap b = ThumbLoader.loadThumbSync(ctx, m.uri, m.isVideo, 540);
            thumbs.add(b);
        }
        if (layout == 0 || n == 2) {
            // two side by side (or stacked if layout==1)
            boolean vertical = (layout == 0);
            for (int i = 0; i < Math.min(2, n); i++) {
                Rect dst;
                if (vertical) {
                    int w = (size - gap * 3) / 2;
                    dst = new Rect(gap + i * (w + gap), gap, gap + i * (w + gap) + w, size - gap);
                } else {
                    int h = (size - gap * 3) / 2;
                    dst = new Rect(gap, gap + i * (h + gap), size - gap, gap + i * (h + gap) + h);
                }
                drawFill(c, thumbs.get(i), dst);
            }
        } else if (layout == 2 && n >= 3) {
            int w = (size - gap * 3) / 2;
            drawFill(c, thumbs.get(0), new Rect(gap, gap, gap + w, size - gap));
            int h = (size - gap * 3) / 2;
            drawFill(c, thumbs.get(1), new Rect(gap * 2 + w, gap, size - gap, gap + h));
            drawFill(c, thumbs.get(2), new Rect(gap * 2 + w, gap * 2 + h, size - gap, size - gap));
        } else {
            // 2x2 grid
            int cell = (size - gap * 3) / 2;
            for (int i = 0; i < Math.min(4, n); i++) {
                int col = i % 2, row = i / 2;
                Rect dst = new Rect(gap + col * (cell + gap), gap + row * (cell + gap),
                        gap + col * (cell + gap) + cell, gap + row * (cell + gap) + cell);
                drawFill(c, thumbs.get(i), dst);
            }
        }
        for (Bitmap b : thumbs) if (b != null) b.recycle();
        return out;
    }

    private Bitmap compose(List<MediaItem> sel, int layout, int size) {
        return compose(sel, layout, size, this);
    }

    private static void drawFill(Canvas c, Bitmap b, Rect dst) {
        if (b == null) return;
        float scale = Math.max((float) dst.width() / b.getWidth(), (float) dst.height() / b.getHeight());
        int sw = (int) (dst.width() / scale), sh = (int) (dst.height() / scale);
        int sx = (b.getWidth() - sw) / 2, sy = (b.getHeight() - sh) / 2;
        c.drawBitmap(b, new Rect(sx, sy, sx + sw, sy + sh), dst, new Paint(Paint.FILTER_BITMAP_FLAG));
    }

    private void save() {
        final List<MediaItem> sel = selected();
        if (sel.size() < 2) {
            UiUtils.toast(this, R.string.collage_pick);
            return;
        }
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap bmp = compose(sel, layout, 1440, CollageActivity.this);
                final Uri uri = ImageUtils.saveToGallery(CollageActivity.this, bmp, "collage");
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (uri != null) {
                            UiUtils.toast(CollageActivity.this, R.string.edit_saved);
                            finish();
                        } else {
                            UiUtils.toast(CollageActivity.this, R.string.edit_save_failed);
                        }
                    }
                });
            }
        }).start();
    }
}
