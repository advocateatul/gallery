package io.github.advocateatul.gallery.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GalleryDb extends SQLiteOpenHelper {
    private static final String DB = "gallery.db";
    private static final int VER = 1;
    private static GalleryDb inst;

    public static synchronized GalleryDb get(Context c) {
        if (inst == null) inst = new GalleryDb(c.getApplicationContext());
        return inst;
    }

    private GalleryDb(Context c) { super(c, DB, null, VER); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE favorites (id TEXT PRIMARY KEY, isVideo INTEGER, added INTEGER)");
        db.execSQL("CREATE TABLE trash (id TEXT PRIMARY KEY, isVideo INTEGER, name TEXT, mime TEXT, path TEXT, dateAdded INTEGER, expiry INTEGER)");
        db.execSQL("CREATE TABLE secure (id TEXT PRIMARY KEY, name TEXT, mime TEXT, dateAdded INTEGER, size INTEGER, origName TEXT)");
        db.execSQL("CREATE TABLE custom_albums (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, created INTEGER)");
        db.execSQL("CREATE TABLE album_items (albumId INTEGER, mediaKey TEXT, PRIMARY KEY(albumId, mediaKey))");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int o, int n) {}

    // ---- favorites ----
    public void addFavorite(MediaItem m) {
        ContentValues v = new ContentValues();
        v.put("id", m.key()); v.put("isVideo", m.isVideo ? 1 : 0);
        v.put("added", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("favorites", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void removeFavorite(MediaItem m) {
        getWritableDatabase().delete("favorites", "id=?", new String[]{m.key()});
    }
    public Set<String> favoriteKeys() {
        Set<String> s = new HashSet<String>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id FROM favorites", null);
        while (c.moveToNext()) s.add(c.getString(0));
        c.close();
        return s;
    }

    // ---- trash ----
    public static class TrashRow {
        public String id; public boolean isVideo; public String name; public String mime;
        public String path; public long dateAdded; public long expiry;
    }
    public void addTrash(MediaItem m, long expiry) {
        ContentValues v = new ContentValues();
        v.put("id", m.key()); v.put("isVideo", m.isVideo ? 1 : 0);
        v.put("name", m.name); v.put("mime", m.mime); v.put("path", m.path);
        v.put("dateAdded", System.currentTimeMillis()); v.put("expiry", expiry);
        getWritableDatabase().insertWithOnConflict("trash", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void removeTrash(String key) {
        getWritableDatabase().delete("trash", "id=?", new String[]{key});
    }
    public List<TrashRow> listTrash() {
        List<TrashRow> out = new ArrayList<TrashRow>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,isVideo,name,mime,path,dateAdded,expiry FROM trash ORDER BY dateAdded DESC", null);
        while (c.moveToNext()) {
            TrashRow r = new TrashRow();
            r.id = c.getString(0); r.isVideo = c.getInt(1) == 1; r.name = c.getString(2);
            r.mime = c.getString(3); r.path = c.getString(4);
            r.dateAdded = c.getLong(5); r.expiry = c.getLong(6);
            out.add(r);
        }
        c.close();
        return out;
    }
    public List<TrashRow> expiredTrash() {
        List<TrashRow> out = new ArrayList<TrashRow>();
        long now = System.currentTimeMillis();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,isVideo,name,mime,path,dateAdded,expiry FROM trash WHERE expiry<=?", new String[]{String.valueOf(now)});
        while (c.moveToNext()) {
            TrashRow r = new TrashRow();
            r.id = c.getString(0); r.isVideo = c.getInt(1) == 1; r.name = c.getString(2);
            r.mime = c.getString(3); r.path = c.getString(4);
            r.dateAdded = c.getLong(5); r.expiry = c.getLong(6);
            out.add(r);
        }
        c.close();
        return out;
    }

    // ---- secure folder ----
    public static class SecureRow {
        public String id; public String name; public String mime; public long dateAdded; public long size; public String origName;
    }
    public void addSecure(String id, String name, String mime, long size, String origName) {
        ContentValues v = new ContentValues();
        v.put("id", id); v.put("name", name); v.put("mime", mime);
        v.put("dateAdded", System.currentTimeMillis()); v.put("size", size); v.put("origName", origName);
        getWritableDatabase().insertWithOnConflict("secure", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }
    public void removeSecure(String id) {
        getWritableDatabase().delete("secure", "id=?", new String[]{id});
    }
    public List<SecureRow> listSecure() {
        List<SecureRow> out = new ArrayList<SecureRow>();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,name,mime,dateAdded,size,origName FROM secure ORDER BY dateAdded DESC", null);
        while (c.moveToNext()) {
            SecureRow r = new SecureRow();
            r.id = c.getString(0); r.name = c.getString(1); r.mime = c.getString(2);
            r.dateAdded = c.getLong(3); r.size = c.getLong(4); r.origName = c.getString(5);
            out.add(r);
        }
        c.close();
        return out;
    }

    // ---- custom albums (virtual albums, like Samsung Gallery's user albums) ----
    public static class CustomAlbum {
        public long id; public String name; public int count; public String coverKey;
    }
    public long createAlbum(String name) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("created", System.currentTimeMillis());
        return getWritableDatabase().insert("custom_albums", null, v);
    }
    public void deleteAlbum(long id) {
        getWritableDatabase().delete("album_items", "albumId=?", new String[]{String.valueOf(id)});
        getWritableDatabase().delete("custom_albums", "id=?", new String[]{String.valueOf(id)});
    }
    public void addToAlbum(long albumId, List<String> keys) {
        SQLiteDatabase db = getWritableDatabase();
        for (String k : keys) {
            ContentValues v = new ContentValues();
            v.put("albumId", albumId);
            v.put("mediaKey", k);
            db.insertWithOnConflict("album_items", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        }
    }
    public void removeFromAlbum(long albumId, String key) {
        getWritableDatabase().delete("album_items", "albumId=? AND mediaKey=?",
                new String[]{String.valueOf(albumId), key});
    }
    public List<CustomAlbum> listCustomAlbums() {
        List<CustomAlbum> out = new ArrayList<CustomAlbum>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT a.id, a.name, COUNT(i.mediaKey), MIN(i.mediaKey) FROM custom_albums a " +
                "LEFT JOIN album_items i ON i.albumId=a.id GROUP BY a.id ORDER BY a.created DESC", null);
        while (c.moveToNext()) {
            CustomAlbum a = new CustomAlbum();
            a.id = c.getLong(0); a.name = c.getString(1);
            a.count = c.getInt(2); a.coverKey = c.getString(3);
            out.add(a);
        }
        c.close();
        return out;
    }
    public List<String> albumItemKeys(long albumId) {
        List<String> out = new ArrayList<String>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT mediaKey FROM album_items WHERE albumId=?", new String[]{String.valueOf(albumId)});
        while (c.moveToNext()) out.add(c.getString(0));
        c.close();
        return out;
    }
}
