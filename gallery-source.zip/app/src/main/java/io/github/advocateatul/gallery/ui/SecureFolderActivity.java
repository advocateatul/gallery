package io.github.advocateatul.gallery.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.github.advocateatul.gallery.R;
import io.github.advocateatul.gallery.data.GalleryDb;
import io.github.advocateatul.gallery.util.MediaActions;
import io.github.advocateatul.gallery.util.ThumbLoader;
import io.github.advocateatul.gallery.util.UiUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SecureFolderActivity extends AppCompatActivity {
    private List<GalleryDb.SecureRow> rows = new ArrayList<GalleryDb.SecureRow>();

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_list);
        ((TextView) findViewById(R.id.title)).setText(R.string.menu_secure);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        TextView action = findViewById(R.id.action);
        action.setVisibility(View.VISIBLE);
        action.setText(R.string.pin_change);
        action.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(SecureFolderActivity.this, PinActivity.class);
                i.putExtra("change", true);
                startActivity(i);
            }
        });
        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new GridLayoutManager(this, 3));
        list.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return rows.size(); }
            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_photo, p, false);
                int cell = UiUtils.screenWidth(p.getContext()) / 3;
                v.setLayoutParams(new ViewGroup.LayoutParams(cell, cell));
                return new RecyclerView.ViewHolder(v) {};
            }
            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                final GalleryDb.SecureRow r = rows.get(pos);
                ImageView thumb = h.itemView.findViewById(R.id.thumb);
                File f = MediaActions.secureFile(h.itemView.getContext(), r.name);
                boolean video = r.mime != null && r.mime.startsWith("video");
                h.itemView.findViewById(R.id.play).setVisibility(video ? View.VISIBLE : View.GONE);
                h.itemView.findViewById(R.id.duration).setVisibility(View.GONE);
                if (video) {
                    thumb.setImageResource(R.drawable.ic_video);
                    thumb.setScaleType(ImageView.ScaleType.CENTER);
                } else {
                    ThumbLoader.get(h.itemView.getContext()).loadFile(thumb, f, 320);
                }
                h.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { showSecureItem(r); }
                });
            }
        });
        refresh();
    }

    private void refresh() {
        rows = GalleryDb.get(this).listSecure();
        // prune rows whose file is gone
        List<GalleryDb.SecureRow> kept = new ArrayList<GalleryDb.SecureRow>();
        for (GalleryDb.SecureRow r : rows) {
            if (MediaActions.secureFile(this, r.name).exists()) kept.add(r);
            else GalleryDb.get(this).removeSecure(r.id);
        }
        rows = kept;
        findViewById(R.id.empty).setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
        ((ImageView) findViewById(R.id.empty_icon)).setImageResource(R.drawable.ic_lock);
        ((TextView) findViewById(R.id.empty_text)).setText(R.string.empty_secure);
        ((TextView) findViewById(R.id.empty_sub)).setText(R.string.action_move_secure);
        ((RecyclerView) findViewById(R.id.list)).getAdapter().notifyDataSetChanged();
    }

    private void showSecureItem(final GalleryDb.SecureRow row) {
        final File f = MediaActions.secureFile(this, row.name);
        boolean video = row.mime != null && row.mime.startsWith("video");
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.Theme_Gallery_Dialog);
        b.setTitle(row.origName);
        if (video) {
            VideoView vv = new VideoView(this);
            vv.setVideoPath(f.getAbsolutePath());
            vv.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 700));
            b.setView(vv);
            vv.start();
        } else {
            ImageView iv = new ImageView(this);
            Bitmap bmp = ThumbLoader.decodeScaled(f, 1200);
            if (bmp != null) iv.setImageBitmap(bmp);
            iv.setAdjustViewBounds(true);
            b.setView(iv);
        }
        b.setPositiveButton(R.string.action_restore, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                new Thread(new Runnable() {
                    @Override public void run() {
                        final boolean ok = MediaActions.restoreFromSecure(SecureFolderActivity.this, row);
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (ok) UiUtils.toast(SecureFolderActivity.this, R.string.secure_restored);
                                refresh();
                            }
                        });
                    }
                }).start();
            }
        });
        b.setNegativeButton(R.string.action_delete, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                new AlertDialog.Builder(SecureFolderActivity.this, R.style.Theme_Gallery_Dialog)
                        .setTitle(R.string.secure_delete)
                        .setPositiveButton(R.string.action_delete, new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d2, int w) {
                                f.delete();
                                GalleryDb.get(SecureFolderActivity.this).removeSecure(row.id);
                                refresh();
                            }
                        })
                        .setNegativeButton(R.string.action_cancel, null)
                        .show();
            }
        });
        b.show();
    }
}
