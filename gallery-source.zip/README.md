# Gallery

A fast, private, Samsung One UI–style photo gallery for Android — built from scratch
(own code, own icons) for Atul's Motorola Edge 70. No account, no cloud, no ads:
every smart feature runs on-device.

## Features (Samsung Gallery parity + more)

- **Pictures** — date-grouped grid, pinch-to-zoom grid size (2–5 columns), sort
  (newest / oldest / name / largest), fast async thumbnails with memory + disk cache
- **Albums** — auto albums from device folders with cover + counts
- **Stories** — auto stories by day, plus Memories: *On this day* and *Best shots*
  (sharpness + brightness heuristics), smart albums grouped by date + location
- **Search** — smart search by name, album, date text ("January 2026"), type
  (photo / video), and location
- **Favourites** — one-tap heart, favourites collection
- **Recycle bin** — 30-day trash with restore and permanent delete (system trash
  on Android 11+, app-managed trash below)
- **Viewer** — swipe between photos, pinch + double-tap zoom, video playback with
  seek, share, favourite, delete, details (EXIF/date/location), slideshow,
  set-as-wallpaper
- **Editor** — crop (free / 1:1 / 4:3 / 16:9), rotate, flip, 8 filters, adjust
  (brightness, contrast, saturation, warmth, highlights, shadows, sharpness),
  draw, text, stickers, collage (2/3/4-photo layouts), one-tap auto-enhance,
  object eraser (on-device diffusion inpainting), video trim (no re-encode)
- **Secure Folder** — app-level locked folder: media moved out of MediaStore into
  private storage, gated by a 4-digit PIN + fingerprint (BiometricPrompt).
  This is NOT Samsung Knox — a third-party app cannot replicate system-level
  Secure Folder — but the files are invisible to other apps and to the gallery.
- **Smart cleanup** — duplicate finder (perceptual hash), similar-photo groups,
  blurry detection (Laplacian variance), dark-photo detection, screenshots
- **Bilingual UI** — English + हिन्दी, switchable in Settings / Menu
- **Dark One UI theme** — near-black background, Samsung-blue accent, rounded
  album covers, bottom navigation (Pictures / Albums / Stories / Menu)

## Beyond Samsung Gallery

- Smarter cleanup with one-tap bulk delete and "keep the best" grouping
- Instant local smart search (date text, location, type) with no account
- Memories + smart albums generated fully on-device, no cloud
- Bilingual in-app language switch (English / हिन्दी)
- Object eraser + auto-enhance built into the editor, no extra app needed
- No Samsung account, no cloud sync, no ads — fully private

## Smart features — honest note

All "smart" behaviour is heuristic and on-device: perceptual hashing for
duplicates, Laplacian variance for blur, mean luminance for dark photos,
histogram analysis for auto-enhance, and iterative neighbour-averaging
inpainting for the object eraser. There is no ML model and no cloud call.
Face grouping is intentionally not included (too heavy / unreliable on-device).

## Build

Gradle does not work in the build sandbox used here (its daemon protocol is
corrupted), so the app is built with the manual pipeline in `build.py`
(aapt2 compile/link → javac → d8 → zipalign → apksigner), the same pipeline
used for the Legal Law app. Requirements: JDK 17, Android SDK
(build-tools 36.1.0, platform android-36). Dependencies (AppCompat,
RecyclerView, ViewPager2) are vendored as AARs under `deps/`.

```
python3 build.py
# -> release/Gallery-v1.0.apk (signed with the release keystore)
```

## Install

On the phone: download `Gallery-v1.0.apk`, tap it, tap Install. Grant
"Photos and videos" permission on first launch.

## License

MIT. Written from scratch for this project; AndroidX libraries keep their
own Apache 2.0 licenses. Not affiliated with Samsung; "One UI style" only —
no Samsung code, assets, or trademarks are used.
