"""Manual build for the Gallery app (no Gradle: the Gradle daemon cannot
work in this sandbox - loopback TCP between JVMs is corrupted).
Pipeline: extract AARs -> merge manifests -> aapt2 compile -> aapt2 link
-> javac -> d8 -> zipalign -> apksigner. Proven by aklegal-app build_v42.py."""
import os, subprocess, sys, zipfile, shutil, glob, copy
import xml.etree.ElementTree as ET

HOME = os.path.expanduser('~')
APP = f'{HOME}/workspace/gallery-app'
M = f'{APP}/manual'
DEPS = f'{APP}/deps'
BT = f'{HOME}/workspace/tools/android-sdk/build-tools/36.1.0'
AJAR = f'{HOME}/workspace/tools/android-sdk/platforms/android-36/android.jar'
JDK = f'{HOME}/workspace/tools/jdk-17.0.20.1+1'
PKG = 'io.github.advocateatul.gallery'
ANS = 'http://schemas.android.com/apk/res/android'
TNS = 'http://schemas.android.com/tools'
ET.register_namespace('android', ANS)
A = lambda n: f'{{{ANS}}}{n}'

env = dict(os.environ)
env['JAVA_HOME'] = JDK
env['PATH'] = f'{JDK}/bin:' + env.get('PATH', '')

def run(cmd, **kw):
    print('+', ' '.join(str(c) for c in cmd)[:220], flush=True)
    r = subprocess.run(cmd, env=env, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        print(r.stdout[-3000:]); print(r.stderr[-3000:])
        raise SystemExit(f'FAILED: {cmd[0]} rc={r.returncode}')
    return r

# ---------- 1) extract AARs ----------
aars_dir = f'{M}/aars'
shutil.rmtree(aars_dir, ignore_errors=True)
os.makedirs(aars_dir)
aar_files = sorted(glob.glob(f'{DEPS}/*.aar'))
libs = []
for f in aar_files:
    name = os.path.basename(f)[:-4]
    dest = f'{aars_dir}/{name}'
    with zipfile.ZipFile(f) as z:
        z.extractall(dest)
    libs.append((name, dest))
print(f'{len(libs)} AARs extracted')

# ---------- 2) merge manifests ----------
app_tree = ET.parse(f'{APP}/app/src/main/AndroidManifest.xml')
root = app_tree.getroot()
app_el = root.find('application')

def strip_tools(el):
    for k in list(el.attrib):
        if k.startswith(f'{{{TNS}}}'):
            del el.attrib[k]
    for c in el:
        strip_tools(c)

def key_of(el):
    return (el.tag, el.get(A('name')))

existing_app_children = {key_of(c) for c in app_el}
existing_top = {(c.tag, c.get(A('name'))) for c in root if c.tag in ('uses-permission', 'uses-feature', 'permission')}
added = 0
for name, dest in libs:
    mf = f'{dest}/AndroidManifest.xml'
    if not os.path.exists(mf):
        continue
    lt = ET.parse(mf)
    lr = lt.getroot()
    for c in list(lr):
        if c.tag in ('uses-permission', 'uses-feature', 'permission'):
            k = (c.tag, c.get(A('name')))
            if k not in existing_top:
                strip_tools(c); root.append(copy.deepcopy(c)); existing_top.add(k); added += 1
        elif c.tag == 'application':
            acf = c.get(A('appComponentFactory'))
            if acf and not app_el.get(A('appComponentFactory')):
                app_el.set(A('appComponentFactory'), acf)
            for gc in list(c):
                if gc.tag in ('activity', 'activity-alias', 'service', 'receiver', 'provider', 'meta-data', 'uses-library'):
                    k = key_of(gc)
                    if k not in existing_app_children:
                        strip_tools(gc); app_el.append(copy.deepcopy(gc)); existing_app_children.add(k); added += 1
print(f'manifest merge: +{added} elements')

for el in root.iter():
    if el.tag in ('application', 'activity', 'activity-alias', 'service', 'receiver', 'provider'):
        n = el.get(A('name'))
        if n:
            if n.startswith('.'):
                el.set(A('name'), PKG + n)
            elif '.' not in n:
                el.set(A('name'), PKG + '.' + n)
strip_tools(root)
sub_count = 0
for el in root.iter():
    for k, v in list(el.attrib.items()):
        if '${applicationId}' in v:
            el.set(k, v.replace('${applicationId}', PKG)); sub_count += 1
print(f'applicationId substitutions: {sub_count}')

removed = []
for c in list(app_el):
    nm = c.get(A('name'))
    if nm in ('androidx.startup.InitializationProvider', 'androidx.profileinstaller.ProfileInstallReceiver'):
        app_el.remove(c); removed.append(nm)
print('stripped components:', removed)
merged_path = f'{M}/merged-manifest.xml'
app_tree.write(merged_path, xml_declaration=True, encoding='utf-8')
print('merged manifest written')

# ---------- 3) compile resources ----------
comp_dir = f'{M}/compiled'
shutil.rmtree(comp_dir, ignore_errors=True)
os.makedirs(comp_dir)
compiled = []
def compile_res(resdir, tag):
    out = f'{comp_dir}/{tag}.zip'
    run([f'{BT}/aapt2', 'compile', '--dir', resdir, '-o', out])
    compiled.append(out)
compile_res(f'{APP}/app/src/main/res', 'app')
extra_pkgs = []
classes_jars = []
asset_dirs = []
for name, dest in libs:
    if os.path.exists(f'{dest}/classes.jar'):
        classes_jars.append(f'{dest}/classes.jar')
    for lj in sorted(glob.glob(f'{dest}/libs/*.jar')):
        classes_jars.append(lj)
    resdir = f'{dest}/res'
    if os.path.isdir(resdir) and os.listdir(resdir):
        compile_res(resdir, name)
    rtxt = f'{dest}/R.txt'
    if os.path.exists(rtxt) and os.path.getsize(rtxt) > 0:
        lmf = ET.parse(f'{dest}/AndroidManifest.xml').getroot()
        extra_pkgs.append(lmf.get('package'))
    if os.path.isdir(f'{dest}/assets') and os.listdir(f'{dest}/assets'):
        asset_dirs.append(f'{dest}/assets')
print(f'{len(compiled)} res sets compiled; extra R packages: {len(extra_pkgs)}')

# ---------- 4) link ----------
gen_dir = f'{M}/gen'
shutil.rmtree(gen_dir, ignore_errors=True)
os.makedirs(gen_dir)
link_cmd = [f'{BT}/aapt2', 'link', '-o', f'{M}/base.apk', '-I', AJAR,
            '--manifest', merged_path, '--java', gen_dir,
            '--min-sdk-version', '26', '--target-sdk-version', '34',
            '--version-code', '1', '--version-name', '1.0', '--auto-add-overlay']
if extra_pkgs:
    link_cmd += ['--extra-packages', ':'.join(extra_pkgs)]
for ad in asset_dirs:
    link_cmd += ['-A', ad]
link_cmd += compiled
run(link_cmd)
print('base.apk linked')

# ---------- 5) javac ----------
plain_jars = [f for f in sorted(glob.glob(f'{DEPS}/*.jar')) if os.path.getsize(f) > 1000]
cp = ':'.join([AJAR] + classes_jars + plain_jars)
sources = []
for base in [f'{APP}/app/src/main/java', gen_dir]:
    for dirpath, _, files in os.walk(base):
        for fn in files:
            if fn.endswith('.java'):
                sources.append(os.path.join(dirpath, fn))
print(f'javac: {len(sources)} sources')
classes_dir = f'{M}/classes'
shutil.rmtree(classes_dir, ignore_errors=True)
os.makedirs(classes_dir)
src_list = f'{M}/sources.txt'
open(src_list, 'w').write('\n'.join(sources))
run([f'{JDK}/bin/javac', '-encoding', 'UTF-8', '-source', '8', '-target', '8',
     '-cp', cp, '-d', classes_dir, '@' + src_list])
run([f'{JDK}/bin/jar', 'cf', f'{M}/appclasses.jar', '-C', classes_dir, '.'])
print('app classes compiled')

# ---------- 6) d8 (no diet filter: deps are small, keep everything) ----------
dex_inputs = [f'{M}/appclasses.jar'] + classes_jars + plain_jars
dex_dir = f'{M}/dex'
shutil.rmtree(dex_dir, ignore_errors=True)
os.makedirs(dex_dir)
run([f'{BT}/d8', '--lib', AJAR, '--min-api', '26', '--output', dex_dir] + dex_inputs)
print('dex done:', os.listdir(dex_dir))

# ---------- 7) package + sign ----------
unsigned = f'{M}/unsigned.apk'
with zipfile.ZipFile(f'{M}/base.apk') as zin, zipfile.ZipFile(unsigned, 'w', zipfile.ZIP_DEFLATED) as zout:
    have = set()
    for item in zin.infolist():
        zout.writestr(item, zin.read(item.filename))
        have.add(item.filename)
    for dx in sorted(os.listdir(dex_dir)):
        if dx.endswith('.dex'):
            zout.write(os.path.join(dex_dir, dx), dx)
            have.add(dx)
    svc = {}
    for jar in classes_jars + plain_jars:
        try:
            with zipfile.ZipFile(jar) as zj:
                for n in zj.namelist():
                    if n.startswith('META-INF/services/') and not n.endswith('/'):
                        svc.setdefault(n, [])
                        for line in zj.read(n).decode('utf-8', 'replace').splitlines():
                            line = line.strip()
                            if line and line not in svc[n]:
                                svc[n].append(line)
        except Exception:
            pass
    for n, lines in svc.items():
        if n not in have:
            zout.writestr(n, '\n'.join(lines) + '\n')
            have.add(n)
    print('merged META-INF/services:', len(svc))
run([f'{BT}/zipalign', '-f', '-p', '4', unsigned, f'{M}/aligned.apk'])
pw = open(f'{HOME}/workspace/goals/advocate-website-build-and-self-hosting/hidden_files/app-signing/keystore-password.txt').read().strip()
env['KP'] = pw
final = f'{APP}/release/Gallery-v1.0.apk'
if os.path.exists(final):
    os.remove(final)
r = subprocess.run([f'{BT}/apksigner', 'sign', '--ks', f'{HOME}/workspace/goals/advocate-website-build-and-self-hosting/hidden_files/app-signing/android.keystore',
                    '--ks-key-alias', 'aklegal', '--ks-pass', 'env:KP', '--key-pass', 'env:KP',
                    '--out', final, f'{M}/aligned.apk'], env=env, capture_output=True, text=True)
del env['KP']
if r.returncode != 0:
    print(r.stdout[-2000:]); print(r.stderr[-2000:]); raise SystemExit('apksigner FAILED')
print('SIGNED APK:', final, os.path.getsize(final), 'bytes')
run([f'{BT}/apksigner', 'verify', '--verbose', final])
b = run([f'{BT}/aapt2', 'dump', 'badging', final])
lines=[l for l in b.stdout.splitlines() if l.startswith(('package:', 'sdkVersion', 'targetSdkVersion', 'uses-permission', 'application-label', 'launchable-activity'))]
print('\n'.join(lines[:40]))
