# Gallery App — BUILD LOG
- Started: 2026-11-16 (IST). Goal: native Android gallery APK, Samsung One UI style, for Motorola Edge 70 (Android 16, arm64).
- Package: io.github.advocateatul.gallery, app name "Gallery", minSdk 26, targetSdk 34/35.
- Toolchain verified: JDK 17 (~/workspace/tools/jdk-17.0.20.1+1), Android SDK (~/workspace/tools/android-sdk; build-tools 34.0.0/35.0.0/36.1.0; platforms 34/36), Gradle 8.11.1 zip.
- Signing: keystore ~/workspace/goals/advocate-website-build-and-self-hosting/hidden_files/app-signing/android.keystore, alias aklegal; password already in project files (keystore-password.txt). aklegal-app has no signingConfig in gradle — APKs were signed manually (zipalign + apksigner) — same approach here.
- GitHub reachable (200, ~1s). git 2.43.0.
- Emulator binary exists; system-images/android-34/google_apis present (ABI to check).
- Route: attempt Fossify Gallery (Apache 2.0) clone + build first; fallback = from-scratch Kotlin app if unworkable.

## 2026-11-16 — Gradle route ABANDONED (proven dead end)
- Gradle 9.5.1 + AGP 9.2.1 (Fossify) fails: "Could not dispatch a message to the daemon" / Broken pipe.
- Root cause found: loopback TCP between JVM processes is corrupted in this sandbox. Java client -> Java daemon gets EPIPE on write; aklegal-app's own gradle-build.log shows the identical failure ("Could not receive a message from the daemon", "Unexpected type tag 109 found" — 109='m', matching the "muse: Othe" fragment injected into a Java loopback test reply). Python<->Python loopback works; Java<->Java does not.
- The aklegal-app v42 APK was built by a MANUAL pipeline (aapt2 compile/link, javac, d8, zipalign, apksigner) — see ~/workspace/aklegal-app/manual/*.log. That is the proven route here. Build scripts were Python (.pyc remains: build_v35/build_v37/diet_filter).
- DECISION: from-scratch Java gallery app + manual aapt2/javac/d8 pipeline. Fossify clone kept at fossify/ (reference only, NOT in the final repo) — its Gradle+KSP+Room+Glide stack cannot be built manually in reasonable time.
- App will use only framework APIs + a small set of AndroidX AARs (appcompat, recyclerview, viewpager2 — reusing already-extracted AARs in aklegal-app/manual/aars/ where possible).
- Memory: VM tight (~490MB available); Gradle -Xmx1536m, workers.max=1. No swap add possible (swapon: Operation not permitted).
- Gradle home is /root/.gradle (Java user.home=/root; I run as root with HOME=/home/hatch).

## 2026-11-16 — First clean build ✅
- build.py (manual aapt2/javac/d8 pipeline adapted from aklegal-app build_v42.py) builds clean.
- APK: release/Gallery-v1.0.apk, 2,509,091 bytes, package io.github.advocateatul.gallery, versionCode 1, versionName 1.0, minSdk 26, targetSdk 34.
- apksigner verify: v2 + v3 schemes true. 14 activities in manifest. Hindi strings verified in resources.arsc (207 hi entries, e.g. tab_pictures = "तस्वीरें").
- Deps: 41 vendored AARs/JARs in deps/ (appcompat 1.7.0, recyclerview 1.3.2, viewpager2 1.1.0 + transitive). No diet filter (deps small).
- First-build errors fixed: LATITUDE/LONGITUDE not on MediaColumns (use literal column names), ViewPager2 has no findViewHolderForAdapterPosition (via child RecyclerView), shadowed var in EditorActivity crop loop, missing EN strings trim_saved/trim_failed, PinActivity DialogInterface import, ViewerActivity androidx AlertDialog.
- Fossify clone moved to ~/workspace/gallery-app-fossify-ref/ (reference only, not in repo).

## 2026-11-16 — Trash lookup fix + Samsung fidelity pass + final build ✅
- BUG FIXED (code review): on API 30+, trashed items are hidden from normal
  MediaStore queries, so TrashActivity would have shown empty. Added
  MediaRepo.getByKeyTrashed (QUERY_ARG_MATCH_TRASHED) + legacy-trash synthetic
  items with local-file thumbnails (MediaItem.thumbFile). Rebuilt clean.
- SAMSUNG FIDELITY PASS (web research: Samsung Photography Academy S26/One UI 9
  guide, NamuWiki One UI 7 notes, Samsung support paths):
  - Confirmed parity: bottom nav Pictures/Albums/Stories/Menu, chronological
    Pictures with pinch grid zoom, folder albums, auto Stories, Menu->Trash
    30 days, Secure Folder (app-level), editor crop/rotate/adjust/filters,
    duplicate finder, search by description.
  - ADDED from the pass: user-created custom albums (virtual, DB-backed) with
    Create card, Add-to-album from selection, remove-from-album, delete album;
    Hide album (long-press) + Hidden albums in Settings.
  - NOT reproduced (listed honestly): People face grouping (too heavy on-device),
    Documents collection, natural-language AI search (metadata search instead),
    GIF/Movie maker, Samsung Cloud sync (by design: private, no cloud),
    Galaxy AI Remaster (heuristic auto-enhance instead), AI object eraser
    (basic diffusion inpainting instead). Secure Folder is app-level, NOT Knox.
- FINAL APK: release/Gallery-v1.0.apk, 2,517,352 bytes, v1.0 (code 1),
  minSdk 26, targetSdk 34, signed v2+v3 (aklegal keystore), 14 activities,
  207 Hindi strings in resources.arsc. Reference checker: 0 missing
  strings/drawables/layouts/ids. Dex contains createAlbum, listCustomAlbums,
  getByKeyTrashed, inpaint, autoEnhance.
- EMULATOR TESTING NOT POSSIBLE ON THIS VM (proven): x86_64 emulator requires
  KVM (no vmx/svm on host CPU); arm64 image unsupported by QEMU2 on x86_64;
  the parent team's raw-QEMU Android-x86 attempt (Oct 21) also never reached adb.
  VM has only ~580 MB RAM free; Android needs 1.5 GB+. So NO runtime test was
  possible here. Verification is static: clean build, aapt2 link (validates all
  layouts/drawables/strings), javac, apksigner verify, badging, dex dump.
  Atul MUST install on his Motorola Edge 70 and confirm each feature; any
  defect found there must be fixed before calling it done.
- PIN is SHA-256 hashed (not Keystore-backed). Trash on API 30+ needs the
  user to confirm Android's system trash dialog (OS requirement).
- Repo-ready: README.md, .gitignore (keystore/passwords/build outputs excluded),
  fossify/ moved out to ~/workspace/gallery-app-fossify-ref/.
